// SAIF Background Service Worker (Manifest V3)
// Connected to Go Gateway infrastructure (/api/v1/audit/decisions)
// Integrates Chrome DevTools Protocol (CDP) network interception & High-Bandwidth Port Messaging

// Load standard rules catalog
if (typeof importScripts === 'function' && typeof STANDARD_RULES === 'undefined') {
  try {
    importScripts('rules_catalog.js');
  } catch (e) {
    console.error('[SAIF Sensor] Failed to load rules_catalog.js:', e);
  }
}

let catalogModule = null;

function getCatalogModule() {
  if (catalogModule && catalogModule.STANDARD_RULES && catalogModule.STANDARD_RULES.length > 0) {
    return catalogModule;
  }

  // 1. Try globalThis / self / window
  const g = typeof globalThis !== 'undefined' ? globalThis : (typeof self !== 'undefined' ? self : (typeof window !== 'undefined' ? window : {}));
  if (g.STANDARD_RULES && g.STANDARD_RULES.length > 0) {
    catalogModule = {
      RULE_CATEGORIES: g.RULE_CATEGORIES || [],
      STANDARD_RULES: g.STANDARD_RULES,
      compiledRules: g.compiledRules || [],
      calculateShannonEntropy: typeof g.calculateShannonEntropy === 'function' ? g.calculateShannonEntropy : null,
      PUBLIC_TEST_CREDENTIALS: g.PUBLIC_TEST_CREDENTIALS || null,
      isPublicTestCredential: typeof g.isPublicTestCredential === 'function' ? g.isPublicTestCredential : null,
      parseInlineDirectives: typeof g.parseInlineDirectives === 'function' ? g.parseInlineDirectives : null,
      isRuleActive: typeof g.isRuleActive === 'function' ? g.isRuleActive : null,
      matchStandardRules: typeof g.matchStandardRules === 'function' ? g.matchStandardRules : null,
      getCategorySummary: typeof g.getCategorySummary === 'function' ? g.getCategorySummary : null
    };
    return catalogModule;
  }

  // 2. Try self explicitly
  if (typeof self !== 'undefined' && self.STANDARD_RULES && self.STANDARD_RULES.length > 0) {
    catalogModule = {
      RULE_CATEGORIES: self.RULE_CATEGORIES || [],
      STANDARD_RULES: self.STANDARD_RULES,
      compiledRules: self.compiledRules || [],
      calculateShannonEntropy: typeof self.calculateShannonEntropy === 'function' ? self.calculateShannonEntropy : null,
      PUBLIC_TEST_CREDENTIALS: self.PUBLIC_TEST_CREDENTIALS || null,
      isPublicTestCredential: typeof self.isPublicTestCredential === 'function' ? self.isPublicTestCredential : null,
      parseInlineDirectives: typeof self.parseInlineDirectives === 'function' ? self.parseInlineDirectives : null,
      isRuleActive: typeof self.isRuleActive === 'function' ? self.isRuleActive : null,
      matchStandardRules: typeof self.matchStandardRules === 'function' ? self.matchStandardRules : null,
      getCategorySummary: typeof self.getCategorySummary === 'function' ? self.getCategorySummary : null
    };
    return catalogModule;
  }

  // 3. Try lexical identifiers if present
  try {
    if (typeof STANDARD_RULES !== 'undefined' && typeof RULE_CATEGORIES !== 'undefined') {
      catalogModule = {
        RULE_CATEGORIES: RULE_CATEGORIES,
        STANDARD_RULES: STANDARD_RULES,
        compiledRules: typeof compiledRules !== 'undefined' ? compiledRules : [],
        calculateShannonEntropy: typeof calculateShannonEntropy === 'function' ? calculateShannonEntropy : null,
        PUBLIC_TEST_CREDENTIALS: typeof PUBLIC_TEST_CREDENTIALS !== 'undefined' ? PUBLIC_TEST_CREDENTIALS : null,
        isPublicTestCredential: typeof isPublicTestCredential === 'function' ? isPublicTestCredential : null,
        parseInlineDirectives: typeof parseInlineDirectives === 'function' ? parseInlineDirectives : null,
        isRuleActive: typeof isRuleActive === 'function' ? isRuleActive : null,
        matchStandardRules: typeof matchStandardRules === 'function' ? matchStandardRules : null,
        getCategorySummary: typeof getCategorySummary === 'function' ? getCategorySummary : null
      };
      return catalogModule;
    }
  } catch (_) {}

  // 4. Try dynamic importScripts fallback if function is available
  if (typeof importScripts === 'function') {
    try {
      importScripts('rules_catalog.js');
      const g2 = typeof globalThis !== 'undefined' ? globalThis : (typeof self !== 'undefined' ? self : {});
      if (g2 && g2.STANDARD_RULES && g2.STANDARD_RULES.length > 0) {
        catalogModule = {
          RULE_CATEGORIES: g2.RULE_CATEGORIES || [],
          STANDARD_RULES: g2.STANDARD_RULES,
          compiledRules: g2.compiledRules || [],
          calculateShannonEntropy: typeof g2.calculateShannonEntropy === 'function' ? g2.calculateShannonEntropy : null,
          PUBLIC_TEST_CREDENTIALS: g2.PUBLIC_TEST_CREDENTIALS || null,
          isPublicTestCredential: typeof g2.isPublicTestCredential === 'function' ? g2.isPublicTestCredential : null,
          parseInlineDirectives: typeof g2.parseInlineDirectives === 'function' ? g2.parseInlineDirectives : null,
          isRuleActive: typeof g2.isRuleActive === 'function' ? g2.isRuleActive : null,
          matchStandardRules: typeof g2.matchStandardRules === 'function' ? g2.matchStandardRules : null,
          getCategorySummary: typeof g2.getCategorySummary === 'function' ? g2.getCategorySummary : null
        };
        return catalogModule;
      }
    } catch (_) {}
  }

  // 5. Try require in Node.js test environment
  try {
    if (typeof require === 'function') {
      catalogModule = require('./rules_catalog.js');
      return catalogModule;
    }
  } catch (_) {}

  return null;
}

// Initial catalog resolution
catalogModule = getCatalogModule();

const DEFAULT_GATEWAY = 'http://127.0.0.1:18080';
const DEFAULT_TENANT = '11111111-2222-3333-4444-555555555555';

// Dynamic Rule and Category Toggles (loaded from chrome.storage.local)
let cachedRuleToggles = {};
let cachedCategoryToggles = {};
let cachedRecentEvents = [];
let cachedSnoozeUntil = 0;
let totalEvaluationsCount = 0;
let totalBlocksCount = 0;

// Unified Agent Profile & Decoupled Offline Posture State
let currentProfile = 'light';
let isAgentConnected = false;
let failClosedOffline = false;
let enableClientRegexFallback = true;

function updateToolbarBadge(profile = currentProfile, isConnected = isAgentConnected) {
  if (typeof chrome === 'undefined' || !chrome.action) return;
  if (cachedSnoozeUntil > Date.now()) {
    updateSnoozeBadge(cachedSnoozeUntil);
    return;
  }
  try {
    if (!isConnected) {
      chrome.action.setBadgeText({ text: 'OFF' });
      chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' }); // amber warning
      return;
    }
    if (profile === 'c4' || profile === 'decision') {
      chrome.action.setBadgeText({ text: '⚡' });
      chrome.action.setBadgeBackgroundColor({ color: '#0284c7' }); // cyan/blue
    } else if (profile === 'engineer' || profile === 'r2') {
      chrome.action.setBadgeText({ text: '🧠' });
      chrome.action.setBadgeBackgroundColor({ color: '#8b5cf6' }); // violet/blue
    } else {
      chrome.action.setBadgeText({ text: '🧠' });
      chrome.action.setBadgeBackgroundColor({ color: '#22c55e' }); // green
    }
  } catch (_) {}
}

function updateSnoozeBadge(snoozeUntil) {
  if (typeof chrome === 'undefined' || !chrome.action) return;
  const remainingMs = (typeof snoozeUntil === 'number' ? snoozeUntil : 0) - Date.now();
  if (remainingMs <= 0) {
    clearSnoozeBadge();
    return;
  }
  const mins = Math.ceil(remainingMs / 60000);
  const badgeText = mins >= 60 ? Math.round(mins / 60) + 'h' : mins + 'm';
  try {
    chrome.action.setBadgeText({ text: badgeText });
    chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });
  } catch (_) {}
}

function clearSnoozeBadge() {
  if (typeof chrome === 'undefined' || !chrome.action) return;
  try {
    updateToolbarBadge(currentProfile, isAgentConnected);
  } catch (_) {}
}

function broadcastSnoozeState(snoozeUntil) {
  if (typeof chrome === 'undefined' || !chrome.tabs) return;
  try {
    chrome.tabs.query({}, (tabs) => {
      if (Array.isArray(tabs)) {
        tabs.forEach(tab => {
          if (tab && tab.id) {
            chrome.tabs.sendMessage(tab.id, {
              type: '__SAIF_SNOOZE_STATE_CHANGED__',
              snoozeUntil
            }).catch(() => {});
          }
        });
      }
    });
  } catch (_) {}
}

// Decision and Endpoint Routing Caches
const evaluationCache = new Map(); // contentHash -> { verdict, reasons, eventId, timestamp }
const EVAL_CACHE_TTL_MS = 20000; // 20s TTL for primed in-flight decisions

let activeEndpointCache = {
  url: null,
  checkedAt: 0
};
const ENDPOINT_CACHE_TTL_MS = 10000; // 10s health cache

// Session-scoped temporary domain whitelist (1-click "Allow once for this domain" action)
const temporaryDomainWhitelist = new Set();
const cachedOmniOverrides = new Set();

if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
  chrome.storage.local.get(['omniOverrides'], (res) => {
    if (res && Array.isArray(res.omniOverrides)) {
      res.omniOverrides.forEach(o => cachedOmniOverrides.add(o));
    }
  });
  if (chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.omniOverrides) {
        cachedOmniOverrides.clear();
        (changes.omniOverrides.newValue || []).forEach(o => cachedOmniOverrides.add(o));
      }
    });
  }
}

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.type === 'RECORD_OVERRIDE_EVENT') {
      const chain = [{
        tier: 'dlp',
        action: 'overridden',
        riskScore: msg.riskScore || 0.95,
        rule: msg.triggeredRule || 'Omnibox Navigation Override',
        latencyMs: 0.1
      }];
      recordEvaluationEvent(msg.prompt, 'OVERRIDDEN', msg.reasons || ['Break-Glass Override'], msg.hostname || 'Omnibox', msg.riskScore || 0.95, msg.triggeredRule || 'Omnibox Override', chain);
      if (msg.prompt) {
        cachedOmniOverrides.add(msg.prompt);
        cachedOmniOverrides.add(msg.prompt.trim());
      }
      if (msg.query) {
        cachedOmniOverrides.add(msg.query);
        cachedOmniOverrides.add(msg.query.trim());
      }
      if (msg.target) cachedOmniOverrides.add(msg.target);
      if (msg.dest) {
        cachedOmniOverrides.add(msg.dest);
        try {
          const parsed = new URL(msg.dest);
          cachedOmniOverrides.add(parsed.href);
          cachedOmniOverrides.add(parsed.origin);
          cachedOmniOverrides.add(parsed.hostname);
          for (const val of parsed.searchParams.values()) {
            cachedOmniOverrides.add(val);
            cachedOmniOverrides.add(val.trim());
          }
        } catch (_) {}
      }
      if (typeof sendResponse === 'function') sendResponse({ status: 'ok' });
    }
  });
}

function extractDomain(urlStr) {
  if (!urlStr || typeof urlStr !== 'string') return '';
  try {
    const u = urlStr.includes('://') ? new URL(urlStr) : new URL('http://' + urlStr);
    return u.hostname.toLowerCase();
  } catch (_) {
    return urlStr.toLowerCase().replace(/^[a-z]+:\/\//, '').split('/')[0].split('?')[0].split(':')[0];
  }
}

function isDomainTemporarilyAllowed(originUrl) {
  if (!originUrl) return false;
  const domain = extractDomain(originUrl);
  if (!domain) return false;
  if (temporaryDomainWhitelist.has(domain)) return true;
  for (const allowed of temporaryDomainWhitelist) {
    if (domain === allowed || domain.endsWith('.' + allowed) || allowed.endsWith('.' + domain)) {
      return true;
    }
  }
  return false;
}

const MINIMUM_DAEMON_PROTOCOL = '2.1.0';

function compareVersions(v1, v2) {
  const p1 = (v1 || '0').split('.').map(Number);
  const p2 = (v2 || '0').split('.').map(Number);
  for (let i = 0; i < Math.max(p1.length, p2.length); i++) {
    const num1 = p1[i] || 0;
    const num2 = p2[i] || 0;
    if (num1 > num2) return 1;
    if (num1 < num2) return -1;
  }
  return 0;
}

async function checkEndpointHealth(url, timeoutMs = 150) {
  try {
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    const effectiveTimeout = url.includes('18080') ? 150 : timeoutMs;
    const timer = controller ? setTimeout(() => controller.abort(), effectiveTimeout) : null;
    let res = await fetch(`${url}/health`, {
      signal: controller ? controller.signal : undefined
    });
    if (!res.ok && res.status === 404) {
      res = await fetch(`${url}/healthz`, {
        signal: controller ? controller.signal : undefined
      });
    }
    if (timer) clearTimeout(timer);
    if (!res.ok) {
      if (url.includes('1808')) {
        isAgentConnected = false;
        updateToolbarBadge(currentProfile, false);
      }
      return false;
    }

    // For workstation daemon (1808x), validate protocol version handshake and profile
    if (url.includes('1808')) {
      try {
        const body = await res.clone().json();
        const protoVer = body.protocol_version || body.protocolVersion;
        if (!protoVer || compareVersions(protoVer, MINIMUM_DAEMON_PROTOCOL) < 0) {
          console.warn(`[SAIF Sensor] Stale or incompatible daemon detected at ${url} (version: ${protoVer || 'unversioned'}, required: >=${MINIMUM_DAEMON_PROTOCOL}). Operating in Graceful Autonomous Safe-Mode.`);
          return false;
        }
        if (body.engineProfile && body.engineProfile !== currentProfile) {
          currentProfile = body.engineProfile;
          setStorage({ currentProfile });
        }
        isAgentConnected = true;

        // Synchronize paused/snooze state from workstation daemon / system tray
        if (body.paused === true) {
          const remMs = (Number(body.paused_remaining_sec) || 900) * 1000;
          cachedSnoozeUntil = Date.now() + remMs;
          setStorage({ snoozeUntil: cachedSnoozeUntil, isPaused: true });
          updateSnoozeBadge(cachedSnoozeUntil);
          broadcastSnoozeState(cachedSnoozeUntil);
        } else if (body.paused === false && cachedSnoozeUntil > Date.now()) {
          cachedSnoozeUntil = 0;
          setStorage({ snoozeUntil: 0, isPaused: false });
          clearSnoozeBadge();
          broadcastSnoozeState(0);
          updateToolbarBadge(currentProfile, true);
        } else if (cachedSnoozeUntil <= Date.now()) {
          updateToolbarBadge(currentProfile, true);
        }
      } catch (_) {
        // If JSON clone fails, allow connection if res.ok
      }
    }
    return true;
  } catch (_) {
    if (url.includes('1808')) {
      isAgentConnected = false;
      updateToolbarBadge(currentProfile, false);
    }
    return false;
  }
}

async function discoverAgentEndpoint() {
  const now = Date.now();
  if (activeEndpointCache.url && (now - activeEndpointCache.checkedAt < ENDPOINT_CACHE_TTL_MS)) {
    return activeEndpointCache.url;
  }

  // Priority 1: Native Workstation Agent (18080-18082) with fast 150ms timeout
  for (const port of [18080, 18081, 18082]) {
    if (await checkEndpointHealth(`http://127.0.0.1:${port}`, 150)) {
      activeEndpointCache = { url: `http://127.0.0.1:${port}`, checkedAt: now };
      return activeEndpointCache.url;
    }
  }

  // Priority 2: Central Control Plane Docker Gateway (8080)
  if (await checkEndpointHealth('http://127.0.0.1:8080', 250)) {
    console.log('[SAIF Sensor] Native agent (18080-18082) unreachable. Failing over to Docker Gateway (8080).');
    activeEndpointCache = { url: 'http://127.0.0.1:8080', checkedAt: now };
    return activeEndpointCache.url;
  }

  // Priority 3: Check storage-configured gatewayUrl if defined
  const store = await getStorage(['gatewayUrl']);
  if (store.gatewayUrl && await checkEndpointHealth(store.gatewayUrl, 600)) {
    activeEndpointCache = { url: store.gatewayUrl, checkedAt: now };
    return activeEndpointCache.url;
  }

  // Both unreachable: record null in cache
  activeEndpointCache = { url: null, checkedAt: now };
  return null;
}

// Client-Side Instant DLP Regex Scan with Toggles
function getActiveCompiledRules() {
  if (!catalogModule || !catalogModule.compiledRules) return [];
  return catalogModule.compiledRules.filter(r => 
    catalogModule.isRuleActive(r, cachedCategoryToggles, cachedRuleToggles)
  );
}

// Bidirectional Smart Restore Vault (Token <-> Original Secret)
const tokenVault = {
  tokenToSecret: new Map(),
  secretToToken: new Map(),
  counter: 0,

  tokenize(secret, prefix = 'SECRET') {
    if (this.secretToToken.has(secret)) {
      return this.secretToToken.get(secret);
    }
    const token = `[${prefix}_${this.counter++}]`;
    this.tokenToSecret.set(token, secret);
    this.secretToToken.set(secret, token);
    return token;
  },

  resolve(text) {
    if (!text) return text;
    let resolved = text;
    for (const [token, secret] of this.tokenToSecret.entries()) {
      resolved = resolved.replaceAll(token, secret);
    }
    return resolved;
  },

  sanitize(text) {
    if (!text) return { sanitized: text, replacements: 0, tokens: [] };

    const parseDirectives = catalogModule && typeof catalogModule.parseInlineDirectives === 'function' ? catalogModule.parseInlineDirectives : null;
    if (parseDirectives) {
      const { globalIgnore } = parseDirectives(text);
      if (globalIgnore) return { sanitized: text, replacements: 0, tokens: [] };
    }

    let sanitized = text;
    const tokens = [];
    let count = 0;

    const activeRules = getActiveCompiledRules();
    for (const pattern of activeRules) {
      pattern.regex.lastIndex = 0;
      sanitized = sanitized.replace(pattern.regex, (match, offset, fullStr) => {
        // 1. Skip canonical public test credentials
        if (catalogModule && typeof catalogModule.isPublicTestCredential === 'function' && catalogModule.isPublicTestCredential(match)) {
          return match;
        }
        // 2. Skip low-entropy mock tokens
        if (pattern.minEntropy && catalogModule && typeof catalogModule.calculateShannonEntropy === 'function') {
          if (catalogModule.calculateShannonEntropy(match) < pattern.minEntropy) {
            return match;
          }
        }
        // 3. Skip line directives if present
        if (parseDirectives) {
          const prefix = fullStr.substring(0, offset);
          const lineIdx = prefix.split('\n').length - 1;
          const { lineDirectives } = parseDirectives(fullStr);
          const currDir = lineDirectives ? lineDirectives.get(lineIdx) : null;
          const prevDir = lineDirectives ? lineDirectives.get(lineIdx - 1) : null;
          const ruleId = (pattern.id || '').toLowerCase();
          if (currDir && (currDir.has('*') || currDir.has(ruleId))) return match;
          if (prevDir && (prevDir.has('*') || prevDir.has(ruleId))) return match;
        }

        count++;
        const token = this.tokenize(match, pattern.placeholder);
        tokens.push({ token, original: match, type: pattern.name });
        return token;
      });
    }

    return { sanitized, replacements: count, tokens };
  }
};

var PUBLIC_TEST_CREDENTIALS = (typeof PUBLIC_TEST_CREDENTIALS !== 'undefined') ? PUBLIC_TEST_CREDENTIALS : new Set([
  'AKIAIOSFODNN7EXAMPLE',
  'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
  '000-00-0000',
  '0000-00-00-0000',
  '0000-00-00-0000'
]);

function isPublicTestCredential(token) {
  if (!token || typeof token !== 'string') return false;
  const t = token.trim();
  if (PUBLIC_TEST_CREDENTIALS.has(t)) return true;
  if (/^sk-(?:proj-)?test-[a-zA-Z0-9_-]+$/i.test(t)) return true;
  if (/^ghp_0{20,}$/.test(t)) return true;
  if (/^glpat-0{20,}$/.test(t)) return true;
  if (/^npm_0{20,}$/.test(t)) return true;
  if (/^AKIA0{16}$/.test(t)) return true;
  if (/^sk_live_0{20,}$/.test(t)) return true;
  return false;
}

function checkLocalPatterns(promptText, categoryToggles = cachedCategoryToggles, ruleToggles = cachedRuleToggles) {
  const matched = [];
  if (!promptText) return matched;
  if (isPublicTestCredential(promptText)) return matched;
  if (catalogModule && typeof catalogModule.matchStandardRules === 'function') {
    const matches = catalogModule.matchStandardRules(promptText, categoryToggles, ruleToggles);
    return matches.map(m => m.reason);
  }
  return matched;
}

async function sha256(message) {
  const msgUint8 = new TextEncoder().encode(message || '');
  const hashBuffer = await crypto.subtle.digest('SHA-256', msgUint8);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(b => b.toString(16).padStart(2, '0')).join('');
}

async function getStorage(keys) {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    return await chrome.storage.local.get(keys);
  }
  return {};
}

async function setStorage(data) {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    await chrome.storage.local.set(data);
  }
}

async function initSensor() {
  try {
    console.log('[SAIF Sensor] Service worker initialized.');
    let config = {};
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL) {
      try {
        const res = await fetch(chrome.runtime.getURL('config.json'));
        if (res.ok) config = await res.json();
      } catch (e) {}
    }

    const discovered = await discoverAgentEndpoint();
    const gatewayUrl = (config.gatewayUrl || discovered || DEFAULT_GATEWAY).replace(/\/+$/, '');
    const tenantId = config.tenantId || DEFAULT_TENANT;

    const stored = await getStorage(['ruleToggles', 'categoryToggles', 'recentEvents', 'totalEvaluations', 'totalBlocks', 'temporaryDomainWhitelist', 'snoozeUntil']);
    if (stored.ruleToggles) cachedRuleToggles = stored.ruleToggles;
    if (stored.categoryToggles) cachedCategoryToggles = stored.categoryToggles;
    if (Array.isArray(stored.recentEvents)) cachedRecentEvents = stored.recentEvents;
    if (typeof stored.totalEvaluations === 'number') totalEvaluationsCount = stored.totalEvaluations;
    if (typeof stored.totalBlocks === 'number') totalBlocksCount = stored.totalBlocks;
    if (typeof stored.snoozeUntil === 'number') {
      cachedSnoozeUntil = stored.snoozeUntil;
      updateSnoozeBadge(cachedSnoozeUntil);
    }
    if (Array.isArray(stored.temporaryDomainWhitelist)) {
      stored.temporaryDomainWhitelist.forEach(d => temporaryDomainWhitelist.add(d));
    }

    await setStorage({
      gatewayUrl,
      tenantId,
      sensorId: config.sensorId || 'b2c3d4e5-f6a7-8901-bcde-f12345678901',
      sensorKey: config.sensorKey || 'default-sensor-key-secret',
      status: 'ONLINE',
      lastHeartbeat: new Date().toISOString()
    });
  } catch (err) {
    console.error('[SAIF Sensor] Init error:', err);
  }
}

// Record local evaluation history event (Only records what gets BLOCKED or OVERRIDDEN in the browser extension)
function recordEvaluationEvent(promptText, verdict, reasons, originUrl, riskScore, triggeredRule, evaluationChain, isSandbox = false, shouldNotify = false) {
  // Free tier browser extension invariant: only record blocked violations or deliberate overrides
  if (verdict !== 'BLOCK' && verdict !== 'OVERRIDDEN') {
    return null;
  }

  // Deduplicate rapid identical events within 3000ms (e.g. dual webNavigation + tabs.onUpdated hooks or retry)
  if (cachedRecentEvents.length > 0) {
    const lastEvent = cachedRecentEvents[0];
    const timeDiff = Date.now() - new Date(lastEvent.timestamp).getTime();
    if (timeDiff < 3000 && lastEvent.promptSnippet === (promptText || '').substring(0, 120) && lastEvent.verdict === verdict) {
      return lastEvent;
    }
  }

  const isOverride = verdict === 'OVERRIDDEN';
  totalEvaluationsCount++;
  if (!isOverride) {
    totalBlocksCount++;
  }

  const resolvedScore = typeof riskScore === 'number'
    ? riskScore
    : 0.95;

  const resolvedRule = triggeredRule || (reasons && reasons[0]) || (isOverride ? 'Break-Glass Override' : 'Policy Violation');

  const eventItem = {
    id: 'evt-' + Date.now() + '-' + Math.random().toString(36).substring(2, 7),
    timestamp: new Date().toISOString(),
    originUrl: originUrl || 'unknown',
    promptSnippet: (promptText || '').substring(0, 120),
    verdict: isOverride ? 'OVERRIDDEN' : 'BLOCK',
    action: isOverride ? 'override' : 'block',
    riskScore: resolvedScore,
    triggeredRule: resolvedRule,
    reasons: reasons || [isOverride ? 'Break-Glass Override' : 'Policy Violation'],
    severity: isOverride ? 'Medium' : 'Critical',
    evaluationChain: Array.isArray(evaluationChain) ? evaluationChain : []
  };
  cachedRecentEvents.unshift(eventItem);
  if (cachedRecentEvents.length > 50) cachedRecentEvents.pop();
  setStorage({
    recentEvents: cachedRecentEvents,
    totalEvaluations: totalEvaluationsCount,
    totalBlocks: totalBlocksCount
  }).catch(() => {});

  if (shouldNotify && !isSandbox && originUrl !== 'sandbox') {
    // Dispatch native OS desktop notification toast via workstation daemon on :18080
    try {
      fetch('http://127.0.0.1:18080/api/v1/notify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rule_name: isOverride ? 'Break-Glass Override Authorized' : resolvedRule,
          matched_text: (promptText || '').substring(0, 80),
          risk_score: resolvedScore
        })
      }).catch(() => {});
    } catch (_) {}
  }

  return eventItem;
}

// Top-level initialization on every service worker spinup/wakeup (Manifest V3 lifecycle standard)
if (typeof chrome !== 'undefined' && chrome.runtime) {
  initSensor().catch(err => console.warn('[SAIF Sensor] Top-level initSensor error:', err));
  if (chrome.runtime.onInstalled) {
    chrome.runtime.onInstalled.addListener(initSensor);
  }
}

if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local') {
      if (changes.categoryToggles) {
        cachedCategoryToggles = changes.categoryToggles.newValue || {};
        evaluationCache.clear();
      }
      if (changes.ruleToggles) {
        cachedRuleToggles = changes.ruleToggles.newValue || {};
        evaluationCache.clear();
      }
      if (changes.recentEvents) {
        cachedRecentEvents = Array.isArray(changes.recentEvents.newValue) ? changes.recentEvents.newValue : [];
      }
      if (changes.snoozeUntil) {
        cachedSnoozeUntil = typeof changes.snoozeUntil.newValue === 'number' ? changes.snoozeUntil.newValue : 0;
        updateSnoozeBadge(cachedSnoozeUntil);
      }
    }
  });
}

// Evaluate Prompt against Gateway Infrastructure (/api/v1/audit/decisions)
async function evaluatePrompt(promptText, originUrl, options = {}) {
  console.log('[SAIF Sensor] Evaluating outgoing prompt:', promptText.substring(0, 60));

  // -1. Check Time-Bounded Protection Snooze
  if (cachedSnoozeUntil > Date.now()) {
    console.log('[SAIF Sensor] Bypassing evaluation: Protection is currently snoozed until', new Date(cachedSnoozeUntil).toISOString());
    return {
      verdict: 'ALLOW',
      reasons: ['Clean - Protection Snoozed'],
      riskScore: 0.0,
      triggeredRule: 'None (Protection Snoozed)',
      overridden: true,
      evaluationChain: [{
        tier: 'protection_snooze',
        action: 'allow',
        riskScore: 0.0,
        rule: 'Time-Bounded Protection Snooze',
        latencyMs: 0.1
      }],
      eventId: (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : ('evt-' + Date.now())
    };
  }

  const activeCategoryToggles = options.categoryToggles || cachedCategoryToggles;
  const activeRuleToggles = options.ruleToggles || cachedRuleToggles;

  // 0. Check Temporary Domain Whitelist ("Allow once for this domain" action)
  if (isDomainTemporarilyAllowed(originUrl)) {
    console.log('[SAIF Sensor] Bypassing evaluation for temporarily whitelisted domain:', originUrl);
    return {
      verdict: 'ALLOW',
      reasons: ['Clean - Temporarily Whitelisted Domain'],
      riskScore: 0.0,
      triggeredRule: 'None (Whitelisted Domain)',
      evaluationChain: [{
        tier: 'domain_whitelist',
        action: 'allow',
        riskScore: 0.0,
        rule: 'Temporary Domain Session Whitelist',
        latencyMs: 0.1
      }],
      eventId: (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : ('evt-' + Date.now())
    };
  }

  // 1. Client-Side Instant DLP Scan (0ms zero-latency hard secrets with toggles)
  const localViolations = checkLocalPatterns(promptText, activeCategoryToggles, activeRuleToggles);
  if (localViolations.length > 0) {
    console.warn('[SAIF Sensor] Instant Local DLP Violation:', localViolations);
    const ruleName = localViolations[0];
    const chain = [{
      tier: 'dlp',
      action: 'block',
      riskScore: 0.95,
      rule: ruleName,
      latencyMs: 0.1
    }];
    const result = {
      verdict: 'BLOCK',
      reasons: localViolations,
      riskScore: 0.95,
      triggeredRule: ruleName,
      evaluationChain: chain,
      eventId: (typeof crypto !== 'undefined' && crypto.randomUUID) ? crypto.randomUUID() : ('evt-' + Date.now())
    };
    recordEvaluationEvent(promptText, result.verdict, result.reasons, originUrl, result.riskScore, result.triggeredRule, result.evaluationChain);
    return result;
  }

  function isRuleSuppressedByToggles(ruleName, catToggles, rToggles, pText) {
    if (pText && catalogModule && typeof catalogModule.matchStandardRules === 'function') {
      const allMatches = catalogModule.matchStandardRules(pText, {}, {});
      if (allMatches.length > 0) {
        const activeMatches = catalogModule.matchStandardRules(pText, catToggles, rToggles);
        if (activeMatches.length === 0) {
          return true;
        }
      }
    }
    if (!ruleName) return false;
    if (catalogModule && typeof catalogModule.isRuleActive === 'function') {
      const ruleDef = catalogModule.STANDARD_RULES.find(r =>
        r.name === ruleName ||
        r.id === ruleName ||
        r.reason === ruleName ||
        (r.reason && ruleName.includes(r.reason)) ||
        (r.name && ruleName.includes(r.name))
      );
      if (ruleDef && !catalogModule.isRuleActive(ruleDef, catToggles, rToggles)) {
        return true;
      }
    }
    const lower = (ruleName || '').toLowerCase();
    for (const [catId, active] of Object.entries(catToggles || {})) {
      if (active === false && (lower.includes(catId) || (catId === 'pii' && (lower.includes('pii') || lower.includes('ssn') || lower.includes('social security'))))) {
        return true;
      }
    }
    for (const [rId, active] of Object.entries(rToggles || {})) {
      if (active === false) {
        if (rId === 'pat-ssn' && (lower.includes('ssn') || lower.includes('social security'))) return true;
        if (rId === 'pat-aws-key' && (lower.includes('aws') || lower.includes('akia'))) return true;
        if (rId === 'pat-aws-temp-key' && (lower.includes('aws') || lower.includes('asia'))) return true;
        if (rId === 'pat-credit-card' && (lower.includes('credit card') || lower.includes('card'))) return true;
        const baseId = rId.replace(/^pat-/, '').replace(/-/g, ' ');
        if (lower.includes(baseId)) return true;
      }
    }
    return false;
  }

  // 2. Check in-memory decision cache (fast lookup for primed DOM submit clicks)
  const contentHash = await sha256(promptText);
  const now = Date.now();
  if (evaluationCache.has(contentHash)) {
    const cached = evaluationCache.get(contentHash);
    if (now - cached.timestamp < EVAL_CACHE_TTL_MS) {
      if (cached.verdict === 'BLOCK' && isRuleSuppressedByToggles(cached.triggeredRule, activeCategoryToggles, activeRuleToggles, promptText)) {
        evaluationCache.delete(contentHash);
      } else {
        console.log('[SAIF Sensor] Serving decision from pre-flight cache for hash:', contentHash.substring(0, 8));
        if (cached.verdict === 'BLOCK') {
          recordEvaluationEvent(promptText, cached.verdict, cached.reasons, originUrl, cached.riskScore, cached.triggeredRule, cached.evaluationChain);
        }
        return {
          verdict: cached.verdict,
          reasons: cached.reasons,
          eventId: cached.eventId,
          riskScore: cached.riskScore,
          triggeredRule: cached.triggeredRule,
          evaluationChain: cached.evaluationChain
        };
      }
    } else {
      evaluationCache.delete(contentHash);
    }
  }

  // 2b. Check substring / prefix match against active primed BLOCK decisions
  // Prevents diluted RPC payloads from overriding an explicit DOM prompt block
  for (const [hash, cached] of evaluationCache.entries()) {
    if (now - cached.timestamp < EVAL_CACHE_TTL_MS && cached.verdict === 'BLOCK' && cached.rawPrompt) {
      if (isRuleSuppressedByToggles(cached.triggeredRule, activeCategoryToggles, activeRuleToggles, promptText)) {
        continue;
      }
      if (promptText.includes(cached.rawPrompt) || (cached.rawPrompt.length > 20 && promptText.startsWith(cached.rawPrompt.substring(0, 40)))) {
        console.warn('[SAIF Sensor] Serving decision from active primed BLOCK cache for matching prompt:', cached.rawPrompt.substring(0, 40));
        recordEvaluationEvent(promptText, 'BLOCK', cached.reasons, originUrl, cached.riskScore, cached.triggeredRule, cached.evaluationChain);
        return {
          verdict: 'BLOCK',
          reasons: cached.reasons,
          eventId: cached.eventId,
          riskScore: cached.riskScore,
          triggeredRule: cached.triggeredRule,
          evaluationChain: cached.evaluationChain
        };
      }
    }
  }

  // 3. Resolve active endpoint with two-tier failover (saif.exe :18080 -> Docker Gateway :8080)
  const store = await getStorage(['gatewayUrl', 'tenantId', 'sensorId', 'sensorKey']);
  let targetUrl = await discoverAgentEndpoint();
  if (!targetUrl) {
    targetUrl = store.gatewayUrl || DEFAULT_GATEWAY;
  }

  const tenantId = store.tenantId || DEFAULT_TENANT;
  const sensorId = store.sensorId || 'b2c3d4e5-f6a7-8901-bcde-f12345678901';
  const eventId = crypto.randomUUID();

  const payload = {
    eventId,
    sensorId,
    sensorType: 'browser_extension',
    tenantId,
    eventTimeUtc: new Date().toISOString(),
    mode: options.isPreflight ? 'preflight' : 'inline',
    alertPolicy: 'suppress',
    alert_policy: 'suppress',
    userContext: {
      userId: 'browser-user',
      devicePosture: 'managed',
      originUrl: originUrl || 'unknown'
    },
    categoryToggles: activeCategoryToggles,
    ruleToggles: activeRuleToggles,
    aiContext: {
      provider: 'openai',
      modelRequested: 'gpt-4o',
      prompt: promptText,
      contentHash
    },
    content: {
      promptText: promptText
    }
  };

  async function postAuditDecision(endpointUrl) {
    const cleanUrl = endpointUrl.replace(/\/+$/, '');
    const evalUrl = `${cleanUrl}/api/v1/audit/decisions`;
    const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
    // 150ms fast-fail timeout for local workstation daemon (saif.exe on :18080-:18089)
    const isLocalDaemon = endpointUrl.includes('1808');
    const timeoutMs = isLocalDaemon ? 250 : 600;
    const timeout = controller ? setTimeout(() => controller.abort(), timeoutMs) : null;
    try {
      const response = await fetch(evalUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Sensor-Key': store.sensorKey || '',
          'X-Tenant-ID': tenantId,
          'X-Role': 'admin'
        },
        body: JSON.stringify(payload),
        signal: controller ? controller.signal : undefined
      });
      if (timeout) clearTimeout(timeout);
      return response;
    } catch (err) {
      if (timeout) clearTimeout(timeout);
      throw err;
    }
  }

  try {
    let response;
    try {
      response = await postAuditDecision(targetUrl);
    } catch (primaryErr) {
      // Automatic cascade to Docker Gateway (8080) if primary 1808x connection failed or timed out
      if (targetUrl.includes('1808')) {
        console.warn('[SAIF Sensor] Primary agent (1808x) unavailable. Attempting Docker Gateway (8080) fallback...');
        response = await postAuditDecision('http://127.0.0.1:8080');
      } else {
        throw primaryErr;
      }
    }

    if (!response.ok) {
      // If primary 1808x gave non-200, try Docker 8080
      if (targetUrl.includes('1808')) {
        console.warn('[SAIF Sensor] Primary agent returned HTTP', response.status, '. Trying Docker Gateway (8080)...');
        try {
          const fallbackRes = await postAuditDecision('http://127.0.0.1:8080');
          if (fallbackRes.ok) {
            response = fallbackRes;
          }
        } catch (_) {}
      }
    }

    if (!response.ok) {
      console.warn('[SAIF Sensor] Gateway returned error status:', response.status, '. Falling back to autonomous client regex.');
      const fallbackViolations = checkLocalPatterns(promptText, activeCategoryToggles, activeRuleToggles);
      if (fallbackViolations.length > 0) {
        const ruleName = fallbackViolations[0];
        const chain = [
          { tier: 'dlp_fallback', action: 'block', riskScore: 0.95, rule: ruleName, latencyMs: 0.2 }
        ];
        const fallbackBlock = {
          verdict: 'BLOCK',
          reasons: fallbackViolations,
          riskScore: 0.95,
          triggeredRule: ruleName,
          evaluationChain: chain,
          eventId: eventId || ('evt-' + Date.now()),
          fallbackMode: 'autonomous_client_regex'
        };
        recordEvaluationEvent(promptText, fallbackBlock.verdict, fallbackBlock.reasons, originUrl, fallbackBlock.riskScore, fallbackBlock.triggeredRule, fallbackBlock.evaluationChain);
        return fallbackBlock;
      }
      const chain = [
        { tier: 'dlp_fallback', action: 'allow', riskScore: 0.0, rule: `Clean (Autonomous In-Browser Regex Fallback - Gateway ${response.status})`, latencyMs: 0.2 }
      ];
      return {
        verdict: 'ALLOW',
        reasons: ['Clean - Safe (Autonomous In-Browser Regex Fallback)'],
        riskScore: 0.0,
        triggeredRule: 'None (Clean)',
        evaluationChain: chain,
        eventId: eventId || ('evt-' + Date.now()),
        fallbackMode: 'autonomous_client_regex'
      };
    }

    const decision = await response.json();
    console.log('[SAIF Sensor] Gateway decision response:', decision);

    let isBlock = (decision.action === 'block' || decision.action === 'forbid' || decision.verdict === 'BLOCK');

    // Dynamic Toggle Guard: If upstream returned BLOCK for a rule/category that is disabled in client toggles,
    // suppress the block to guarantee the user's toggle choices are respected across the system.
    const cls = decision.metadata?.classificationResult;
    const primaryLabel = (cls && cls.labels && cls.labels[0] && cls.labels[0].category) || null;
    const ruleCandidate = decision.triggered_rule || decision.triggeredRule || primaryLabel || (decision.metadata?.policyIds && decision.metadata.policyIds[0]);
    let toggleSuppressed = false;
    if (isRuleSuppressedByToggles(ruleCandidate, activeCategoryToggles, activeRuleToggles, promptText)) {
      console.log('[SAIF Sensor] Upstream rule/category/prompt disabled in extension toggles:', ruleCandidate);
      isBlock = false;
      toggleSuppressed = true;
    }

    // Extract risk score: 
    // - If toggle disabled: 0.0
    // - If block: score (default 0.85)
    // - If advisory warn band (>= 0.40): preserved
    // - If clean (< 0.40): 0.0 per canonical schema purity
    let rawScore = 0.0;
    if (typeof decision.risk_score === 'number') {
      rawScore = decision.risk_score;
    } else if (typeof decision.riskScore === 'number') {
      rawScore = decision.riskScore;
    } else if (cls && typeof cls.riskScore === 'number') {
      rawScore = cls.riskScore;
    } else if (isBlock) {
      rawScore = 0.85;
    }

    let riskScore = 0.0;
    if (toggleSuppressed) {
      riskScore = 0.0;
    } else if (isBlock) {
      riskScore = rawScore || 0.85;
    } else if (rawScore >= 0.4) {
      riskScore = rawScore;
    } else {
      riskScore = 0.0;
    }

    // Extract triggered rule: report rule name on block OR when riskScore >= 0.4 (advisory/warn)
    const triggeredRule = (!toggleSuppressed && (isBlock || (ruleCandidate && riskScore >= 0.4)))
      ? (ruleCandidate || 'Policy Violation')
      : 'None (Clean)';

    // Default reason on ALLOW should be advisory reason if in WARN band, otherwise 'Clean - Safe'
    const reasons = isBlock
      ? (decision.enforcement && decision.enforcement.userMessage
          ? [decision.enforcement.userMessage]
          : (decision.reasons && decision.reasons.length ? decision.reasons : ['Blocked by corporate security policy.']))
      : (riskScore >= 0.4 && triggeredRule !== 'None (Clean)'
          ? [triggeredRule]
          : (decision.reasons && decision.reasons.length && !decision.reasons[0].toLowerCase().includes('block') && !decision.reasons[0].toLowerCase().includes('violation')
              ? decision.reasons
              : ['Clean - Safe']));

    // Build canonical evaluation chain trace across evaluation tiers
    const evaluationChain = [
      {
        tier: 'dlp',
        action: 'allow',
        riskScore: 0.0,
        rule: 'Clean (No Regex Match)',
        latencyMs: 0.2
      },
      {
        tier: cls?.tier || 'semantic',
        action: isBlock ? 'block' : 'allow',
        riskScore: Number(riskScore.toFixed(4)),
        rule: primaryLabel || (isBlock ? 'Policy Threshold Exceeded' : 'Under Violation Threshold'),
        latencyMs: cls?.latencyMs || decision.metadata?.processingTimeMs || 15
      }
    ];

    if (decision.metadata?.policyIds && decision.metadata.policyIds.length > 0) {
      evaluationChain.push({
        tier: 'cedar',
        action: isBlock ? 'block' : 'allow',
        riskScore: Number(riskScore.toFixed(4)),
        rule: decision.metadata.policyIds.join(', '),
        latencyMs: 1
      });
    }

    const result = {
      verdict: isBlock ? 'BLOCK' : 'ALLOW',
      reasons,
      riskScore,
      triggeredRule,
      evaluationChain,
      eventId: decision.eventId || eventId,
      rawPrompt: promptText
    };

    evaluationCache.set(contentHash, { ...result, timestamp: Date.now() });

    // Record in local audit history: strictly for BLOCK decisions only in the browser extension
    if (isBlock) {
      recordEvaluationEvent(promptText, result.verdict, result.reasons, originUrl, result.riskScore, result.triggeredRule, result.evaluationChain);
    }
    return result;
  } catch (err) {
    console.warn('[SAIF Sensor] Security gateways unreachable/timed out:', err.message);
    isAgentConnected = false;
    updateToolbarBadge(currentProfile, false);

    // 1. Strict Offline Mode: Enforce hard block when failClosedOffline is configured
    if (failClosedOffline || options.failClosedOffline) {
      const chain = [
        { tier: 'dlp', action: 'block', riskScore: 1.0, rule: 'Agent Offline (Fail-Closed Posture)', latencyMs: 0.1 }
      ];
      const fallbackBlock = {
        verdict: 'BLOCK',
        reasons: ['Agent Offline (Fail-Closed Security Posture Enforced)'],
        riskScore: 1.0,
        triggeredRule: 'Offline Fail-Closed Policy',
        evaluationChain: chain,
        eventId: eventId || ('evt-' + Date.now()),
        fallbackMode: 'offline_fail_closed'
      };
      recordEvaluationEvent(promptText, fallbackBlock.verdict, fallbackBlock.reasons, originUrl, fallbackBlock.riskScore, fallbackBlock.triggeredRule, fallbackBlock.evaluationChain);
      return fallbackBlock;
    }

    // 2. Client Regex Fallback (Milestone 11.2 compatibility)
    if (options.enableClientRegexFallback || (enableClientRegexFallback && !options.failOpenOffline)) {
      const fallbackViolations = checkLocalPatterns(promptText, activeCategoryToggles, activeRuleToggles);
      if (fallbackViolations.length > 0) {
        const ruleName = fallbackViolations[0];
        const chain = [
          { tier: 'dlp_fallback', action: 'block', riskScore: 0.95, rule: ruleName, latencyMs: 0.2 }
        ];
        const fallbackBlock = {
          verdict: 'BLOCK',
          reasons: fallbackViolations,
          riskScore: 0.95,
          triggeredRule: ruleName,
          evaluationChain: chain,
          eventId: eventId || ('evt-' + Date.now()),
          fallbackMode: 'autonomous_client_regex'
        };
        recordEvaluationEvent(promptText, fallbackBlock.verdict, fallbackBlock.reasons, originUrl, fallbackBlock.riskScore, fallbackBlock.triggeredRule, fallbackBlock.evaluationChain);
        return fallbackBlock;
      }

      const chain = [
        { tier: 'dlp_fallback', action: 'allow', riskScore: 0.0, rule: 'Clean (Autonomous In-Browser Regex Fallback)', latencyMs: 0.2 }
      ];
      return {
        verdict: 'ALLOW',
        reasons: ['Clean - Safe (Autonomous In-Browser Regex Fallback)'],
        riskScore: 0.0,
        triggeredRule: 'None (Clean)',
        evaluationChain: chain,
        eventId: eventId || ('evt-' + Date.now()),
        fallbackMode: 'autonomous_client_regex'
      };
    }

    // 3. Decoupled Default Posture: Fail-open with amber warning badge
    const chain = [
      { tier: 'dlp', action: 'allow', riskScore: 0.0, rule: 'Agent Offline (Fail-Open Warning)', latencyMs: 0.1 }
    ];
    return {
      verdict: 'ALLOW',
      reasons: ['Clean - Safe (Agent Offline - Fail-Open Warning)'],
      riskScore: 0.0,
      triggeredRule: 'None (Agent Offline)',
      evaluationChain: chain,
      eventId: eventId || ('evt-' + Date.now()),
      fallbackMode: 'offline_fail_open',
      offlineWarning: true
    };
  }
}

// -------------------------------------------------------------
// High-Bandwidth Persistent Port Pipeline & Keep-Alive Heartbeat
// -------------------------------------------------------------
const activePorts = new Set();

if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onConnect) {
  chrome.runtime.onConnect.addListener((port) => {
    if (port.name === 'saif-channel') {
      activePorts.add(port);
      console.log('[SAIF Sensor] Port connected. Active port count:', activePorts.size);
      try {
        port.postMessage({
          type: 'DOMAIN_WHITELIST_UPDATED',
          whitelisted: Array.from(temporaryDomainWhitelist)
        });
      } catch (_) {}

      port.onMessage.addListener(async (msg) => {
        // Internal keep-alive heartbeat ping/pong
        if (msg.type === 'PING') {
          port.postMessage({ type: 'PONG', timestamp: Date.now() });
          return;
        }

        // Paste Sanitization Request
        if (msg.type === 'SANITIZE_TEXT') {
          const result = tokenVault.sanitize(msg.text);
          port.postMessage({
            type: 'SANITIZE_TEXT_RESPONSE',
            requestId: msg.requestId,
            sanitized: result.sanitized,
            replacements: result.replacements,
            tokens: result.tokens
          });
          return;
        }

        // Smart Restore Token Resolution Request
        if (msg.type === 'RESOLVE_TOKENS') {
          const resolved = tokenVault.resolve(msg.text);
          port.postMessage({
            type: 'RESOLVE_TOKENS_RESPONSE',
            requestId: msg.requestId,
            resolved
          });
          return;
        }

        // Pre-emptive Evaluation Priming (dispatched asynchronously on DOM submit click or typing)
        if (msg.type === 'PRIME_EVALUATION') {
          evaluatePrompt(msg.prompt, port.sender ? port.sender.url : 'unknown', {
            isPreflight: true,
            categoryToggles: msg.categoryToggles,
            ruleToggles: msg.ruleToggles
          })
            .then(outcome => {
              try {
                port.postMessage({
                  type: 'PRIME_EVALUATION_RESPONSE',
                  requestId: msg.requestId,
                  ...outcome
                });
              } catch (_) {}
            })
            .catch(() => {});
          return;
        }

        // Block Event Recording Request (from DOM front-door trap or in-browser fast-path)
        if (msg.type === 'RECORD_BLOCK_EVENT') {
          const recorded = recordEvaluationEvent(
            msg.prompt,
            'BLOCK',
            msg.reasons || ['Policy Violation'],
            port.sender ? (port.sender.url || 'browser') : 'browser',
            msg.riskScore || 0.95,
            msg.triggeredRule || (msg.reasons && msg.reasons[0]) || 'Policy Violation',
            msg.evaluationChain || [],
            !!msg.isSandbox
          );
          if (msg.requestId) {
            port.postMessage({
              type: 'RECORD_BLOCK_EVENT_RESPONSE',
              requestId: msg.requestId,
              recorded: !!recorded
            });
          }
          return;
        }

        // Override Event Recording Request (from in-page Break-Glass confirmation)
        if (msg.type === 'RECORD_OVERRIDE_EVENT') {
          const recorded = recordEvaluationEvent(
            msg.prompt,
            'OVERRIDDEN',
            msg.reasons || ['Break-Glass Override'],
            port.sender ? (port.sender.url || 'browser') : 'browser',
            msg.riskScore || 0.95,
            msg.triggeredRule || (msg.reasons && msg.reasons[0]) || 'Break-Glass Override',
            msg.evaluationChain || [{ tier: 'break_glass', action: 'override', riskScore: msg.riskScore || 0.95, rule: msg.triggeredRule || 'Break-Glass Override', latencyMs: 0.1 }],
            !!msg.isSandbox,
            false
          );
          if (msg.requestId) {
            port.postMessage({
              type: 'RECORD_OVERRIDE_EVENT_RESPONSE',
              requestId: msg.requestId,
              recorded: !!recorded
            });
          }
          return;
        }

        // Advisory Warning Notification Request (Native Desktop Alert for Medium Risk)
        if (msg.type === 'RECORD_ADVISORY_EVENT') {
          try {
            fetch('http://127.0.0.1:18080/api/v1/notify', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({
                rule_name: (msg.reasons && msg.reasons[0]) || 'Advisory Security Warning',
                matched_text: (msg.prompt || '').substring(0, 80),
                risk_score: msg.riskScore || 0.60
              })
            }).catch(() => {});
          } catch (_) {}
          return;
        }

        // Prompt Security Evaluation Request
        if (msg.type === 'EVALUATE_PROMPT') {
          const outcome = await evaluatePrompt(msg.prompt, port.sender ? port.sender.url : 'unknown', {
            isPreflight: false,
            categoryToggles: msg.categoryToggles,
            ruleToggles: msg.ruleToggles
          });
          port.postMessage({
            type: 'EVALUATE_PROMPT_RESPONSE',
            requestId: msg.requestId,
            ...outcome
          });
          return;
        }
      });

      port.onDisconnect.addListener(() => {
        const err = chrome.runtime.lastError;
        activePorts.delete(port);
        console.log('[SAIF Sensor] Port disconnected. Remaining active:', activePorts.size);
      });
    }
  });
}

// Fallback One-Off Message Listener
if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.onMessage) {
  chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.type === 'PRIME_EVALUATION') {
      evaluatePrompt(request.prompt, sender && sender.tab ? sender.tab.url : 'popup', {
        isPreflight: true,
        categoryToggles: request.categoryToggles,
        ruleToggles: request.ruleToggles
      })
        .then(res => sendResponse(res))
        .catch(err => sendResponse({ verdict: 'BLOCK', reasons: [err.message] }));
      return true;
    }
    if (request.type === 'EVALUATE_PROMPT') {
      evaluatePrompt(request.prompt, sender && sender.tab ? sender.tab.url : 'popup', {
        isPreflight: false,
        categoryToggles: request.categoryToggles,
        ruleToggles: request.ruleToggles
      })
        .then(res => sendResponse(res))
        .catch(err => sendResponse({ verdict: 'BLOCK', reasons: [err.message] }));
      return true;
    }
    if (request.type === 'SANITIZE_TEXT') {
      const res = tokenVault.sanitize(request.text);
      sendResponse(res);
      return true;
    }
    if (request.type === 'RESOLVE_TOKENS') {
      const res = tokenVault.resolve(request.text);
      sendResponse({ resolved: res });
      return true;
    }
    if (request.type === 'GET_STATUS') {
      getStorage(['gatewayUrl', 'tenantId', 'sensorId', 'status', 'lastHeartbeat'])
        .then(res => sendResponse(res));
      return true;
    }
    if (request.type === 'GET_RULES_CATALOG') {
      const catMod = getCatalogModule();
      const cats = catMod ? (request.taxonomy === 'presidio' ? catMod.PRESIDIO_CATEGORIES : catMod.RULE_CATEGORIES) : [];
      const rules = catMod ? catMod.STANDARD_RULES : [];
      sendResponse({
        categories: cats,
        presidioCategories: catMod ? catMod.PRESIDIO_CATEGORIES : [],
        legacyCategories: catMod ? catMod.LEGACY_CATEGORIES : [],
        rules: rules,
        categoryToggles: cachedCategoryToggles,
        ruleToggles: cachedRuleToggles
      });
      return true;
    }
    if (request.type === 'GET_AGENT_STATUS') {
      sendResponse({
        connected: isAgentConnected,
        profile: currentProfile,
        failClosedOffline: failClosedOffline
      });
      return true;
    }
    if (request.type === 'SET_FAIL_CLOSED_OFFLINE') {
      failClosedOffline = request.enabled === true;
      setStorage({ failClosedOffline }).then(() => {
        sendResponse({ success: true, failClosedOffline });
      });
      return true;
    }
    if (request.type === 'SWITCH_PROFILE') {
      let targetProfile = 'light';
      if (request.profile === 'c4' || request.profile === 'decision') {
        targetProfile = 'c4';
      } else if (request.profile === 'engineer' || request.profile === 'r2') {
        targetProfile = 'engineer';
      }
      fetch('http://127.0.0.1:18080/api/v1/agent/profile', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ profile: targetProfile })
      })
        .then(res => res.json().then(data => ({ ok: res.ok, data })))
        .then(({ ok, data }) => {
          if (ok && data && data.status === 'ok' && data.profile === targetProfile) {
            currentProfile = targetProfile;
            isAgentConnected = true;
            updateToolbarBadge(currentProfile, true);
            setStorage({ currentProfile });
            sendResponse({ success: true, profile: currentProfile, data });
          } else {
            const errorMsg = (data && data.message) || (data && data.error) || 'Agent failed to switch profile';
            sendResponse({ success: false, error: errorMsg, currentProfile: (data && data.profile) || currentProfile });
          }
        })
        .catch(err => {
          sendResponse({ success: false, error: err.message });
        });
      return true;
    }
    if (request.type === 'SET_RULE_TOGGLE') {
      cachedRuleToggles[request.ruleId] = request.enabled;
      evaluationCache.clear();
      setStorage({ ruleToggles: cachedRuleToggles }).then(() => {
        sendResponse({ success: true, ruleToggles: cachedRuleToggles });
      });
      return true;
    }
    if (request.type === 'SET_CATEGORY_TOGGLE') {
      cachedCategoryToggles[request.categoryId] = request.enabled;
      evaluationCache.clear();
      setStorage({ categoryToggles: cachedCategoryToggles }).then(() => {
        sendResponse({ success: true, categoryToggles: cachedCategoryToggles });
      });
      return true;
    }
    if (request.type === 'GET_RECENT_EVENTS') {
      if (cachedRecentEvents && cachedRecentEvents.length > 0) {
        sendResponse({ events: cachedRecentEvents });
      } else {
        getStorage('recentEvents').then(res => {
          const events = (res && res.recentEvents) || [];
          cachedRecentEvents = events;
          sendResponse({ events });
        });
      }
      return true;
    }
    if (request.type === 'CLEAR_RECENT_EVENTS') {
      cachedRecentEvents = [];
      setStorage({ recentEvents: [] }).then(() => sendResponse({ success: true }));
      return true;
    }
    if (request.type === 'GET_SENSOR_STATS') {
      const activeRules = getActiveCompiledRules();
      sendResponse({
        totalEvaluations: totalEvaluationsCount,
        totalBlocks: totalBlocksCount,
        activeRulesCount: activeRules.length,
        status: 'ONLINE'
      });
      return true;
    }
    if (request.type === 'SNOOZE_PROTECTION') {
      const durationMinutes = Number(request.durationMinutes) || 15;
      const snoozeUntil = Date.now() + (durationMinutes * 60 * 1000);
      cachedSnoozeUntil = snoozeUntil;
      // Forward to workstation daemon to keep system tray in sync
      fetch(`http://127.0.0.1:18080/api/v1/agent/pause?duration=${durationMinutes}m`, { method: 'POST' }).catch(() => {});
      setStorage({ snoozeUntil, isPaused: true }).then(() => {
        updateSnoozeBadge(snoozeUntil);
        broadcastSnoozeState(snoozeUntil);
        sendResponse({ success: true, snoozeUntil, durationMinutes });
      });
      return true;
    }
    if (request.type === 'RESUME_PROTECTION') {
      cachedSnoozeUntil = 0;
      // Forward to workstation daemon to keep system tray in sync
      fetch('http://127.0.0.1:18080/api/v1/agent/resume', { method: 'POST' }).catch(() => {});
      setStorage({ snoozeUntil: 0, isPaused: false }).then(() => {
        clearSnoozeBadge();
        broadcastSnoozeState(0);
        updateToolbarBadge(currentProfile, true);
        sendResponse({ success: true, snoozeUntil: 0 });
      });
      return true;
    }
    if (request.type === 'GET_SNOOZE_STATUS') {
      const remainingMs = Math.max(0, cachedSnoozeUntil - Date.now());
      sendResponse({
        isSnoozed: remainingMs > 0,
        snoozeUntil: cachedSnoozeUntil,
        remainingMinutes: Math.ceil(remainingMs / 60000),
        currentProfile: currentProfile
      });
      return true;
    }
    if (request.type === 'ALLOW_DOMAIN_ONCE') {
      const domain = extractDomain(request.domain);
      if (domain) {
        temporaryDomainWhitelist.add(domain);
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ temporaryDomainWhitelist: Array.from(temporaryDomainWhitelist) });
        }
        for (const p of activePorts) {
          try {
            p.postMessage({
              type: 'DOMAIN_WHITELIST_UPDATED',
              whitelisted: Array.from(temporaryDomainWhitelist)
            });
          } catch (_) {}
        }
      }
      sendResponse({ success: true, domain, whitelisted: Array.from(temporaryDomainWhitelist) });
      return true;
    }
    if (request.type === 'REVOKE_DOMAIN_ONCE') {
      const domain = extractDomain(request.domain);
      if (domain) {
        temporaryDomainWhitelist.delete(domain);
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ temporaryDomainWhitelist: Array.from(temporaryDomainWhitelist) });
        }
        for (const p of activePorts) {
          try {
            p.postMessage({
              type: 'DOMAIN_WHITELIST_UPDATED',
              whitelisted: Array.from(temporaryDomainWhitelist)
            });
          } catch (_) {}
        }
      }
      sendResponse({ success: true, domain, whitelisted: Array.from(temporaryDomainWhitelist) });
      return true;
    }
    if (request.type === 'GET_WHITELISTED_DOMAINS') {
      sendResponse({ whitelisted: Array.from(temporaryDomainWhitelist) });
      return true;
    }
    if (request.type === 'DIVERT_TAB_TO_BLOCKED_PAGE') {
      const tabId = sender.tab ? sender.tab.id : null;
      divertTabToBlocked(tabId, {
        violation: request.violation || 'Policy Violation',
        hostname: request.hostname || 'search',
        query: request.query || ''
      });
      sendResponse({ success: true });
      return true;
    }
  });
}

// -------------------------------------------------------------
// Omnibox & Top-Level URL Navigation Gatekeeper
// -------------------------------------------------------------
const redirectingTabs = new Map();

function divertTabToBlocked(tabId, result) {
  const now = Date.now();
  if (redirectingTabs.has(tabId) && (now - redirectingTabs.get(tabId) < 2500)) {
    return;
  }
  redirectingTabs.set(tabId, now);

  // Safety guarantee: ensure audit log event exists for this block
  if (result && result.query) {
    const chain = [{
      tier: 'dlp',
      action: 'block',
      riskScore: 0.95,
      rule: result.violation || 'Policy Violation',
      latencyMs: 0.1
    }];
    recordEvaluationEvent(result.query, 'BLOCK', [result.violation], result.hostname, 0.95, result.violation, chain);
  }

  const blockedUrl = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL)
    ? chrome.runtime.getURL(
        `blocked.html?reason=${encodeURIComponent(result.violation)}&target=${encodeURIComponent(result.hostname)}&snippet=${encodeURIComponent(result.query.substring(0, 80))}&dest=${encodeURIComponent(result.rawUrl || '')}`
      )
    : `blocked.html?reason=${encodeURIComponent(result.violation)}&target=${encodeURIComponent(result.hostname)}&snippet=${encodeURIComponent(result.query.substring(0, 80))}&dest=${encodeURIComponent(result.rawUrl || '')}`;

  if (typeof chrome !== 'undefined' && chrome.tabs) {
    // 1. If tabId is valid (> 0), update it AND bring it to front
    if (tabId && tabId > 0 && chrome.tabs.update) {
      chrome.tabs.update(tabId, { url: blockedUrl, active: true }, () => {
        if (chrome.runtime && chrome.runtime.lastError) {
          // Fallback if tab update failed (e.g. prerender tab discarded or switched)
          chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs && tabs[0] && tabs[0].id) {
              chrome.tabs.update(tabs[0].id, { url: blockedUrl, active: true });
            }
          });
        }
      });
    } else if (chrome.tabs.query && chrome.tabs.update) {
      // 2. tabId is invalid or negative (prerender tab / internal chrome navigation):
      // update active foreground tab directly
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs && tabs[0] && tabs[0].id) {
          chrome.tabs.update(tabs[0].id, { url: blockedUrl, active: true });
        }
      });
    }

    // 3. Multi-tab Purge Invariant: Close or divert ANY open tabs in the current window
    // that are displaying or navigating to the exact violating query (closing the [Switch to this tab] autocomplete leak)
    if (chrome.tabs.query && chrome.tabs.update && result.query) {
      const qToken = result.query.trim();
      chrome.tabs.query({ currentWindow: true }, (allTabs) => {
        if (!allTabs) return;
        for (const t of allTabs) {
          if (t.id !== tabId && t.url && (t.url.includes(encodeURIComponent(qToken)) || t.url.includes(qToken))) {
            if (!t.url.includes('blocked.html') && !t.url.startsWith('chrome-extension://')) {
              console.warn('[SAIF Sensor] Purging pre-existing violating search tab:', t.id, t.url);
              chrome.tabs.update(t.id, { url: blockedUrl });
            }
          }
        }
      });
    }
  }
}

function inspectNavigationUrl(urlStr) {
  if (!urlStr || typeof urlStr !== 'string') return null;

  // Ignore internal and browser-managed schemes and extension pages
  if (urlStr.startsWith('chrome://') || 
      urlStr.startsWith('chrome-extension://') || 
      urlStr.startsWith('about:') || 
      urlStr.startsWith('data:') ||
      urlStr.startsWith('blob:') ||
      urlStr.includes('blocked.html')) {
    return null;
  }

  try {
    const url = new URL(urlStr);

    // Bypass check if domain is temporarily whitelisted by developer
    if (isDomainTemporarilyAllowed(url.hostname)) {
      return null;
    }
    if (cachedOmniOverrides.has(urlStr) || cachedOmniOverrides.has(url.href) || cachedOmniOverrides.has(url.hostname) || cachedOmniOverrides.has(url.origin)) {
      return null;
    }

    // 1. Inspect search engine query parameters (Google, Bing, Yahoo, DuckDuckGo, Baidu, Ecosia, Kagi)
    const SEARCH_QUERY_PARAMS = ['q', 'query', 'p', 'search_query', 'wd', 'text', 'keyword'];
    for (const param of SEARCH_QUERY_PARAMS) {
      const val = url.searchParams.get(param);
      if (val && val.trim().length > 0) {
        if (cachedOmniOverrides.has(val) || cachedOmniOverrides.has(val.trim())) {
          continue;
        }
        // Fast instant DLP regex scan
        const violations = checkLocalPatterns(val);
        if (violations && violations.length > 0) {
          return {
            violation: violations[0],
            param,
            query: val,
            hostname: url.hostname,
            rawUrl: urlStr,
            isSearch: true
          };
        }
      }
    }

    // 2. Comprehensive check on all query parameters (prevent pasting URLs with embedded secrets)
    for (const [key, val] of url.searchParams.entries()) {
      if (SEARCH_QUERY_PARAMS.includes(key)) continue;
      if (cachedOmniOverrides.has(val) || cachedOmniOverrides.has(val.trim())) continue;
      const violations = checkLocalPatterns(val);
      if (violations && violations.length > 0) {
        return {
          violation: violations[0],
          param: key,
          query: val,
          hostname: url.hostname,
          rawUrl: urlStr,
          isSearch: false
        };
      }
    }
  } catch (e) {}

  return null;
}

async function inspectNavigationUrlAsync(urlStr) {
  if (!urlStr || typeof urlStr !== 'string') return null;

  // Ignore internal and browser-managed schemes and extension pages
  if (urlStr.startsWith('chrome://') || 
      urlStr.startsWith('chrome-extension://') || 
      urlStr.startsWith('about:') || 
      urlStr.startsWith('data:') ||
      urlStr.startsWith('blob:') ||
      urlStr.includes('blocked.html')) {
    return null;
  }

  // Ensure cachedOmniOverrides is synchronized from chrome.storage.local if empty
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local && cachedOmniOverrides.size === 0) {
    try {
      const res = await new Promise(r => chrome.storage.local.get(['omniOverrides'], r));
      if (res && Array.isArray(res.omniOverrides)) {
        res.omniOverrides.forEach(o => cachedOmniOverrides.add(o));
      }
    } catch (_) {}
  }

  // 1. Fast instant synchronous regex scan (0ms)
  const regexResult = inspectNavigationUrl(urlStr);
  if (regexResult) {
    if (!regexResult.isSearch) {
      // Real website URL immunity: do not record BLOCK event or divert tab
      return regexResult;
    }
    const chain = [{
      tier: 'dlp',
      action: 'block',
      riskScore: 0.95,
      rule: regexResult.violation,
      latencyMs: 0.1
    }];
    recordEvaluationEvent(regexResult.query, 'BLOCK', [regexResult.violation], regexResult.hostname || urlStr, 0.95, regexResult.violation, chain);
    return regexResult;
  }

  // 2. Semantic evaluation for search engine queries & Omnibox inputs
  try {
    const cat = getCatalogModule();
    const isSearch = (cat && typeof cat.isSearchEngineUrl === 'function')
      ? cat.isSearchEngineUrl(urlStr)
      : false;
    if (!isSearch) {
      return null;
    }
    const url = new URL(urlStr);
    const SEARCH_QUERY_PARAMS = ['q', 'query', 'p', 'search_query', 'wd', 'text', 'keyword'];
    for (const param of SEARCH_QUERY_PARAMS) {
      const val = url.searchParams.get(param);
      if (val && val.trim().length >= 10) {
        if (cachedOmniOverrides.has(val) || cachedOmniOverrides.has(val.trim())) continue;
        // Check if semantic rule is active in catalog
        const isSemanticActive = catalogModule && typeof catalogModule.isRuleActive === 'function'
          ? catalogModule.isRuleActive({ id: 'pat-semantic-engine', category: 'semantic', enabledByDefault: true }, cachedCategoryToggles, cachedRuleToggles)
          : true;

        if (isSemanticActive) {
          const decision = await evaluatePrompt(val.trim(), url.origin || urlStr, { isPreflight: false });
          if (decision && decision.verdict === 'BLOCK') {
            const isOfflineError = decision.reasons && decision.reasons.some(r => r.includes('unreachable') || r.includes('reconnecting'));
            if (!isOfflineError) {
              return {
                violation: (decision.reasons && decision.reasons[0]) || 'Semantic Confidential Content Leak',
                param,
                query: val,
                hostname: url.hostname,
                rawUrl: urlStr,
                isSearch: true,
                isSemantic: true
              };
            }
          }
        }
      }
    }
  } catch (err) {
    console.debug('[SAIF Sensor] inspectNavigationUrlAsync semantic evaluation notice:', err);
  }

  return null;
}

// Attach chrome.webNavigation.onBeforeNavigate listener for address bar queries
if (typeof chrome !== 'undefined' && chrome.webNavigation && chrome.webNavigation.onBeforeNavigate) {
  chrome.webNavigation.onBeforeNavigate.addListener(async (details) => {
    if (details.frameId !== 0) return;
    if (details.url && (details.url.includes('blocked.html') || details.url.startsWith('chrome-extension://'))) {
      return;
    }

    const result = await inspectNavigationUrlAsync(details.url);
    if (result && result.isSearch) {
      console.warn('[SAIF Sensor] Synchronously blocked Omnibox/URL exfiltration navigation:', result);
      divertTabToBlocked(details.tabId, result);
    }
  });
}

// Attach chrome.tabs.onUpdated listener for guaranteed Omnibox, prerender, and address bar interception
if (typeof chrome !== 'undefined' && chrome.tabs && chrome.tabs.onUpdated) {
  chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
    const candidateUrl = changeInfo.url;
    if (!candidateUrl) return;
    if (candidateUrl.includes('blocked.html') || candidateUrl.startsWith('chrome-extension://')) {
      return;
    }

    const result = await inspectNavigationUrlAsync(candidateUrl);
    if (result && result.isSearch) {
      console.warn('[SAIF Sensor] Synchronously blocked tab navigation exfiltration:', result);
      divertTabToBlocked(tabId, result);
    }
  });
}

// Node.js test environment export protection
try {
  if (typeof module !== 'undefined' && module && module.exports) {
    module.exports = {
      sha256,
      checkLocalPatterns,
      inspectNavigationUrl,
      inspectNavigationUrlAsync,
      divertTabToBlocked,
      evaluatePrompt,
      tokenVault,
      DEFAULT_GATEWAY,
      DEFAULT_TENANT,
      catalogModule,
      cachedRuleToggles,
      cachedCategoryToggles,
      cachedRecentEvents,
      getRecentEvents: () => cachedRecentEvents,
      clearRecentEvents: () => { cachedRecentEvents.length = 0; },
      recordEvaluationEvent,
      getActiveCompiledRules,
      evaluationCache,
      setCachedRuleToggles: (t) => { cachedRuleToggles = t; },
      setCachedCategoryToggles: (t) => { cachedCategoryToggles = t; },
      temporaryDomainWhitelist,
      isDomainTemporarilyAllowed,
      extractDomain,
      updateSnoozeBadge,
      clearSnoozeBadge,
      broadcastSnoozeState,
      setCachedSnoozeUntil: (ts) => { cachedSnoozeUntil = ts; },
      getCachedSnoozeUntil: () => cachedSnoozeUntil,
      cachedOmniOverrides,
      updateToolbarBadge,
      getCurrentProfile: () => currentProfile,
      setCurrentProfile: (p) => { currentProfile = p; },
      isAgentConnected: () => isAgentConnected,
      setAgentConnected: (c) => { isAgentConnected = c; },
      getFailClosedOffline: () => failClosedOffline,
      setFailClosedOffline: (f) => { failClosedOffline = f; },
      getEnableClientRegexFallback: () => enableClientRegexFallback,
      setEnableClientRegexFallback: (e) => { enableClientRegexFallback = e; }
    };
  }
} catch (e) {}
