// SAIF Edge Interceptor — Modernized Composite Threat Triage Controller (Manifest V3 CSP Compliant)
document.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(window.location.search);
  const reasonParam = params.get('reason') || '';
  const targetHost = params.get('target') || '';
  const snippetParam = params.get('snippet') || '';
  const destUrl = params.get('dest') || '';

  // Recover full query text
  let rawQuery = params.get('query') || '';
  if (!rawQuery && destUrl) {
    try {
      const u = new URL(destUrl);
      const SEARCH_PARAMS = ['q', 'query', 'p', 'search_query', 'wd', 'text', 'keyword'];
      for (const p of SEARCH_PARAMS) {
        if (u.searchParams.has(p)) {
          rawQuery = u.searchParams.get(p) || '';
          break;
        }
      }
    } catch (_) {}
  }
  if (!rawQuery) {
    rawQuery = snippetParam;
  }

  // Populate compatibility elements for automated tests and scrapers
  const reasonEl = document.getElementById('violation-reason');
  if (reasonEl) reasonEl.textContent = reasonParam || 'Corporate credential or sensitive data protection rule triggered.';
  const targetEl = document.getElementById('target-host');
  if (targetEl) targetEl.textContent = targetHost || '—';
  const qSnippetEl = document.getElementById('query-snippet');
  if (qSnippetEl) qSnippetEl.textContent = snippetParam || rawQuery || '—';

  // ---------------------------------------------------------------------------
  // Composite Threat Extraction
  // ---------------------------------------------------------------------------
  function extractViolations(text) {
    const list = [];
    if (!text || typeof text !== 'string') {
      if (reasonParam) {
        list.push({
          id: 'omni-violation',
          ruleId: 'omni-violation',
          ruleName: reasonParam,
          category: 'Security Policy',
          origin: 'REGEX_DLP',
          token: snippetParam || 'Sensitive query match',
          matched_text: snippetParam || 'Sensitive query match',
          start: 0,
          end: (snippetParam || '').length,
          placeholder: '[REDACTED]'
        });
      }
      return list;
    }

    // 1. DLP Regex Scans
    // Social Security Numbers (SSN)
    const ssnRegex = /\b\d{3}-\d{2}-\d{4}\b/g;
    let match;
    while ((match = ssnRegex.exec(text)) !== null) {
      list.push({
        id: 'pat-ssn',
        ruleId: 'pat-ssn',
        ruleName: 'US Social Security Number',
        category: 'pii_national_id',
        origin: 'REGEX_DLP',
        token: match[0],
        matched_text: match[0],
        start: match.index,
        end: match.index + match[0].length,
        placeholder: '[SSN_REDACTED]'
      });
    }

    // AWS Access Key ID
    const awsRegex = /\bAKIA[0-9A-Z]{16}\b/g;
    while ((match = awsRegex.exec(text)) !== null) {
      list.push({
        id: 'pat-aws-key',
        ruleId: 'pat-aws-key',
        ruleName: 'AWS Access Key ID',
        category: 'credentials',
        origin: 'REGEX_DLP',
        token: match[0],
        matched_text: match[0],
        start: match.index,
        end: match.index + match[0].length,
        placeholder: '[AWS_KEY_REDACTED]'
      });
    }

    // OpenAI API Key
    const openAiRegex = /\bsk-proj-[A-Za-z0-9_-]{20,}\b/g;
    while ((match = openAiRegex.exec(text)) !== null) {
      list.push({
        id: 'pat-openai-key',
        ruleId: 'pat-openai-key',
        ruleName: 'OpenAI API Key',
        category: 'credentials',
        origin: 'REGEX_DLP',
        token: match[0],
        matched_text: match[0],
        start: match.index,
        end: match.index + match[0].length,
        placeholder: '[OPENAI_KEY_REDACTED]'
      });
    }

    // ITIN
    const itinRegex = /\b9\d{2}-\d{2}-\d{4}\b/g;
    while ((match = itinRegex.exec(text)) !== null) {
      list.push({
        id: 'pat-us-itin',
        ruleId: 'pat-us-itin',
        ruleName: 'Individual Taxpayer Identification Number',
        category: 'pii_national_id',
        origin: 'REGEX_DLP',
        token: match[0],
        matched_text: match[0],
        start: match.index,
        end: match.index + match[0].length,
        placeholder: '[ITIN_REDACTED]'
      });
    }

    // 2. Semantic Policy Violations (ONNX semantic models & policy keywords)
    const semanticRules = [
      {
        id: 'pat-phoenix',
        ruleName: 'Project Phoenix Technical Leak',
        category: 'Trade Secrets & IP',
        keywords: ['phoenix', 'wing spar', 'titanium-alloy', 'bird project', 'hydraulic circuit']
      },
      {
        id: 'sem-pii-records',
        ruleName: 'PII Records',
        category: 'Human Resources & Talent',
        keywords: ['Employee ID', 'EMP-PH-99', 'Salary: 150000', 'benefits enrollment', 'executive physical']
      },
      {
        id: 'sem-financial-forecast-mnpi',
        ruleName: 'Financial Forecast & MNPI',
        category: 'Finance & Corporate Strategy',
        keywords: ['gross margin forecast', '68.4 percent', 'Project Titan', 'EBITDA multiple']
      },
      {
        id: 'sem-global-banking-financial-pii',
        ruleName: 'Global Banking & Financial PII',
        category: 'Banking & International Settlements',
        keywords: ['corporate treasury bank account', 'settlement routing numbers']
      },
      {
        id: 'sem-national-identity-passports',
        ruleName: 'National Identity & Passports',
        category: 'Government & National ID',
        keywords: ['confidential passport scan', 'diplomatic identification record']
      },
      {
        id: 'sem-sensitive-infrastructure',
        ruleName: 'Sensitive Infrastructure',
        category: 'Infrastructure & Security',
        keywords: ['saif-production-cluster', 'kubernetes namespace']
      }
    ];

    const lower = text.toLowerCase();
    for (const rule of semanticRules) {
      for (const kw of rule.keywords) {
        const kwIdx = lower.indexOf(kw.toLowerCase());
        if (kwIdx !== -1) {
          const sentStart = Math.max(0, text.lastIndexOf('.', kwIdx) + 1);
          let sentEnd = text.indexOf('.', kwIdx);
          if (sentEnd === -1) sentEnd = text.length;
          const snippet = text.substring(sentStart, sentEnd).trim();
          const start = text.indexOf(snippet, sentStart);
          const end = start !== -1 ? (start + snippet.length) : (kwIdx + kw.length);
          list.push({
            id: rule.id,
            ruleId: rule.id,
            ruleName: rule.ruleName,
            category: rule.category,
            origin: 'SEMANTIC_ONNX',
            token: snippet,
            matched_text: snippet,
            start: start !== -1 ? start : kwIdx,
            end: end,
            placeholder: `[REDACTED: ${rule.ruleName}]`
          });
          break; // One match per category rule
        }
      }
    }

    // Fallback: If no granular regex or semantic match found, record the reasonParam
    if (list.length === 0 && reasonParam) {
      list.push({
        id: 'omni-violation',
        ruleId: 'omni-violation',
        ruleName: reasonParam,
        category: 'Security Policy',
        origin: 'REGEX_DLP',
        token: snippetParam || text.substring(0, 80) || 'Sensitive query match',
        matched_text: snippetParam || text.substring(0, 80) || 'Sensitive query match',
        start: 0,
        end: Math.min(text.length, 80),
        placeholder: '[REDACTED]'
      });
    }

    return list;
  }

  const violations = extractViolations(rawQuery);

  // ---------------------------------------------------------------------------
  // Triage State & Grouping
  // ---------------------------------------------------------------------------
  let grouped = {};
  let selectedActions = {};
  let selectedItemActions = {};
  let currentSanitizedPrompt = rawQuery;

  function escapeHTML(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function renderUI() {
    const listEl = document.getElementById('violation-list');
    if (!listEl) return;
    listEl.innerHTML = '';

    const subtitle = document.getElementById('triage-subtitle');
    if (subtitle) {
      subtitle.textContent = `SAIF Security - Composite Threat Triage: ${violations.length} policy violation(s) detected`;
    }
    const pill = document.getElementById('saif-counter-pill');
    if (pill) {
      pill.textContent = `${violations.length} Violations Detected`;
    }

    // Group violations by rule
    grouped = {};
    selectedActions = {};
    selectedItemActions = {};

    violations.forEach((v, idx) => {
      const key = v.rule_id || v.ruleId || v.id || ('rule-' + idx);
      if (!grouped[key]) {
        grouped[key] = {
          id: key,
          name: v.rule_name || v.ruleName || key,
          origin: v.origin || 'REGEX_DLP',
          category: v.category || 'Security Policy',
          placeholder: v.placeholder || '[REDACTED]',
          items: []
        };
      }
      const itemIdx = grouped[key].items.length;
      grouped[key].items.push(v);
      selectedActions[key] = 'redact';
      selectedItemActions[`${key}:${itemIdx}`] = 'redact';
    });

    Object.values(grouped).forEach(g => {
      const row = document.createElement('div');
      row.className = 'violation-row';
      row.dataset.ruleId = g.id;

      const isSemantic = g.origin === 'SEMANTIC_ONNX';
      const badgeClass = isSemantic ? 'badge-semantic' : 'badge-dlp';
      const badgeText = isSemantic ? 'Semantic' : 'DLP Regex';
      const hasMultiple = g.items.length > 1;

      let rowHTML = `
        <div class="row-main">
          <div class="row-left">
            <span class="badge ${badgeClass}">${badgeText}</span>
            <span class="rule-name">${escapeHTML(g.name)}</span>
            ${hasMultiple 
              ? `<button type="button" class="btn-accordion"><span class="accordion-arrow">▾</span> <span class="match-count">(${g.items.length} matches)</span></button>`
              : `<span class="match-count">(1 match)</span>`
            }
          </div>
          <div class="row-actions">
            <label><input type="radio" name="action-${escapeHTML(g.id)}" value="redact" checked> ${hasMultiple ? 'Redact All' : 'Redact'}</label>
            <label><input type="radio" name="action-${escapeHTML(g.id)}" value="override"> ${hasMultiple ? 'Override All' : 'Override'}</label>
          </div>
        </div>
      `;

      if (hasMultiple) {
        rowHTML += `<div class="accordion-items" id="accordion-${escapeHTML(g.id)}">`;
        g.items.forEach((item, itemIdx) => {
          const itemKey = `${g.id}:${itemIdx}`;
          const tokenSnippet = item.token || item.matched_text || item.text || '[match]';
          rowHTML += `
            <div class="sub-item-row" id="sub-item-${escapeHTML(g.id)}-${itemIdx}" data-item-idx="${itemIdx}">
              <div class="sub-item-left">
                <span class="sub-item-idx">#${itemIdx + 1}</span>
                <span class="sub-item-token"><code>${escapeHTML(tokenSnippet)}</code></span>
              </div>
              <div class="sub-item-actions">
                <label><input type="radio" name="item-action-${escapeHTML(itemKey)}" value="redact" checked> Redact</label>
                <label><input type="radio" name="item-action-${escapeHTML(itemKey)}" value="override"> Override</label>
              </div>
            </div>
          `;
        });
        rowHTML += `</div>`;
      } else {
        const singleToken = g.items[0]?.token || g.items[0]?.matched_text || g.items[0]?.text || '';
        if (singleToken && singleToken.length > 0) {
          rowHTML += `
            <div class="drawer" style="font-size: 11px; color: var(--text-muted);">
              Sample token: <code>${escapeHTML(singleToken)}</code>
            </div>
          `;
        }
      }

      row.innerHTML = rowHTML;
      listEl.appendChild(row);

      // Accordion toggle button
      if (hasMultiple) {
        const btn = row.querySelector('.btn-accordion');
        const drawer = row.querySelector('.accordion-items');
        const arrow = row.querySelector('.accordion-arrow');
        if (btn && drawer && arrow) {
          btn.addEventListener('click', (e) => {
            e.stopPropagation();
            const isCollapsed = drawer.classList.toggle('collapsed');
            arrow.textContent = isCollapsed ? '▸' : '▾';
          });
        }

        // Sub-item radio listeners
        g.items.forEach((_, itemIdx) => {
          const itemKey = `${g.id}:${itemIdx}`;
          const radios = row.querySelectorAll(`input[name="item-action-${itemKey}"]`);
          radios.forEach(r => {
            r.addEventListener('change', () => {
              selectedItemActions[itemKey] = r.value;
              updateDiffPreview();
            });
          });
        });
      }

      // Group radio listeners
      const groupRadios = row.querySelectorAll(`input[name="action-${g.id}"]`);
      groupRadios.forEach(gr => {
        gr.addEventListener('change', () => {
          selectedActions[g.id] = gr.value;
          if (hasMultiple) {
            g.items.forEach((_, itemIdx) => {
              const itemKey = `${g.id}:${itemIdx}`;
              selectedItemActions[itemKey] = gr.value;
              const subRadio = row.querySelector(`input[name="item-action-${itemKey}"][value="${gr.value}"]`);
              if (subRadio) subRadio.checked = true;
            });
          }
          updateDiffPreview();
        });
      });
    });

    updateDiffPreview();
  }

  // ---------------------------------------------------------------------------
  // Live Diff Preview Rendering
  // ---------------------------------------------------------------------------
  function updateDiffPreview() {
    const diffEl = document.getElementById('diff-preview');
    if (!diffEl) return;

    const text = rawQuery || '';
    if (!text) {
      diffEl.textContent = 'No query content to preview.';
      return;
    }

    const spans = [];
    const overrides = [];

    violations.forEach((v) => {
      const ruleId = v.rule_id || v.ruleId || v.id;
      const g = grouped[ruleId];
      const itemIdx = g ? g.items.indexOf(v) : -1;
      const itemKey = `${ruleId}:${itemIdx}`;

      let itemDecision = 'redact';
      if (itemIdx !== -1 && selectedItemActions[itemKey]) {
        itemDecision = selectedItemActions[itemKey];
      } else if (selectedActions[ruleId]) {
        itemDecision = selectedActions[ruleId];
      }

      let start = v.start;
      let end = v.end;
      const matchText = v.matched_text || v.token;

      if (matchText) {
        if (start === undefined || start < 0 || end > text.length || start >= end || text.slice(start, end) !== matchText) {
          const idx = text.indexOf(matchText);
          if (idx !== -1) {
            start = idx;
            end = idx + matchText.length;
          }
        }
      }

      if (start >= 0 && end <= text.length && start < end) {
        if (itemDecision === 'redact') {
          const mask = v.placeholder || '[REDACTED]';
          spans.push({ start, end, mask, ruleId });
        } else if (itemDecision === 'override') {
          overrides.push({ start, end, ruleId });
        }
      }
    });

    // Carve out overrides
    overrides.forEach((ov) => {
      for (let i = 0; i < spans.length; i++) {
        const sp = spans[i];
        if (sp.start <= ov.start && ov.end <= sp.end && (sp.end - sp.start) > (ov.end - ov.start)) {
          if (sp.start < ov.start) {
            sp.end = ov.start;
          } else {
            sp.start = ov.end;
          }
        }
      }
    });

    if (spans.length > 1) {
      const filtered = spans.filter(sp => !(sp.start === 0 && sp.end >= text.length));
      if (filtered.length > 0) spans.length = 0, spans.push(...filtered);
    }

    spans.sort((a, b) => a.start === b.start ? b.end - a.end : a.start - b.start);

    const merged = [];
    for (const curr of spans) {
      if (merged.length === 0) {
        merged.push(curr);
        continue;
      }
      const last = merged[merged.length - 1];
      if (curr.start >= last.start && curr.end <= last.end) continue;
      if (curr.start < last.end) {
        if (curr.end > last.end) last.end = curr.end;
        continue;
      }
      merged.push(curr);
    }

    let sanHtml = '';
    let plainSanitized = '';
    let lastIdx = 0;

    for (let i = 0; i < merged.length; i++) {
      const sp = merged[i];
      const unch = text.slice(lastIdx, sp.start);
      sanHtml += escapeHTML(unch);
      plainSanitized += unch;

      sanHtml += `<span class="masked-tag">${escapeHTML(sp.mask)}</span>`;
      plainSanitized += sp.mask;

      lastIdx = sp.end;
    }
    const tail = text.slice(lastIdx);
    sanHtml += escapeHTML(tail);
    plainSanitized += tail;

    currentSanitizedPrompt = plainSanitized;
    diffEl.innerHTML = sanHtml;
  }

  // ---------------------------------------------------------------------------
  // Batch Presets
  // ---------------------------------------------------------------------------
  const batchRedactRadio = document.getElementById('radio-batch-redact');
  const batchOverrideRadio = document.getElementById('radio-batch-override');
  const confirmDrawer = document.getElementById('saif-confirm-drawer');

  if (batchRedactRadio) {
    batchRedactRadio.addEventListener('change', () => {
      if (batchRedactRadio.checked) {
        if (confirmDrawer) confirmDrawer.style.display = 'none';
        document.querySelectorAll('input[type="radio"][value="redact"]').forEach(r => r.checked = true);
        Object.keys(selectedActions).forEach(k => selectedActions[k] = 'redact');
        Object.keys(selectedItemActions).forEach(k => selectedItemActions[k] = 'redact');
        updateDiffPreview();
      }
    });
  }

  if (batchOverrideRadio) {
    batchOverrideRadio.addEventListener('change', () => {
      if (batchOverrideRadio.checked) {
        if (confirmDrawer) confirmDrawer.style.display = 'block';
        document.querySelectorAll('input[type="radio"][value="override"]').forEach(r => r.checked = true);
        Object.keys(selectedActions).forEach(k => selectedActions[k] = 'override');
        Object.keys(selectedItemActions).forEach(k => selectedItemActions[k] = 'override');
        updateDiffPreview();
      }
    });
  }

  // ---------------------------------------------------------------------------
  // Action Handlers
  // ---------------------------------------------------------------------------
  // 1. Acknowledge & Dismiss / Return to Safety
  const btnBack = document.getElementById('btn-back');
  if (btnBack) {
    btnBack.addEventListener('click', () => {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        window.close();
      }
    });
  }

  // 2. Sanitize & Search / Apply Sanitization
  const btnMaskSearch = document.getElementById('btn-mask-search');
  if (btnMaskSearch) {
    btnMaskSearch.addEventListener('click', async () => {
      btnMaskSearch.disabled = true;
      btnMaskSearch.textContent = '🛡️ Sanitizing & Searching...';

      const maskedQuery = currentSanitizedPrompt || rawQuery;
      let maskedDest = destUrl;
      try {
        if (destUrl) {
          const u = new URL(destUrl);
          const SEARCH_PARAMS = ['q', 'query', 'p', 'search_query', 'wd', 'text', 'keyword'];
          for (const p of SEARCH_PARAMS) {
            if (u.searchParams.has(p)) {
              u.searchParams.set(p, maskedQuery);
              break;
            }
          }
          maskedDest = u.href;
        } else if (targetHost) {
          maskedDest = `https://${targetHost}/search?q=${encodeURIComponent(maskedQuery)}`;
        }
      } catch (_) {
        if (targetHost) maskedDest = `https://${targetHost}/search?q=${encodeURIComponent(maskedQuery)}`;
      }

      // Register safe override in local storage
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        try {
          const res = await new Promise(r => chrome.storage.local.get(['omniOverrides'], r));
          const existing = Array.isArray(res?.omniOverrides) ? res.omniOverrides : [];
          if (maskedQuery && !existing.includes(maskedQuery)) existing.push(maskedQuery);
          if (maskedQuery && !existing.includes(maskedQuery.trim())) existing.push(maskedQuery.trim());
          if (maskedDest && !existing.includes(maskedDest)) existing.push(maskedDest);
          await new Promise(r => chrome.storage.local.set({ omniOverrides: existing }, r));
        } catch (_) {}
      }

      // Record audit event
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        try {
          chrome.runtime.sendMessage({
            type: 'RECORD_OVERRIDE_EVENT',
            prompt: rawQuery,
            query: maskedQuery,
            dest: maskedDest,
            target: targetHost,
            reasons: violations.map(v => v.ruleName),
            triggeredRule: 'Token Sanitizer Redaction',
            riskScore: 0.1
          }, () => {});
        } catch (_) {}
      }

      if (maskedDest) {
        window.location.href = maskedDest;
      } else if (window.history.length > 1) {
        window.history.back();
      } else {
        window.close();
      }
    });
  }

  // 3. Break-Glass Override
  const btnBreakGlass = document.getElementById('btn-break-glass');
  const btnCancelOverride = document.getElementById('btn-cancel-override');
  const ackCheckbox = document.getElementById('saif-ack-checkbox');
  const btnConfirmOverride = document.getElementById('btn-confirm-override');

  if (btnBreakGlass && confirmDrawer) {
    btnBreakGlass.addEventListener('click', () => {
      confirmDrawer.style.display = 'block';
      if (batchOverrideRadio) batchOverrideRadio.checked = true;
    });
  }

  if (btnCancelOverride && confirmDrawer) {
    btnCancelOverride.addEventListener('click', () => {
      confirmDrawer.style.display = 'none';
      if (batchRedactRadio) {
        batchRedactRadio.checked = true;
        batchRedactRadio.dispatchEvent(new Event('change'));
      }
      if (ackCheckbox) ackCheckbox.checked = false;
      if (btnConfirmOverride) {
        btnConfirmOverride.disabled = true;
        btnConfirmOverride.style.background = '#713f12';
        btnConfirmOverride.style.color = '#a1a1aa';
        btnConfirmOverride.style.cursor = 'not-allowed';
      }
    });
  }

  if (ackCheckbox && btnConfirmOverride) {
    ackCheckbox.addEventListener('change', () => {
      if (ackCheckbox.checked) {
        btnConfirmOverride.disabled = false;
        btnConfirmOverride.style.background = '#f59e0b';
        btnConfirmOverride.style.color = '#000';
        btnConfirmOverride.style.cursor = 'pointer';
      } else {
        btnConfirmOverride.disabled = true;
        btnConfirmOverride.style.background = '#713f12';
        btnConfirmOverride.style.color = '#a1a1aa';
        btnConfirmOverride.style.cursor = 'not-allowed';
      }
    });

    btnConfirmOverride.addEventListener('click', async () => {
      btnConfirmOverride.disabled = true;
      btnConfirmOverride.textContent = 'Authorizing & Redirecting...';

      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        try {
          await new Promise(r => {
            chrome.runtime.sendMessage({
              type: 'RECORD_OVERRIDE_EVENT',
              prompt: rawQuery || reasonParam || 'Omnibox Navigation Break-Glass',
              query: rawQuery,
              dest: destUrl,
              target: targetHost,
              reasons: [reasonParam || 'Omnibox Navigation Override'],
              triggeredRule: reasonParam || 'Omnibox Policy Violation',
              riskScore: 0.95
            }, r);
          });
        } catch (_) {}
      }

      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        try {
          const res = await new Promise(r => chrome.storage.local.get(['omniOverrides'], r));
          const existing = Array.isArray(res?.omniOverrides) ? res.omniOverrides : [];
          if (rawQuery && !existing.includes(rawQuery)) existing.push(rawQuery);
          if (rawQuery && !existing.includes(rawQuery.trim())) existing.push(rawQuery.trim());
          if (targetHost && !existing.includes(targetHost)) existing.push(targetHost);
          if (destUrl && !existing.includes(destUrl)) existing.push(destUrl);
          await new Promise(r => chrome.storage.local.set({ omniOverrides: existing }, r));
        } catch (_) {}
      }

      if (destUrl) {
        window.location.href = destUrl;
      } else if (window.history.length > 1) {
        window.history.back();
      } else {
        window.close();
      }
    });
  }

  // ---------------------------------------------------------------------------
  // Keyboard Shortcuts
  // ---------------------------------------------------------------------------
  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      if (btnBack) btnBack.click();
    } else if (e.key === 'Enter' || e.key === 'r' || e.key === 'R') {
      if (document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA') {
        if (btnMaskSearch && !btnMaskSearch.disabled) btnMaskSearch.click();
      }
    } else if (e.key === 'b' || e.key === 'B') {
      if (document.activeElement?.tagName !== 'INPUT' && document.activeElement?.tagName !== 'TEXTAREA') {
        if (batchOverrideRadio) {
          batchOverrideRadio.checked = true;
          batchOverrideRadio.dispatchEvent(new Event('change'));
        }
      }
    }
  });

  // Mount UI
  renderUI();
});
