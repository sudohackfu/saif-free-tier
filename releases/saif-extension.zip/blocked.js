// SAIF Edge Interceptor — Blocked Page Controller (Manifest V3 CSP Compliant)
document.addEventListener('DOMContentLoaded', () => {
  const params = new URLSearchParams(window.location.search);
  const reason = params.get('reason');
  const target = params.get('target');
  const query = params.get('snippet') || params.get('query');
  const dest = params.get('dest') || (target && query ? (target.startsWith('http') ? target : `https://${target}/search?q=${encodeURIComponent(query)}`) : '');

  if (reason) {
    const reasonEl = document.getElementById('violation-reason');
    if (reasonEl) reasonEl.textContent = reason;
  }
  if (target) {
    const targetEl = document.getElementById('target-host');
    if (targetEl) targetEl.textContent = target;
  }
  if (query) {
    const qRow = document.getElementById('query-row');
    const qEl = document.getElementById('query-snippet');
    if (qRow) qRow.style.display = 'block';
    if (qEl) qEl.textContent = query;
  }

  // Return to Safety Button
  const btnBack = document.getElementById('btn-back');
  if (btnBack) {
    btnBack.addEventListener('click', () => {
      if (window.history.length > 1) {
        window.history.back();
      } else {
        window.close();
      }
    });
  }

  // Mask & Search Button (Auto-sanitizes query and redirects to search engine)
  const btnMaskSearch = document.getElementById('btn-mask-search');
  if (btnMaskSearch) {
    const canSanitize = (typeof canSanitizePrompt === 'function')
      ? canSanitizePrompt(query || '')
      : (typeof window.rulesCatalog?.canSanitizePrompt === 'function' ? window.rulesCatalog.canSanitizePrompt(query || '') : null);

    if (canSanitize && !canSanitize.canSanitize) {
      btnMaskSearch.style.display = 'none';
    } else {
      btnMaskSearch.addEventListener('click', async () => {
        btnMaskSearch.disabled = true;
        btnMaskSearch.textContent = 'Masking & Searching...';

        const sanitizeFn = (typeof sanitizePrompt === 'function')
          ? sanitizePrompt
          : (typeof window.rulesCatalog?.sanitizePrompt === 'function' ? window.rulesCatalog.sanitizePrompt : null);

        const sanitizeRes = sanitizeFn ? sanitizeFn(query || '') : { sanitized: query || '', replacementsCount: 1 };
        const maskedQuery = sanitizeRes.sanitized;

        let maskedDest = dest;
        try {
          if (dest) {
            const u = new URL(dest);
            const SEARCH_PARAMS = ['q', 'query', 'p', 'search_query', 'wd', 'text', 'keyword'];
            for (const p of SEARCH_PARAMS) {
              if (u.searchParams.has(p)) {
                u.searchParams.set(p, maskedQuery);
                break;
              }
            }
            maskedDest = u.href;
          } else if (target) {
            maskedDest = `https://${target}/search?q=${encodeURIComponent(maskedQuery)}`;
          }
        } catch (_) {
          if (target) maskedDest = `https://${target}/search?q=${encodeURIComponent(maskedQuery)}`;
        }

        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          try {
            const res = await new Promise((resolve) => chrome.storage.local.get(['omniOverrides'], resolve));
            const existing = Array.isArray(res?.omniOverrides) ? res.omniOverrides : [];
            if (maskedQuery && !existing.includes(maskedQuery)) existing.push(maskedQuery);
            if (maskedQuery && !existing.includes(maskedQuery.trim())) existing.push(maskedQuery.trim());
            if (maskedDest && !existing.includes(maskedDest)) existing.push(maskedDest);
            await new Promise((resolve) => chrome.storage.local.set({ omniOverrides: existing }, resolve));
          } catch (_) {}
        }

        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
          try {
            chrome.runtime.sendMessage({
              type: 'RECORD_OVERRIDE_EVENT',
              prompt: query,
              query: maskedQuery,
              dest: maskedDest,
              target: target,
              reasons: [`Sanitized ${sanitizeRes.replacementsCount} secret token(s)`],
              triggeredRule: 'Token Sanitizer Redaction',
              riskScore: 0.1
            }, () => {});
          } catch (_) {}
        }

        if (maskedDest) {
          window.location.href = maskedDest;
        } else if (window.history.length > 1) {
          window.history.back();
        } else {
          window.close();
        }
      });
    }
  }

  // Break-Glass Drawer Controls
  const btnBreakGlass = document.getElementById('btn-break-glass');
  const confirmDrawer = document.getElementById('saif-confirm-drawer');
  const btnCancelOverride = document.getElementById('btn-cancel-override');
  const ackCheckbox = document.getElementById('saif-ack-checkbox');
  const btnConfirmOverride = document.getElementById('btn-confirm-override');

  if (btnBreakGlass && confirmDrawer) {
    btnBreakGlass.addEventListener('click', () => {
      confirmDrawer.style.display = 'block';
    });
  }

  if (btnCancelOverride && confirmDrawer) {
    btnCancelOverride.addEventListener('click', () => {
      confirmDrawer.style.display = 'none';
      if (ackCheckbox) ackCheckbox.checked = false;
      if (btnConfirmOverride) {
        btnConfirmOverride.disabled = true;
        btnConfirmOverride.style.background = '#713f12';
        btnConfirmOverride.style.color = '#a1a1aa';
        btnConfirmOverride.style.cursor = 'not-allowed';
      }
    });
  }

  if (ackCheckbox && btnConfirmOverride) {
    ackCheckbox.addEventListener('change', () => {
      if (ackCheckbox.checked) {
        btnConfirmOverride.disabled = false;
        btnConfirmOverride.style.background = '#f59e0b';
        btnConfirmOverride.style.color = '#000';
        btnConfirmOverride.style.cursor = 'pointer';
      } else {
        btnConfirmOverride.disabled = true;
        btnConfirmOverride.style.background = '#713f12';
        btnConfirmOverride.style.color = '#a1a1aa';
        btnConfirmOverride.style.cursor = 'not-allowed';
      }
    });

    btnConfirmOverride.addEventListener('click', async () => {
      btnConfirmOverride.disabled = true;
      btnConfirmOverride.textContent = 'Authorizing & Redirecting...';

      // 1. Record override event to background audit history and await worker memory synchronization
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        try {
          await new Promise((resolve) => {
            chrome.runtime.sendMessage({
              type: 'RECORD_OVERRIDE_EVENT',
              prompt: query || reason || 'Omnibox Navigation Break-Glass',
              query: query,
              dest: dest,
              target: target,
              reasons: [reason || 'Omnibox Navigation Override'],
              triggeredRule: reason || 'Omnibox Policy Violation',
              riskScore: 0.95
            }, (res) => resolve(res));
          });
        } catch (_) {}
      }

      // 2. Add query, target, and full destination to omniOverrides in storage so inspectDocumentUrl won't re-block
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        try {
          const res = await new Promise((resolve) => chrome.storage.local.get(['omniOverrides'], resolve));
          const existing = Array.isArray(res?.omniOverrides) ? res.omniOverrides : [];
          if (query && !existing.includes(query)) existing.push(query);
          if (query && !existing.includes(query.trim())) existing.push(query.trim());
          if (target && !existing.includes(target)) existing.push(target);
          if (dest && !existing.includes(dest)) existing.push(dest);
          await new Promise((resolve) => chrome.storage.local.set({ omniOverrides: existing }, resolve));
        } catch (_) {}
      }

      // 3. Navigate to destination or history back
      if (dest) {
        window.location.href = dest;
      } else if (window.history.length > 1) {
        window.history.back();
      } else {
        window.close();
      }
    });
  }
});
