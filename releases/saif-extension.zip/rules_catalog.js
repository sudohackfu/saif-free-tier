// SAIF Rules Catalog - Standard DLP Patterns & Categories
// Compatible with Chrome Extension Service Worker, Content Scripts, and Node.js environments

// Canonical 8 Category Taxonomy (4 Presidio DLP + 4 Semantic Domains)
var RULE_CATEGORIES = [
  { id: 'secrets', name: 'Secrets & Credentials', icon: '🔑', description: 'Cloud access keys, developer tokens, database URIs, and AI provider API keys' },
  { id: 'pii_national_id', name: 'PII: National ID', icon: '🪪', description: 'Social Security Numbers, passports, driver licenses, ITIN, and national identifiers' },
  { id: 'pii_financial', name: 'PII: Financial', icon: '💳', description: 'Payment card numbers, banking identifiers, crypto wallets, and tax entity numbers' },
  { id: 'pii_healthcare', name: 'PII: Healthcare', icon: '🏥', description: 'HIPAA Medical Record Numbers, prescriber IDs, and DEA registration codes' },
  { id: 'sem_trade_secrets', name: 'Trade Secrets & Code', icon: '🛡️', description: 'Proprietary source code, algorithmic architectures, and strategic roadmaps' },
  { id: 'sem_financial_mnpi', name: 'Financial MNPI', icon: '📈', description: 'Material non-public information, earnings forecasts, and M&A transaction terms' },
  { id: 'sem_hr_pii', name: 'HR & Internal PII', icon: '👥', description: 'Employee performance evaluations, compensation bands, and personnel records' },
  { id: 'sem_healthcare', name: 'Clinical & Health Data', icon: '🏥', description: 'Clinical diagnostic findings, medical treatment histories, and patient disclosures' }
];

var PRESIDIO_CATEGORIES = RULE_CATEGORIES;
var LEGACY_CATEGORIES = RULE_CATEGORIES;

var LEGACY_CATEGORY_MAP = {
  'cloud': 'secrets',
  'developer': 'secrets',
  'database': 'secrets',
  'ai_secrets': 'secrets',
  'pii': 'pii_national_id',
  'semantic': 'sem_trade_secrets'
};

var STANDARD_RULES = [
  {
    id: 'pat-aws-key',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'cloud',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'AWS Access Key ID',
    severity: 'Critical',
    regexStr: '\\bAKIA[0-9A-Z]{16}\\b',
    minEntropy: 2.8,
    placeholder: 'AWS_KEY',
    description: 'Amazon Web Services IAM access key identifier (AKIA)',
    reason: 'Exposed AWS Access Key ID (AKIA...)',
    enabledByDefault: true
  },
  {
    id: 'pat-aws-temp-key',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'cloud',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Temporary AWS Access Key',
    severity: 'Critical',
    regexStr: '\\bASIA[0-9A-Z]{16}\\b',
    minEntropy: 2.8,
    placeholder: 'AWS_TEMP_KEY',
    description: 'Temporary AWS STS session token identifier (ASIA)',
    reason: 'Exposed Temporary AWS Access Key (ASIA...)',
    enabledByDefault: true
  },
  {
    id: 'pat-gcp-key',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'cloud',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Google Cloud API Key',
    severity: 'High',
    regexStr: '\\bAIza[0-9A-Za-z_\\-]{35}\\b',
    minEntropy: 3.0,
    placeholder: 'GCP_KEY',
    description: 'Google Cloud Platform public service and API key',
    reason: 'Exposed Google Cloud API Key (AIza...)',
    enabledByDefault: true
  },
  {
    id: 'pat-azure-conn',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'cloud',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Azure Storage Connection String',
    severity: 'Critical',
    regexStr: 'DefaultEndpointsProtocol=https;AccountName=[^;]+;AccountKey=[^;\\s]+(?:;[a-zA-Z0-9]+=[^;\\s]+)*',
    placeholder: 'AZURE_CONN',
    description: 'Azure Storage account connection string with account key',
    reason: 'Exposed Azure Storage Connection String',
    enabledByDefault: true
  },
  {
    id: 'pat-gh-token',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'developer',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'GitHub Personal Access Token',
    severity: 'Critical',
    regexStr: '\\bgh[pousr]_[A-Za-z0-9_]{36,255}\\b',
    minEntropy: 2.8,
    placeholder: 'GITHUB_TOKEN',
    description: 'Classic and fine-grained GitHub personal access tokens',
    reason: 'Exposed GitHub Personal Access Token',
    enabledByDefault: true
  },
  {
    id: 'pat-gl-token',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'developer',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'GitLab Personal Access Token',
    severity: 'Critical',
    regexStr: '\\bglpat-[0-9a-zA-Z_\\-]{20,255}\\b',
    minEntropy: 2.8,
    placeholder: 'GITLAB_TOKEN',
    description: 'GitLab personal and project access token',
    reason: 'Exposed GitLab Personal Access Token',
    enabledByDefault: true
  },
  {
    id: 'pat-npm-token',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'developer',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'NPM Access Token',
    severity: 'Critical',
    regexStr: '\\bnpm_[A-Za-z0-9]{36}\\b',
    minEntropy: 2.8,
    placeholder: 'NPM_TOKEN',
    description: 'NPM package publisher automation token',
    reason: 'Exposed NPM Access Token',
    enabledByDefault: true
  },
  {
    id: 'pat-private-key',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'developer',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Private Cryptographic Key',
    severity: 'Critical',
    regexStr: '-----BEGIN (?:[A-Z0-9_-]+ )?PRIVATE KEY(?: BLOCK)?-----[\\s\\S]*?-----END (?:[A-Z0-9_-]+ )?PRIVATE KEY(?: BLOCK)?-----|-----BEGIN (?:[A-Z0-9_-]+ )?PRIVATE KEY(?: BLOCK)?-----[^\\r\\n]*',
    placeholder: 'PRIVATE_KEY',
    description: 'Cryptographic private key block header and body',
    reason: 'Exposed Private Cryptographic Key',
    enabledByDefault: true
  },
  {
    id: 'pat-slack-token',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'developer',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Slack Bot and User Token',
    severity: 'Critical',
    regexStr: '\\bxox[baprs]-[0-9]{10,13}-[0-9]{10,13}[A-Za-z0-9_-]*\\b',
    minEntropy: 2.8,
    placeholder: 'SLACK_TOKEN',
    description: 'Slack workspace bot and user authentication token',
    reason: 'Exposed Slack Bot or User Token',
    enabledByDefault: true
  },
  {
    id: 'pat-slack-webhook',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'developer',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Slack Incoming Webhook URL',
    severity: 'High',
    regexStr: '\\bhttps:\\/\\/hooks\\.slack\\.com\\/services\\/T[A-Za-z0-9_]{8,}\\/B[A-Za-z0-9_]{8,}\\/[A-Za-z0-9_]{24}\\b',
    placeholder: 'SLACK_WEBHOOK',
    description: 'Direct Slack incoming webhook endpoint URL for workspace messaging',
    reason: 'Exposed Slack Incoming Webhook URL',
    enabledByDefault: true
  },
  {
    id: 'pat-hashicorp-vault',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'developer',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'HashiCorp Vault Token',
    severity: 'Critical',
    regexStr: '\\bhv[sb]\\.[A-Za-z0-9_-]{24,}\\b',
    minEntropy: 3.0,
    placeholder: 'VAULT_TOKEN',
    description: 'HashiCorp Vault client and service authentication token',
    reason: 'Exposed HashiCorp Vault Token',
    enabledByDefault: true
  },
  {
    id: 'pat-pypi-token',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'developer',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'PyPI Upload Token',
    severity: 'Critical',
    regexStr: '\\bpypi-AgEIcHlwaS5vcmc[A-Za-z0-9_-]{50,}\\b',
    minEntropy: 3.0,
    placeholder: 'PYPI_TOKEN',
    description: 'Python Package Index (PyPI) package publishing API token',
    reason: 'Exposed PyPI Upload API Token',
    enabledByDefault: true
  },
  {
    id: 'pat-db-uri',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'database',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Database Connection URI',
    severity: 'Critical',
    regexStr: '(?:postgres|postgresql|mysql|mongodb(?:\\+srv)?|redis):\\/\\/[^\\s"\']+',
    placeholder: 'DB_URI',
    description: 'Database connection URI with embedded authentication credentials',
    reason: 'Exposed Database Connection URI with Credentials',
    enabledByDefault: true
  },
  {
    id: 'pat-jwt-token',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'developer',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'JSON Web Token',
    severity: 'Medium',
    regexStr: 'eyJ[A-Za-z0-9-_=]+\\.[A-Za-z0-9-_=]+\\.[A-Za-z0-9-_=]+',
    placeholder: 'JWT_TOKEN',
    description: 'Base64-encoded signed bearer authorization token',
    reason: 'Exposed JSON Web Token (JWT)',
    enabledByDefault: true
  },
  {
    id: 'pat-stripe-key',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'developer',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Stripe Live API Key',
    severity: 'Critical',
    regexStr: '\\bsk_live_[0-9a-zA-Z]{24,100}\\b',
    minEntropy: 3.0,
    placeholder: 'STRIPE_KEY',
    description: 'Live production payment processing secret key for Stripe',
    reason: 'Exposed Stripe Live API Key',
    enabledByDefault: true
  },
  {
    id: 'pat-ssn',
    category: 'pii_national_id',
    presidioCategory: 'pii_national_id',
    legacyCategory: 'pii',
    engineType: 'cpag_algorithmic',
    engines: ["CPAG 2.0", "Triage"],
    engineSpec: 'Algorithmic Structural Validator',
    cpagSpec: 'Structural Range Validator',
    name: 'US Social Security Number',
    severity: 'High',
    regexStr: '\\b\\d{3}[- ]\\d{2}[- ]\\d{4}\\b',
    placeholder: 'SSN',
    description: 'US Social Security Number with area and group structural verification',
    reason: 'Exposed US Social Security Number (SSN)',
    enabledByDefault: true
  },
  {
    id: 'pat-credit-card',
    category: 'pii_financial',
    presidioCategory: 'pii_financial',
    legacyCategory: 'pii',
    engineType: 'cpag_algorithmic',
    engines: ["CPAG 2.0", "Triage"],
    engineSpec: 'Algorithmic Mod-10 Checksum Validator',
    cpagSpec: 'Mod-10 Checksum Validator',
    name: 'Credit Card Number',
    severity: 'High',
    regexStr: '\\b(?:4[0-9]{3}[ -]?[0-9]{4}[ -]?[0-9]{4}[ -]?[0-9]{4}|5[1-5][0-9]{2}[ -]?[0-9]{4}[ -]?[0-9]{4}[ -]?[0-9]{4}|3[47][0-9]{2}[ -]?[0-9]{6}[ -]?[0-9]{5}|6(?:011|5[0-9]{2})[ -]?[0-9]{4}[ -]?[0-9]{4}[ -]?[0-9]{4}|(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13}|6(?:011|5[0-9]{2})[0-9]{12}))\\b',
    placeholder: 'CREDIT_CARD',
    description: 'Major payment card number with Luhn Mod-10 mathematical validation',
    reason: 'Exposed Credit Card Number',
    enabledByDefault: true
  },
  {
    id: 'pat-openai-key',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'ai_secrets',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'OpenAI API Key',
    severity: 'Critical',
    regexStr: '\\b(?:sk-(?!ant-)(?:proj-|admin-)?[a-zA-Z0-9_\\-]{32,64})\\b',
    minEntropy: 3.0,
    placeholder: 'OPENAI_KEY',
    description: 'OpenAI platform and project-scoped developer API key',
    reason: 'Exposed OpenAI API Key',
    enabledByDefault: true
  },
  {
    id: 'pat-anthropic-key',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'ai_secrets',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Anthropic API Key',
    severity: 'Critical',
    regexStr: '\\bsk-ant-[a-zA-Z0-9_\\-]{32,64}\\b',
    minEntropy: 3.0,
    placeholder: 'ANTHROPIC_KEY',
    description: 'Anthropic Claude developer API key',
    reason: 'Exposed Anthropic API Key',
    enabledByDefault: true
  },
  {
    id: 'pat-hf-token',
    category: 'secrets',
    presidioCategory: 'secrets',
    legacyCategory: 'ai_secrets',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Hugging Face Access Token',
    severity: 'High',
    regexStr: '\\bhf_[a-zA-Z0-9]{34,64}\\b',
    minEntropy: 3.0,
    placeholder: 'HF_TOKEN',
    description: 'Hugging Face model hub authentication token',
    reason: 'Exposed Hugging Face Access Token',
    enabledByDefault: true
  },
  {
    id: 'pat-es-dni',
    category: 'pii_national_id',
    presidioCategory: 'pii_national_id',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Spanish National ID (DNI)',
    severity: 'High',
    regexStr: '\\b[0-9]{8}[TRWAGMYFPDXBNJZSQVHLCKEtrwagmyfpdxbnjzsqvhlcke]\\b',
    placeholder: 'ES_DNI',
    description: 'Spanish National Identity Document (DNI)',
    reason: 'Exposed Spanish National ID (DNI)',
    enabledByDefault: true
  },
  {
    id: 'pat-es-nie',
    category: 'pii_national_id',
    presidioCategory: 'pii_national_id',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Spanish Foreigner ID (NIE)',
    severity: 'High',
    regexStr: '\\b[XYZxyz][0-9]{7}[TRWAGMYFPDXBNJZSQVHLCKEtrwagmyfpdxbnjzsqvhlcke]\\b',
    placeholder: 'ES_NIE',
    description: 'Spanish Foreigner Identification Number (NIE)',
    reason: 'Exposed Spanish Foreigner ID (NIE)',
    enabledByDefault: true
  },
  {
    id: 'pat-it-cf',
    category: 'pii_national_id',
    presidioCategory: 'pii_national_id',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Italian Fiscal Code (Codice Fiscale)',
    severity: 'High',
    regexStr: '\\b[A-Z]{6}[0-9]{2}[A-EHLMPR-T][0-9]{2}[A-Z][0-9]{3}[A-Z]\\b',
    ignoreCase: true,
    placeholder: 'IT_CF',
    description: 'Italian Tax Code (Codice Fiscale)',
    reason: 'Exposed Italian Fiscal Code (Codice Fiscale)',
    enabledByDefault: true
  },
  {
    id: 'pat-in-pan',
    category: 'pii_national_id',
    presidioCategory: 'pii_national_id',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Indian Permanent Account Number (PAN)',
    severity: 'High',
    regexStr: '\\b[A-Z]{3}[PCHFATBLJG][A-Z][0-9]{4}[A-Z]\\b',
    ignoreCase: true,
    placeholder: 'IN_PAN',
    description: 'Indian Income Tax Permanent Account Number (PAN)',
    reason: 'Exposed Indian Permanent Account Number (PAN)',
    enabledByDefault: true
  },
  {
    id: 'pat-in-aadhaar',
    category: 'pii_national_id',
    presidioCategory: 'pii_national_id',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Indian Aadhaar Unique Identity',
    severity: 'High',
    regexStr: '\\b[2-9][0-9]{3}[ -]?[0-9]{4}[ -]?[0-9]{4}\\b',
    placeholder: 'IN_AADHAAR',
    description: 'Indian 12-digit Aadhaar unique identity number',
    reason: 'Exposed Indian Aadhaar Unique Identity',
    enabledByDefault: true
  },
  {
    id: 'pat-fr-nir',
    category: 'pii_national_id',
    presidioCategory: 'pii_national_id',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'French Social Security (NIR)',
    severity: 'High',
    regexStr: '\\b[12][0-9]{2}(?:0[1-9]|1[0-2]|2[0-9])(?:[0-9]{2}|2[ABab])[0-9]{3}[0-9]{3}(?:[ -]?[0-9]{2})\\b',
    placeholder: 'FR_NIR',
    description: 'French National Social Security and Identification Number (NIR)',
    reason: 'Exposed French Social Security Number (NIR)',
    enabledByDefault: true
  },
  {
    id: 'pat-de-tax',
    category: 'pii_national_id',
    presidioCategory: 'pii_national_id',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'German Tax Identification (Steuer-ID)',
    severity: 'High',
    regexStr: '\\b[1-9][0-9]{10}\\b',
    placeholder: 'DE_STEUER_ID',
    description: 'German 11-digit Federal Tax Identification Number (Steuer-ID)',
    reason: 'Exposed German Tax ID (Steuer-ID)',
    enabledByDefault: true
  },
  {
    id: 'pat-uk-nino',
    category: 'pii_national_id',
    presidioCategory: 'pii_national_id',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'UK National Insurance Number (NINO)',
    severity: 'High',
    regexStr: '\\b[A-CEGHJ-PR-TW-Z][A-CEGHJ-NPR-TW-Z][0-9]{6}[A-D]\\b',
    ignoreCase: true,
    placeholder: 'UK_NINO',
    description: 'UK National Insurance Number (NINO)',
    reason: 'Exposed UK National Insurance Number (NINO)',
    enabledByDefault: true
  },
  {
    id: 'pat-ca-sin',
    category: 'pii_national_id',
    presidioCategory: 'pii_national_id',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Canadian Social Insurance Number (SIN)',
    severity: 'High',
    regexStr: '\\b[1-79][0-9]{2}[ -]?[0-9]{3}[ -]?[0-9]{3}\\b',
    placeholder: 'CA_SIN',
    description: 'Canadian 9-digit Social Insurance Number (SIN)',
    reason: 'Exposed Canadian Social Insurance Number (SIN)',
    enabledByDefault: true
  },
  {
    id: 'pat-sg-nric',
    category: 'pii_national_id',
    presidioCategory: 'pii_national_id',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Singapore NRIC / FIN',
    severity: 'High',
    regexStr: '\\b[STFGM][0-9]{7}[A-Z]\\b',
    ignoreCase: true,
    placeholder: 'SG_NRIC',
    description: 'Singapore National Registration Identity Card / FIN number',
    reason: 'Exposed Singapore NRIC/FIN',
    enabledByDefault: true
  },
  {
    id: 'pat-br-cpf',
    category: 'pii_national_id',
    presidioCategory: 'pii_national_id',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Brazilian CPF Identifier',
    severity: 'High',
    regexStr: '\\b[0-9]{3}\\.?[0-9]{3}\\.?[0-9]{3}-?[0-9]{2}\\b',
    placeholder: 'BR_CPF',
    description: 'Brazilian Individual Taxpayer Registry (CPF) identification',
    reason: 'Exposed Brazilian CPF Identifier',
    enabledByDefault: true
  },
  {
    id: 'pat-au-tfn',
    category: 'pii_national_id',
    presidioCategory: 'pii_national_id',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Australian Tax File Number (TFN)',
    severity: 'High',
    regexStr: '\\b[0-9]{3}[ -]?[0-9]{3}[ -]?[0-9]{2,3}\\b',
    placeholder: 'AU_TFN',
    description: 'Australian Tax File Number (TFN)',
    reason: 'Exposed Australian Tax File Number (TFN)',
    enabledByDefault: true
  },
  {
    id: 'pat-phone-e164',
    category: 'pii_national_id',
    presidioCategory: 'pii_national_id',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'International E.164 Telephone Number',
    severity: 'Medium',
    regexStr: '\\+[1-9]\\d{1,14}\\b',
    placeholder: 'PHONE_E164',
    description: 'International E.164 formatted telephone number',
    reason: 'Exposed International Telephone Number (E.164)',
    enabledByDefault: true
  },
  {
    id: 'pat-us-dea',
    category: 'pii_healthcare',
    presidioCategory: 'pii_healthcare',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'US DEA Registration Number',
    severity: 'Critical',
    regexStr: '\\b[A-Z]{2}[0-9]{7}\\b',
    ignoreCase: true,
    placeholder: 'US_DEA',
    description: 'US Drug Enforcement Administration registration number',
    reason: 'Exposed US DEA Registration Number',
    enabledByDefault: true
  },
  {
    id: 'pat-crypto-btc',
    category: 'pii_financial',
    presidioCategory: 'pii_financial',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Bitcoin Cryptocurrency Address',
    severity: 'High',
    regexStr: '\\b(?:[13][a-km-zA-HJ-NP-Z1-9]{25,34}|bc1[02-9ac-hj-np-z]{11,87})\\b',
    placeholder: 'CRYPTO_BTC',
    description: 'Bitcoin mainnet cryptocurrency wallet address (legacy and segwit)',
    reason: 'Exposed Bitcoin Cryptocurrency Address',
    enabledByDefault: true
  },
  {
    id: 'pat-crypto-eth',
    category: 'pii_financial',
    presidioCategory: 'pii_financial',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'Ethereum EVM Cryptocurrency Address',
    severity: 'High',
    regexStr: '\\b0x[a-fA-F0-9]{40}\\b',
    placeholder: 'CRYPTO_ETH',
    description: 'Ethereum and EVM-compatible hexadecimal wallet address',
    reason: 'Exposed Ethereum EVM Cryptocurrency Address',
    enabledByDefault: true
  },
  {
    id: 'pat-us-ein',
    category: 'pii_financial',
    presidioCategory: 'pii_financial',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'US Employer Identification Number (EIN)',
    severity: 'High',
    regexStr: '\\b[0-9]{2}-[0-9]{7}\\b',
    placeholder: 'US_EIN',
    description: 'US Employer Identification Number (EIN) for business entities',
    reason: 'Exposed US Employer Identification Number (EIN)',
    enabledByDefault: true
  },
  {
    id: 'pat-eu-vat',
    category: 'pii_financial',
    presidioCategory: 'pii_financial',
    engineType: 'dlp_cpag',
    engines: ["DLP", "CPAG 2.0"],
    engineSpec: 'Regex Pattern Matcher',
    cpagSpec: 'Format & Checksum Verification',
    name: 'European VAT Registration Number',
    severity: 'High',
    regexStr: '\\b(?:ATU[0-9]{8}|BE[01][0-9]{9}|BG[0-9]{9,10}|CY[0-9]{8}[A-Z]|CZ[0-9]{8,10}|DE[0-9]{9}|DK[0-9]{8}|EE[0-9]{9}|EL[0-9]{9}|ES[A-Z0-9][0-9]{7}[A-Z0-9]|FI[0-9]{8}|FR[A-Z0-9]{2}[0-9]{9}|HR[0-9]{11}|HU[0-9]{8}|IE[0-9]{7}[A-W][A-I]?|IT[0-9]{11}|LT(?:[0-9]{9}|[0-9]{12})|LU[0-9]{8}|LV[0-9]{11}|MT[0-9]{8}|NL[0-9]{9}B[0-9]{2}|PL[0-9]{10}|PT[0-9]{9}|RO[0-9]{2,10}|SE[0-9]{12}|SI[0-9]{8}|SK[0-9]{10})\\b',
    ignoreCase: true,
    placeholder: 'EU_VAT',
    description: 'European Union Member State VAT registration number',
    reason: 'Exposed European VAT Registration Number',
    enabledByDefault: true
  },
  {
    id: 'sem-trade-secrets',
    category: 'sem_trade_secrets',
    presidioCategory: 'sem_trade_secrets',
    legacyCategory: 'semantic',
    engineType: 'neural_onnx',
    engines: ["Neural", "Triage"],
    engineSpec: 'On-Device Neural Semantic Judge',
    cpagSpec: 'Contextual Prototype Similarity Evaluation',
    name: 'Engineering Trade Secrets & Source Code',
    severity: 'Critical',
    regexStr: '',
    placeholder: 'TRADE_SECRET_RISK',
    description: 'On-device neural embedding analysis evaluating prompts against proprietary trade secrets, unreleased hardware, and sensitive source code prototypes',
    reason: 'Detected Proprietary Engineering Trade Secret / Source Code',
    enabledByDefault: true
  },
  {
    id: 'sem-financial-mnpi',
    category: 'sem_financial_mnpi',
    presidioCategory: 'sem_financial_mnpi',
    engineType: 'neural_onnx',
    engines: ["Neural", "Triage"],
    engineSpec: 'On-Device Neural Semantic Judge',
    cpagSpec: 'Contextual Prototype Similarity Evaluation',
    name: 'Financial Forecasts & MNPI',
    severity: 'Critical',
    regexStr: '',
    placeholder: 'MNPI_RISK',
    description: 'On-device neural evaluation detecting pre-announcement financial metrics, executive earnings guidance, and confidential M&A transaction terms',
    reason: 'Detected Material Non-Public Financial Information (MNPI)',
    enabledByDefault: true
  },
  {
    id: 'sem-hr-pii',
    category: 'sem_hr_pii',
    presidioCategory: 'sem_hr_pii',
    engineType: 'neural_onnx',
    engines: ["Neural", "Triage"],
    engineSpec: 'On-Device Neural Semantic Judge',
    cpagSpec: 'Contextual Prototype Similarity Evaluation',
    name: 'Employee Compensation & Internal PII',
    severity: 'High',
    regexStr: '',
    placeholder: 'HR_PII_RISK',
    description: 'On-device neural evaluation detecting non-public executive salary structures, confidential performance ratings, and internal employee rosters',
    reason: 'Detected Confidential HR & Compensation Data',
    enabledByDefault: true
  },
  {
    id: 'sem-healthcare',
    category: 'sem_healthcare',
    presidioCategory: 'sem_healthcare',
    engineType: 'neural_onnx',
    engines: ["Neural", "Triage"],
    engineSpec: 'On-Device Neural Semantic Judge',
    cpagSpec: 'Contextual Prototype Similarity Evaluation',
    name: 'Clinical Diagnostic & Health Records',
    severity: 'Critical',
    regexStr: '',
    placeholder: 'HEALTHCARE_RISK',
    description: 'On-device neural evaluation detecting patient diagnostic pathology summaries, clinical treatment plans, and protected health information',
    reason: 'Detected Clinical Diagnostic / Patient Health Record',
    enabledByDefault: true
  }
];

// Compile regex instances lazily/safely
function compileRuleRegex(rule) {
  if (!rule || !rule.regexStr) return null;
  var flags = rule.ignoreCase ? 'gi' : 'g';
  var pattern = rule.regexStr;
  if (pattern.indexOf('(?i)') === 0) {
    pattern = pattern.substring(4);
    flags = 'gi';
  }
  return new RegExp(pattern, flags);
}

var compiledRules = STANDARD_RULES.filter(r => r.regexStr).map(r => ({
  ...r,
  regex: compileRuleRegex(r)
}));

// Shannon Entropy Calculation: H = -sum(p * log2(p))
function calculateShannonEntropy(str) {
  if (!str || typeof str !== 'string' || str.length === 0) return 0;
  const freq = {};
  for (let i = 0; i < str.length; i++) {
    const ch = str[i];
    freq[ch] = (freq[ch] || 0) + 1;
  }
  let entropy = 0;
  const len = str.length;
  for (const ch in freq) {
    const p = freq[ch] / len;
    entropy -= p * Math.log2(p);
  }
  return entropy;
}

// Canonical Public Test Credential Whitelist
var PUBLIC_TEST_CREDENTIALS = (typeof PUBLIC_TEST_CREDENTIALS !== 'undefined') ? PUBLIC_TEST_CREDENTIALS : new Set([
  'AKIAIOSFODNN7EXAMPLE',
  'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
  '000-00-0000',
  '0000-00-00-0000',
  '0000-0000-0000-0000'
]);

function isPublicTestCredential(token) {
  if (!token || typeof token !== 'string') return false;
  if (PUBLIC_TEST_CREDENTIALS.has(token)) return true;
  // Standard test prefixes or pure repeated dummy fixtures
  if (/^sk-(?:proj-)?test-[a-zA-Z0-9_-]+$/i.test(token)) return true;
  if (/^ghp_0{20,}$/.test(token)) return true;
  if (/^glpat-0{20,}$/.test(token)) return true;
  if (/^npm_0{20,}$/.test(token)) return true;
  if (/^AKIA0{16}$/.test(token)) return true;
  if (/^sk_live_0{20,}$/.test(token)) return true;
  return false;
}

// Parse Inline Code Directives (e.g. // saif:ignore[pat-aws-key], # saif:allow-sample)
function parseInlineDirectives(text) {
  if (!text || typeof text !== 'string') {
    return { globalIgnore: false, lineDirectives: new Map() };
  }

  let globalIgnore = false;
  const lineDirectives = new Map();

  const lines = text.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const directiveMatch = line.match(/(?:\/\/|#|\/\*|<!--)\s*saif:(?:ignore|allow-sample|ignore-all|allow-all)(?:\[([a-zA-Z0-9_\-, ]+)\])?/i);
    if (directiveMatch) {
      if (line.includes('saif:ignore-all') || line.includes('saif:allow-all')) {
        globalIgnore = true;
      }

      const targets = new Set();
      const ruleSpec = directiveMatch[1];
      if (ruleSpec) {
        const parts = ruleSpec.split(',').map(s => s.trim().toLowerCase());
        for (const p of parts) targets.add(p);
      } else {
        targets.add('*'); // wildcard: suppress all rules on target line
      }
      lineDirectives.set(i, targets);
    }
  }

  return { globalIgnore, lineDirectives };
}

function isRuleActive(rule, categoryToggles = {}, ruleToggles = {}) {
  if (!rule) return false;
  // 1. Explicit rule-level override takes highest precedence
  if (ruleToggles && ruleToggles[rule.id] !== undefined) {
    return ruleToggles[rule.id] === true;
  }
  // 2. Direct category toggle
  if (categoryToggles) {
    // 2a. Check specific legacy category first if present on rule
    if (rule.legacyCategory && categoryToggles[rule.legacyCategory] !== undefined) {
      return categoryToggles[rule.legacyCategory] === true;
    }
    // 2b. Check canonical category
    if (rule.category && categoryToggles[rule.category] !== undefined) {
      return categoryToggles[rule.category] === true;
    }
    if (rule.presidioCategory && categoryToggles[rule.presidioCategory] !== undefined) {
      return categoryToggles[rule.presidioCategory] === true;
    }
    // 2c. Legacy category fallback if rule has no specific legacyCategory
    if (!rule.legacyCategory) {
      for (const [legacyId, canonicalId] of Object.entries(LEGACY_CATEGORY_MAP)) {
        if ((rule.category === canonicalId || rule.presidioCategory === canonicalId) && categoryToggles[legacyId] !== undefined) {
          return categoryToggles[legacyId] === true;
        }
      }
    }
  }
  // 3. Default fallback
  return rule.enabledByDefault !== false;
}


// -------------------------------------------------------------
// Mathematical & Algorithmic Checksum Validators for National IDs & Cards
// -------------------------------------------------------------
function validateGermanTaxID(s) {
  const clean = s.replace(/[\s/-]/g, '');
  if (clean.length !== 11 || clean[0] === '0' || !/^\d{11}$/.test(clean)) return false;

  // Statutory § 139b AO structural rule:
  // In the first 10 digits, exactly one digit must appear 2 or 3 times,
  // and all other digits must appear at most once.
  const counts = {};
  for (let i = 0; i < 10; i++) {
    const ch = clean[i];
    counts[ch] = (counts[ch] || 0) + 1;
  }

  let repeatedCount = 0;
  let repeatedFreq = 0;
  for (const cnt of Object.values(counts)) {
    if (cnt > 1) {
      repeatedCount++;
      repeatedFreq = cnt;
    }
  }

  if (repeatedCount !== 1 || (repeatedFreq !== 2 && repeatedFreq !== 3)) {
    return false;
  }

  // If a digit appears 3 times, no three consecutive identical digits are allowed
  if (repeatedFreq === 3) {
    for (let i = 0; i < 8; i++) {
      if (clean[i] === clean[i + 1] && clean[i + 1] === clean[i + 2]) {
        return false;
      }
    }
  }

  // ISO 7064 Mod 11, 10 checksum on first 10 digits
  let p = 10;
  for (let i = 0; i < 10; i++) {
    const d = parseInt(clean[i], 10);
    let sum = (d + p) % 10;
    if (sum === 0) sum = 10;
    p = (sum * 2) % 11;
  }
  let check = 11 - p;
  if (check === 10) check = 0;
  return check === parseInt(clean[10], 10);
}

function validateBrazilianCPF(s) {
  const clean = s.replace(/[\s.-]/g, '');
  if (clean.length !== 11 || !/^\d{11}$/.test(clean)) return false;
  if (/^(\d)\1{10}$/.test(clean)) return false; // reject all-identical digits
  let sum1 = 0;
  for (let i = 0; i < 9; i++) {
    sum1 += parseInt(clean[i], 10) * (10 - i);
  }
  let rem1 = (sum1 * 10) % 11;
  if (rem1 === 10) rem1 = 0;
  if (rem1 !== parseInt(clean[9], 10)) return false;
  let sum2 = 0;
  for (let i = 0; i < 10; i++) {
    sum2 += parseInt(clean[i], 10) * (11 - i);
  }
  let rem2 = (sum2 * 10) % 11;
  if (rem2 === 10) rem2 = 0;
  return rem2 === parseInt(clean[10], 10);
}

function validateLuhn(s) {
  const clean = s.replace(/[\s-]/g, '');
  if (clean.length < 13 || clean.length > 19 || !/^\d+$/.test(clean)) return false;
  let sum = 0;
  let alternate = false;
  for (let i = clean.length - 1; i >= 0; i--) {
    let n = parseInt(clean[i], 10);
    if (alternate) {
      n *= 2;
      if (n > 9) n = (n % 10) + 1;
    }
    sum += n;
    alternate = !alternate;
  }
  return (sum % 10 === 0);
}

function validateSpanishDNI(s) {
  const clean = s.trim().toUpperCase().replace(/[\s-]/g, '');
  if (!/^\d{8}[A-Z]$/.test(clean)) return false;
  const num = parseInt(clean.substring(0, 8), 10);
  const letters = 'TRWAGMYFPDXBNJZSQVHLCKE';
  return clean[8] === letters[num % 23];
}

function isInsideUrlContext(text, matchIndex) {
  const lineStart = Math.max(0, text.lastIndexOf('\n', matchIndex) + 1);
  const preceding = text.substring(lineStart, matchIndex);
  if (/(?:https?:\/\/|www\.)[^\s]*$/i.test(preceding)) {
    return true;
  }
  return false;
}

function matchStandardRules(promptText, categoryToggles = {}, ruleToggles = {}) {
  const matches = [];
  if (!promptText || typeof promptText !== 'string') return matches;

  const { globalIgnore, lineDirectives } = parseInlineDirectives(promptText);
  if (globalIgnore) return matches;

  for (const rule of compiledRules) {
    if (!isRuleActive(rule, categoryToggles, ruleToggles)) {
      continue;
    }

    const regex = compileRuleRegex(rule);
    if (!regex) continue;
    regex.lastIndex = 0;
    let m;
    while ((m = regex.exec(promptText)) !== null) {
      const token = m[0];

      // Rule 18 & Universal Hyphenated Word Invariant:
      // Ensure match is not an embedded component of a UUID or hex/hyphenated identifier (e.g. "a456-426614174000")
      if (m.index > 0 && promptText[m.index - 1] === '-' && m.index > 1 && /[0-9a-zA-Z]/.test(promptText[m.index - 2])) {
        continue;
      }
      if (m.index + token.length < promptText.length && promptText[m.index + token.length] === '-' && m.index + token.length + 1 < promptText.length && /[0-9a-zA-Z]/.test(promptText[m.index + token.length + 1])) {
        continue;
      }

      // Check if match is inside a URL or query parameter
      if (isInsideUrlContext(promptText, m.index)) {
        continue;
      }

      // Algorithmic & Mathematical Checksum Verification
      if (rule.id === 'pat-de-tax' && !validateGermanTaxID(token)) {
        continue;
      }
      if (rule.id === 'pat-br-cpf' && !validateBrazilianCPF(token)) {
        continue;
      }
      if (rule.id === 'pat-credit-card' && !validateLuhn(token)) {
        continue;
      }
      if (rule.id === 'pat-es-dni' && !validateSpanishDNI(token)) {
        continue;
      }

      // 1. Check Public Test Credential Whitelist
      if (isPublicTestCredential(token)) {
        continue;
      }

      // 2. Check Shannon Entropy Filter (suppress low-entropy mock tokens)
      if (rule.minEntropy && rule.minEntropy > 0) {
        const entropy = calculateShannonEntropy(token);
        if (entropy < rule.minEntropy) {
          continue;
        }
      }

      // 3. Check Inline Directives (current line or preceding line comment)
      const prefix = promptText.substring(0, m.index);
      const lineIndex = prefix.split('\n').length - 1;
      const currentLineDirective = lineDirectives.get(lineIndex);
      const prevLineDirective = lineDirectives.get(lineIndex - 1);

      const isSuppressed = (dir) => {
        if (!dir) return false;
        if (dir.has('*')) return true;
        const idLower = rule.id.toLowerCase();
        const shortId = idLower.replace(/^pat-/, '');
        const catLower = rule.category.toLowerCase();
        const presidioCatLower = (rule.presidioCategory || '').toLowerCase();
        return dir.has(idLower) || dir.has(shortId) || dir.has(catLower) || (presidioCatLower && dir.has(presidioCatLower));
      };

      if (isSuppressed(currentLineDirective) || isSuppressed(prevLineDirective)) {
        continue;
      }

      // Valid violation match
      matches.push({
        id: rule.id,
        name: rule.name,
        category: rule.category,
        presidioCategory: rule.presidioCategory || rule.category,
        severity: rule.severity,
        reason: rule.reason,
        placeholder: rule.placeholder,
        matchedToken: token
      });
      break;
    }
  }
  return matches;
}

// Canonical First-Flight Threat Sandbox Vectors
const SANDBOX_VECTORS = [
  {
    id: 'sbx-aws-key',
    name: 'AWS Access Key ID',
    category: 'secrets',
    presidioCategory: 'secrets',
    severity: 'Critical',
    prompt: 'Deploy container cluster using credentials AKIA2EXAMPLE34567890 to production',
    isSemantic: false
  },
  {
    id: 'sbx-openai-key',
    name: 'OpenAI API Key',
    category: 'secrets',
    presidioCategory: 'secrets',
    severity: 'Critical',
    prompt: 'Configure OpenAI SDK client with key sk-proj-abc123def456ghi789jkl012mno345pqr678',
    isSemantic: false
  },
  {
    id: 'sbx-db-uri',
    name: 'Database Connection URI',
    category: 'secrets',
    presidioCategory: 'secrets',
    severity: 'Critical',
    prompt: 'Connect to primary cluster at postgresql://admin:secret@db.internal:5432/prod',
    isSemantic: false
  },
  {
    id: 'sbx-private-key',
    name: 'Private RSA Key',
    category: 'secrets',
    presidioCategory: 'secrets',
    severity: 'Critical',
    prompt: '-----BEGIN RSA PRIVATE KEY-----\nMIIEowIBAAKCAQEA0m4w17i9gB9\n-----END RSA PRIVATE KEY-----',
    isSemantic: false
  },
  {
    id: 'sbx-ssn',
    name: 'US Social Security Number',
    category: 'pii_national_id',
    presidioCategory: 'pii_national_id',
    severity: 'High',
    prompt: 'Employee payroll record: John Doe, SSN: 123-12-1235',
    isSemantic: false
  },
  {
    id: 'sbx-semantic-phoenix',
    name: 'Project Phoenix Aerospace Leak',
    category: 'sem_trade_secrets',
    presidioCategory: 'neural_arbitration',
    severity: 'Critical',
    prompt: 'Provide a structural analysis of the phoenix wing spar using titanium-alloy grade 5.',
    isSemantic: true
  }
];

// CPAG 2.0 Algorithmic & Obfuscation Sandbox Vectors
const CPAG_SANDBOX_VECTORS = [
  {
    id: 'sbx-credit-card',
    name: 'Credit Card (Luhn Verified)',
    category: 'pii_financial',
    presidioCategory: 'pii_financial',
    severity: 'Critical',
    prompt: 'Pay supplier invoice with corporate Visa 4111 1111 1111 1111',
    isSemantic: false
  },
  {
    id: 'sbx-iban',
    name: 'IBAN (ISO Mod-97 Verified)',
    category: 'pii_financial',
    presidioCategory: 'pii_financial',
    severity: 'Critical',
    prompt: 'Wire dividend payout to IBAN DE89 3704 0044 0532 0130 00',
    isSemantic: false
  },
  {
    id: 'sbx-spaced-ssn',
    name: 'De-spaced US SSN (CPAG 2.0)',
    category: 'pii_financial',
    presidioCategory: 'pii_national_id',
    severity: 'High',
    prompt: 'Employee tax verification for John Doe: 9 8 7 - 6 5 - 4 3 2 0',
    isSemantic: false
  },
  {
    id: 'sbx-ast-join',
    name: 'Obfuscated AST Array Join (CPAG 2.0)',
    category: 'secrets',
    presidioCategory: 'secrets',
    severity: 'Critical',
    prompt: "const token = ['ghp_984210', '394820193849102938401928'].join('');",
    isSemantic: false
  }
];

function isSearchEngineUrl(urlStr) {
  if (!urlStr || typeof urlStr !== 'string') return false;
  try {
    const parsed = new URL(urlStr.includes('://') ? urlStr : 'http://' + urlStr);
    const host = parsed.hostname.toLowerCase();
    const path = parsed.pathname.toLowerCase();

    // 1. Exclude cloud/app subdomains that are clearly not web searches
    if (host.startsWith('console.') || host.startsWith('drive.') || host.startsWith('mail.') || 
        host.startsWith('docs.') || host.startsWith('github.') || host.startsWith('gitlab.') ||
        host.startsWith('api.') || host.includes('internal.') || host.includes('corp.')) {
      return false;
    }

    // 2. Specific search provider matching
    const isGoogle = (host === 'google.com' || host === 'www.google.com' || /^www\.google\.[a-z.]+$/.test(host) || /^google\.[a-z.]+$/.test(host)) && path.startsWith('/search');
    const isBing = (host === 'bing.com' || host === 'www.bing.com') && path.startsWith('/search');
    const isDuckDuckGo = (host === 'duckduckgo.com' || host === 'www.duckduckgo.com');
    const isYahoo = (host === 'search.yahoo.com') && path.startsWith('/search');
    const isBaidu = (host === 'baidu.com' || host === 'www.baidu.com') && (path === '/s' || path.startsWith('/s'));
    const isEcosia = (host === 'ecosia.org' || host === 'www.ecosia.org') && path.startsWith('/search');
    const isKagi = (host === 'kagi.com') && path.startsWith('/search');
    const isBrave = (host === 'search.brave.com') && path.startsWith('/search');
    const isStartpage = (host === 'startpage.com' || host === 'www.startpage.com') && (path.startsWith('/search') || path.startsWith('/do/search'));
    const isYandex = (/^yandex\.[a-z.]+$/.test(host) || /^www\.yandex\.[a-z.]+$/.test(host)) && path.startsWith('/search');
    const isLocalSearch = (host === 'localhost' || host === '127.0.0.1') && path.startsWith('/search');

    if (!isGoogle && !isBing && !isDuckDuckGo && !isYahoo && !isBaidu && !isEcosia && !isKagi && !isBrave && !isStartpage && !isYandex && !isLocalSearch) {
      return false;
    }

    // 3. Must have a search query parameter
    const SEARCH_QUERY_PARAMS = ['q', 'query', 'p', 'search_query', 'wd', 'text', 'keyword'];
    for (const param of SEARCH_QUERY_PARAMS) {
      if (parsed.searchParams.has(param)) return true;
    }
    return isDuckDuckGo && parsed.search.length > 1;
  } catch (_) {
    return false;
  }
}

function sanitizePrompt(text, categoryToggles = {}, ruleToggles = {}) {
  if (!text || typeof text !== 'string') {
    return { sanitized: text || '', replacementsCount: 0, details: [] };
  }

  // 1. Gather all non-overlapping match intervals
  const lines = text.split('\n');
  const candidateMatches = [];

  for (const rule of compiledRules) {
    if (!isRuleActive(rule, categoryToggles, ruleToggles)) {
      continue;
    }

    const regex = new RegExp(rule.regexStr, 'gi');
    let match;
    while ((match = regex.exec(text)) !== null) {
      const token = match[0];
      const start = match.index;
      const end = start + token.length;

      // Entropy check
      if (rule.minEntropy && rule.minEntropy > 0) {
        if (calculateShannonEntropy(token) < rule.minEntropy) {
          continue;
        }
      }

      // Public test fixture check
      if (isPublicTestCredential(token)) {
        continue;
      }

      // Inline directive check
      let currentPos = 0;
      let matchLineIndex = 0;
      for (let i = 0; i < lines.length; i++) {
        const lineLen = lines[i].length + 1; // +1 for newline
        if (currentPos + lineLen > start) {
          matchLineIndex = i;
          break;
        }
        currentPos += lineLen;
      }

      const currentLineDirective = parseInlineDirectives(lines[matchLineIndex]);
      const prevLineDirective = matchLineIndex > 0 ? parseInlineDirectives(lines[matchLineIndex - 1]) : null;

      const isSuppressed = (d) => {
        if (!d) return false;
        if (d.type === 'ignore_all') return true;
        if (d.type === 'ignore_rule' && d.rules.includes(rule.id)) return true;
        return false;
      };

      if (isSuppressed(currentLineDirective) || isSuppressed(prevLineDirective)) {
        continue;
      }

      // For URI-like matches, trim trailing sentence punctuation (e.g., trailing comma, period, paren)
      let effectiveEnd = end;
      let effectiveToken = token;
      if (rule.id === 'pat-db-uri' || rule.id === 'pat-slack-webhook') {
        const pMatch = token.match(/[,.;:!?)]+$/);
        if (pMatch) {
          const trimLen = pMatch[0].length;
          effectiveToken = token.slice(0, token.length - trimLen);
          effectiveEnd -= trimLen;
        }
      }

      candidateMatches.push({
        start,
        end: effectiveEnd,
        token: effectiveToken,
        ruleId: rule.id,
        ruleName: rule.name,
        placeholder: rule.placeholder || 'SECRET'
      });
    }
  }

  // 2. Sort by start offset ascending, resolving any overlapping intervals
  candidateMatches.sort((a, b) => a.start - b.start || b.end - a.end);
  const nonOverlapping = [];
  let lastEnd = -1;

  for (const m of candidateMatches) {
    if (m.start >= lastEnd) {
      nonOverlapping.push(m);
      lastEnd = m.end;
    }
  }

  // 3. Reconstruct text slice-by-slice with zero index drift
  const chunks = [];
  let cursor = 0;
  for (const m of nonOverlapping) {
    chunks.push(text.slice(cursor, m.start));
    chunks.push(`[${m.placeholder}_REDACTED]`);
    cursor = m.end;
  }
  chunks.push(text.slice(cursor));

  return {
    sanitized: chunks.join(''),
    replacementsCount: nonOverlapping.length,
    details: nonOverlapping
  };
}

function canSanitizePrompt(text, categoryToggles = {}, ruleToggles = {}) {
  const result = sanitizePrompt(text, categoryToggles, ruleToggles);
  if (result.replacementsCount > 0) {
    return {
      canSanitize: true,
      dlpCount: result.replacementsCount,
      semanticCount: 0,
      guidance: `Found ${result.replacementsCount} credential token(s) ready to sanitize.`
    };
  }

  return {
    canSanitize: false,
    dlpCount: 0,
    semanticCount: 1,
    guidance: 'Semantic policy violation detected. Semantic concepts cannot be auto-sanitized without altering prompt meaning. Please rephrase or use Review & Proceed Anyway.'
  };
}

function getCategorySummary(categoryToggles = {}, ruleToggles = {}) {
  const summary = {};
  for (const cat of RULE_CATEGORIES) {
    const isCatEnabled = categoryToggles[cat.id] !== false;
    const catRules = STANDARD_RULES.filter(r => r.category === cat.id);
    const activeRules = catRules.filter(r => isRuleActive(r, categoryToggles, ruleToggles));
    summary[cat.id] = {
      id: cat.id,
      name: cat.name,
      enabled: isCatEnabled,
      totalRulesCount: catRules.length,
      activeRulesCount: activeRules.length
    };
  }
  for (const [legacyId, canonicalId] of Object.entries(LEGACY_CATEGORY_MAP)) {
    if (summary[canonicalId] && !summary[legacyId]) {
      const legacyRules = STANDARD_RULES.filter(r => r.legacyCategory === legacyId || r.category === legacyId);
      const isLegacyEnabled = categoryToggles[legacyId] !== false && summary[canonicalId].enabled;
      summary[legacyId] = {
        id: legacyId,
        name: legacyId.toUpperCase(),
        enabled: isLegacyEnabled,
        totalRulesCount: legacyRules.length || summary[canonicalId].totalRulesCount,
        activeRulesCount: legacyRules.length ? legacyRules.filter(r => isRuleActive(r, categoryToggles, ruleToggles)).length : summary[canonicalId].activeRulesCount
      };
    }
  }
  return summary;
}

function matchCustomRules(promptText, customRules) {
  if (!promptText || typeof promptText !== 'string' || !Array.isArray(customRules) || customRules.length === 0) {
    return [];
  }

  const directives = parseInlineDirectives(promptText);
  if (directives.globalIgnore) {
    return [];
  }

  const matches = [];

  for (const rule of customRules) {
    if (rule.enabled === false) continue;
    const ruleId = (rule.id || '').toLowerCase();
    const ruleSlug = (rule.slug || ruleId).toLowerCase();
    const ruleName = rule.name || 'Custom Rule';
    const action = rule.action || 'BLOCK'; // 'BLOCK', 'REDACT', 'WARN'
    const severity = action === 'BLOCK' ? 'Critical' : (action === 'REDACT' ? 'High' : 'Medium');

    const isSuppressed = (lineIdx) => {
      const dir = directives.lineDirectives.get(lineIdx);
      if (!dir) return false;
      if (dir.has('*')) return true;
      return dir.has(ruleId) || dir.has(ruleSlug) || dir.has('custom');
    };

    if (rule.type === 'keyword' && rule.pattern) {
      const needle = rule.pattern.toLowerCase();
      const haystack = promptText.toLowerCase();
      let startPos = 0;
      while ((startPos = haystack.indexOf(needle, startPos)) !== -1) {
        const lineIdx = promptText.substring(0, startPos).split('\n').length - 1;
        if (!isSuppressed(lineIdx) && !isSuppressed(lineIdx - 1)) {
          matches.push({
            id: rule.id,
            slug: ruleSlug,
            name: ruleName,
            category: 'custom',
            type: 'keyword',
            severity: severity,
            action: action,
            reason: `Custom Rule Matched: ${ruleName}`,
            placeholder: `REDACTED_${ruleSlug.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase()}`,
            matchedToken: promptText.substring(startPos, startPos + needle.length),
            index: startPos,
            length: needle.length
          });
          break;
        }
        startPos += needle.length;
      }
    } else if (rule.type === 'regex' && rule.pattern) {
      try {
        const re = new RegExp(rule.pattern, 'gi');
        let m;
        while ((m = re.exec(promptText)) !== null) {
          const token = m[0];
          if (!token) break;
          const lineIdx = promptText.substring(0, m.index).split('\n').length - 1;
          if (!isSuppressed(lineIdx) && !isSuppressed(lineIdx - 1)) {
            matches.push({
              id: rule.id,
              slug: ruleSlug,
              name: ruleName,
              category: 'custom',
              type: 'regex',
              severity: severity,
              action: action,
              reason: `Custom Rule Matched: ${ruleName}`,
              placeholder: `REDACTED_${ruleSlug.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase()}`,
              matchedToken: token,
              index: m.index,
              length: token.length
            });
            break;
          }
        }
      } catch (_) {
        // Safe skip on malformed regex
      }
    } else if (rule.type === 'semantic' && Array.isArray(rule.prototypes)) {
      const promptLower = promptText.toLowerCase();
      for (const proto of rule.prototypes) {
        if (!proto || typeof proto !== 'string') continue;
        const protoWords = proto.toLowerCase().split(/\s+/).filter(w => w.length > 4);
        if (protoWords.length > 0) {
          const matchCount = protoWords.filter(w => promptLower.includes(w)).length;
          if (matchCount / protoWords.length >= 0.75) {
            matches.push({
              id: rule.id,
              slug: ruleSlug,
              name: ruleName,
              category: 'custom',
              type: 'semantic',
              severity: severity,
              action: action,
              reason: `Custom Semantic Policy: ${ruleName}`,
              placeholder: `REDACTED_${ruleSlug.replace(/[^a-zA-Z0-9]/g, '_').toUpperCase()}`,
              matchedToken: proto,
              index: 0,
              length: 0
            });
            break;
          }
        }
      }
    }
  }

  return matches;
}

// In-place text sanitization for custom rules (replaces tokens for REDACT rules)
function sanitizeCustomPrompt(promptText, customMatches) {
  if (!promptText || typeof promptText !== 'string' || !Array.isArray(customMatches) || customMatches.length === 0) {
    return { sanitizedText: promptText, replacements: 0 };
  }

  let sanitized = promptText;
  let count = 0;

  const redactMatches = customMatches
    .filter(m => m.action === 'REDACT' && m.matchedToken)
    .sort((a, b) => (b.index || 0) - (a.index || 0));

  for (const m of redactMatches) {
    const placeholder = `[${m.placeholder || 'REDACTED'}]`;
    if (typeof m.index === 'number' && m.length > 0) {
      sanitized = sanitized.substring(0, m.index) + placeholder + sanitized.substring(m.index + m.length);
      count++;
    } else if (m.matchedToken) {
      const idx = sanitized.indexOf(m.matchedToken);
      if (idx !== -1) {
        sanitized = sanitized.substring(0, idx) + placeholder + sanitized.substring(idx + m.matchedToken.length);
        count++;
      }
    }
  }

  return { sanitizedText: sanitized, replacements: count };
}

// Global browser environment exposure
if (typeof globalThis !== 'undefined') {
  globalThis.PRESIDIO_CATEGORIES = PRESIDIO_CATEGORIES;
  globalThis.LEGACY_CATEGORIES = LEGACY_CATEGORIES;
  globalThis.RULE_CATEGORIES = RULE_CATEGORIES;
  globalThis.STANDARD_RULES = STANDARD_RULES;
  globalThis.compiledRules = compiledRules;
  globalThis.calculateShannonEntropy = calculateShannonEntropy;
  globalThis.PUBLIC_TEST_CREDENTIALS = PUBLIC_TEST_CREDENTIALS;
  globalThis.isPublicTestCredential = isPublicTestCredential;
  globalThis.parseInlineDirectives = parseInlineDirectives;
  globalThis.isRuleActive = isRuleActive;
  globalThis.matchStandardRules = matchStandardRules;
  globalThis.getCategorySummary = getCategorySummary;
  globalThis.SANDBOX_VECTORS = SANDBOX_VECTORS;
  globalThis.isSearchEngineUrl = isSearchEngineUrl;
  globalThis.sanitizePrompt = sanitizePrompt;
  globalThis.canSanitizePrompt = canSanitizePrompt;
  globalThis.matchCustomRules = matchCustomRules;
  globalThis.sanitizeCustomPrompt = sanitizeCustomPrompt;
  globalThis.rulesCatalog = {
    PRESIDIO_CATEGORIES,
    LEGACY_CATEGORIES,
    RULE_CATEGORIES,
    STANDARD_RULES,
    compiledRules,
    calculateShannonEntropy,
    PUBLIC_TEST_CREDENTIALS,
    isPublicTestCredential,
    parseInlineDirectives,
    isRuleActive,
    matchStandardRules,
    getCategorySummary,
    SANDBOX_VECTORS,
    CPAG_SANDBOX_VECTORS,
    isSearchEngineUrl,
    sanitizePrompt,
    canSanitizePrompt,
    matchCustomRules,
    sanitizeCustomPrompt
  };
}
if (typeof self !== 'undefined') {
  self.PRESIDIO_CATEGORIES = PRESIDIO_CATEGORIES;
  self.LEGACY_CATEGORIES = LEGACY_CATEGORIES;
  self.RULE_CATEGORIES = RULE_CATEGORIES;
  self.STANDARD_RULES = STANDARD_RULES;
  self.compiledRules = compiledRules;
  self.calculateShannonEntropy = calculateShannonEntropy;
  self.PUBLIC_TEST_CREDENTIALS = PUBLIC_TEST_CREDENTIALS;
  self.isPublicTestCredential = isPublicTestCredential;
  self.parseInlineDirectives = parseInlineDirectives;
  self.isRuleActive = isRuleActive;
  self.matchStandardRules = matchStandardRules;
  self.getCategorySummary = getCategorySummary;
  self.SANDBOX_VECTORS = SANDBOX_VECTORS;
  self.CPAG_SANDBOX_VECTORS = CPAG_SANDBOX_VECTORS;
  self.matchCustomRules = matchCustomRules;
  self.sanitizeCustomPrompt = sanitizeCustomPrompt;
}
if (typeof window !== 'undefined') {
  window.PRESIDIO_CATEGORIES = PRESIDIO_CATEGORIES;
  window.LEGACY_CATEGORIES = LEGACY_CATEGORIES;
  window.RULE_CATEGORIES = RULE_CATEGORIES;
  window.STANDARD_RULES = STANDARD_RULES;
  window.compiledRules = compiledRules;
  window.calculateShannonEntropy = calculateShannonEntropy;
  window.PUBLIC_TEST_CREDENTIALS = PUBLIC_TEST_CREDENTIALS;
  window.isPublicTestCredential = isPublicTestCredential;
  window.parseInlineDirectives = parseInlineDirectives;
  window.isRuleActive = isRuleActive;
  window.matchStandardRules = matchStandardRules;
  window.getCategorySummary = getCategorySummary;
  window.SANDBOX_VECTORS = SANDBOX_VECTORS;
  window.CPAG_SANDBOX_VECTORS = CPAG_SANDBOX_VECTORS;
  window.matchCustomRules = matchCustomRules;
  window.sanitizeCustomPrompt = sanitizeCustomPrompt;
}

// Module export for Node.js test environment
try {
  if (typeof module !== 'undefined' && module && module.exports) {
    module.exports = {
      PRESIDIO_CATEGORIES,
      LEGACY_CATEGORIES,
      RULE_CATEGORIES,
      STANDARD_RULES,
      compiledRules,
      calculateShannonEntropy,
      PUBLIC_TEST_CREDENTIALS,
      isPublicTestCredential,
      parseInlineDirectives,
      isRuleActive,
      matchStandardRules,
      getCategorySummary,
      SANDBOX_VECTORS,
      CPAG_SANDBOX_VECTORS,
      isSearchEngineUrl,
      sanitizePrompt,
      canSanitizePrompt,
      matchCustomRules,
      sanitizeCustomPrompt,
      validateGermanTaxID
    };
  }
} catch (_) {}

