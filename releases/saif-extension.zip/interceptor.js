// SAIF Main-World Network Interceptor (Manifest V3)
// Injected into page context (world: "MAIN") at document_start
// Intercepts outgoing fetch / XHR payloads directly before wire transmission

(function () {
  const hasWindow = typeof window !== 'undefined';
  if (hasWindow && window.__SAIF_INTERCEPTOR_INSTALLED__) return;
  if (hasWindow) window.__SAIF_INTERCEPTOR_INSTALLED__ = true;

  const originalFetch = hasWindow ? window.fetch : null;
  const originalXhrOpen = (hasWindow && typeof XMLHttpRequest !== 'undefined') ? XMLHttpRequest.prototype.open : null;
  const originalXhrSend = (hasWindow && typeof XMLHttpRequest !== 'undefined') ? XMLHttpRequest.prototype.send : null;

  let standardRulesMatcher = (typeof matchStandardRules === 'function') ? matchStandardRules : null;
  if (!standardRulesMatcher) {
    try {
      standardRulesMatcher = require('./rules_catalog.js').matchStandardRules;
    } catch (_) {}
  }

  // Canonical Public Test Credential Whitelist (Built-in Self-Contained)
  const PUBLIC_TEST_CREDENTIALS = new Set([
    'AKIAIOSFODNN7EXAMPLE',
    'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
    '000-00-0000',
    '0000-00-00-0000',
    '0000-00-00-0000'
  ]);

  function isPublicTestCredential(token) {
    if (!token || typeof token !== 'string') return false;
    const t = token.trim();
    if (PUBLIC_TEST_CREDENTIALS.has(t)) return true;
    if (/^sk-(?:proj-)?test-[a-zA-Z0-9_-]+$/i.test(t)) return true;
    if (/^ghp_0{20,}$/.test(t)) return true;
    if (/^glpat-0{20,}$/.test(t)) return true;
    if (/^npm_0{20,}$/.test(t)) return true;
    if (/^AKIA0{16}$/.test(t)) return true;
    if (/^sk_live_0{20,}$/.test(t)) return true;
    return false;
  }

  function calculateShannonEntropy(str) {
    if (!str || typeof str !== 'string') return 0;
    const len = str.length;
    if (len === 0) return 0;
    const freq = {};
    for (let i = 0; i < len; i++) {
      const ch = str[i];
      freq[ch] = (freq[ch] || 0) + 1;
    }
    let entropy = 0;
    for (const ch in freq) {
      const p = freq[ch] / len;
      entropy -= p * Math.log2(p);
    }
    return entropy;
  }

  function parseInlineDirectives(text) {
    if (!text || typeof text !== 'string') {
      return { globalIgnore: false, lineDirectives: new Map() };
    }
    let globalIgnore = false;
    const lineDirectives = new Map();
    const lines = text.split('\n');
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i];
      const directiveMatch = line.match(/(?:\/\/|#|\/\*|<!--)\s*saif:(?:ignore|allow-sample|ignore-all|allow-all)(?:\[([a-zA-Z0-9_\-, ]+)\])?/i);
      if (directiveMatch) {
        if (line.includes('saif:ignore-all') || line.includes('saif:allow-all')) {
          globalIgnore = true;
        }
        const targets = new Set();
        const ruleSpec = directiveMatch[1];
        if (ruleSpec) {
          const parts = ruleSpec.split(',').map(s => s.trim().toLowerCase());
          for (const p of parts) targets.add(p);
        } else {
          targets.add('*');
        }
        lineDirectives.set(i, targets);
      }
    }
    return { globalIgnore, lineDirectives };
  }

  function getMatcher() {
    if (typeof standardRulesMatcher === 'function') return standardRulesMatcher;
    if (typeof matchStandardRules === 'function') return matchStandardRules;
    if (typeof window !== 'undefined' && typeof window.matchStandardRules === 'function') return window.matchStandardRules;
    if (typeof globalThis !== 'undefined' && typeof globalThis.matchStandardRules === 'function') return globalThis.matchStandardRules;
    return null;
  }

  let activeCategoryToggles = {};
  let activeRuleToggles = {};
  let activeCustomRules = [];
  let cachedWhitelistedDomains = [];

  function isCurrentDomainWhitelisted() {
    if (typeof document !== 'undefined' && document.documentElement && document.documentElement.dataset) {
      if (document.documentElement.dataset.saifWhitelisted === 'true') {
        return true;
      }
    }
    if (!hasWindow || !window.location) return false;
    const hostname = (window.location.hostname || '').toLowerCase();
    if (!hostname) return false;
    for (const d of cachedWhitelistedDomains) {
      if (hostname === d || hostname.endsWith('.' + d)) return true;
    }
    return false;
  }

  // Break-Glass In-Memory Overrides & Time-Bounded Snooze
  const overriddenPrompts = new Map(); // promptText -> expiryTimestamp
  let snoozeUntilTimestamp = 0;

  function isPromptOverridden(cand) {
    if (!cand || typeof cand !== 'string') return false;
    if (Date.now() < snoozeUntilTimestamp) return true;
    if (typeof document !== 'undefined' && document.documentElement && document.documentElement.dataset) {
      const lastOverride = document.documentElement.dataset.saifLastOverride;
      if (lastOverride) {
        const cleanLast = lastOverride.trim();
        const cleanCand = cand.trim();
        if (cleanCand === cleanLast || cleanCand.includes(cleanLast) || cleanLast.includes(cleanCand)) {
          return true;
        }
      }
    }
    const clean = cand.trim();
    const expiry = overriddenPrompts.get(clean);
    if (expiry && Date.now() < expiry) {
      return true;
    }
    for (const [k, exp] of overriddenPrompts.entries()) {
      if (Date.now() >= exp) {
        overriddenPrompts.delete(k);
      } else if (clean === k || clean.includes(k) || k.includes(clean)) {
        return true;
      }
    }
    return false;
  }

  function addOverriddenPrompt(promptText, ttlMs = 60000) {
    if (!promptText || typeof promptText !== 'string') return;
    overriddenPrompts.set(promptText.trim(), Date.now() + ttlMs);
  }

  function setSnoozeUntil(timestamp) {
    snoozeUntilTimestamp = typeof timestamp === 'number' ? timestamp : 0;
  }

  function getSnoozeUntil() {
    return snoozeUntilTimestamp;
  }

  if (hasWindow) {
    window.addEventListener('message', (event) => {
      if (event.source !== window || !event.data || typeof event.data !== 'object') return;
      if (event.data.type === '__SAIF_TOGGLES_UPDATE__') {
        if (event.data.categoryToggles) activeCategoryToggles = event.data.categoryToggles;
        if (event.data.ruleToggles) activeRuleToggles = event.data.ruleToggles;
        if (Array.isArray(event.data.customRules)) activeCustomRules = event.data.customRules;
        if (event.data.whitelistedDomains) cachedWhitelistedDomains = event.data.whitelistedDomains;
        if (typeof event.data.snoozeUntil === 'number') snoozeUntilTimestamp = event.data.snoozeUntil;
      }
      if (event.data.type === '__SAIF_BREAK_GLASS_DISPATCH__') {
        if (event.data.prompt && typeof event.data.prompt === 'string') {
          addOverriddenPrompt(event.data.prompt, 60000);
        }
      }
      if (event.data.type === '__SAIF_SNOOZE_STATE_CHANGED__') {
        if (typeof event.data.snoozeUntil === 'number') {
          snoozeUntilTimestamp = event.data.snoozeUntil;
        }
      }
    });
  }

  function setInterceptorToggles(categoryToggles = {}, ruleToggles = {}) {
    activeCategoryToggles = categoryToggles || {};
    activeRuleToggles = ruleToggles || {};
  }

  function getActiveToggles() {
    let cat = { ...activeCategoryToggles };
    let rules = { ...activeRuleToggles };
    if (typeof document !== 'undefined' && document.documentElement && document.documentElement.dataset) {
      try {
        if (document.documentElement.dataset.saifCategoryToggles) {
          const parsed = JSON.parse(document.documentElement.dataset.saifCategoryToggles);
          cat = { ...cat, ...parsed };
        }
        if (document.documentElement.dataset.saifRuleToggles) {
          const parsed = JSON.parse(document.documentElement.dataset.saifRuleToggles);
          rules = { ...rules, ...parsed };
        }
      } catch (_) {}
    }
    return { categoryToggles: cat, ruleToggles: rules };
  }

  // Ignored URL endpoints (telemetry, static assets, logging, self-loopback)
  const IGNORED_URL_PATTERNS = [
    '127.0.0.1:18080',
    '127.0.0.1:8080',
    'localhost:18080',
    'localhost:8080',
    '/api/v1/audit',
    '/telemetry',
    '/metrics',
    '/analytics',
    'google-analytics',
    'statsig',
    'sentry.io',
    'datadog',
    'browser-intake',
    '/cdn-cgi/',
    'favicon.ico',
    '.css',
    '.png',
    '.svg',
    '.woff',
    'play.google.com',
    'logs?format=',
    '/client_204',
    '/gen_204',
    'ogs.google.com',
    'accounts.google.com',
    'login.microsoftonline.com',
    'login.live.com',
    'login.windows.net',
    'account.activedirectory.windowsazure.com',
    '/oauth2/v2.0',
    '/oauth2/token',
    '/oauth2/authorize',
    'doubleclick.net',
    'googletagmanager.com',
    'pipe.aria.microsoft.com',
    '.data.microsoft.com',
    'telemetry.microsoft.com',
    '.vortex.data.microsoft.com',
    '/qos',
    'clarity.ms',
    'bat.bing.com',
    '/collect',
    '/events',
    '/tracking'
  ];

  function isIgnoredUrl(url) {
    if (!url) return true;
    const urlLower = url.toLowerCase();
    return IGNORED_URL_PATTERNS.some(p => urlLower.includes(p));
  }

  // Known telemetry, client-hints, and RPC infrastructure noise strings
  const NOISE_STRINGS = new Set([
    'google chrome', 'chromium', 'not_a brand', 'windows', 'macos', 'linux',
    'android', 'ios', 'x86', 'arm', 'wrb.fr', 'f.req', 'en', 'en-us', 'true', 'false', 'null'
  ]);

  function isNoiseString(str) {
    if (!str || typeof str !== 'string') return true;
    // If it contains a secret pattern (e.g. AWS key, JWT, private key), NEVER treat as noise!
    if (/\b(?:AKIA[0-9A-Z]{16}|ASIA[0-9A-Z]{16}|eyJ[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+|gh[pousr]_[A-Za-z0-9_]{36,255}|sk_live_[0-9a-zA-Z]{24,100}|sk-(?:proj-|admin-)?[a-zA-Z0-9_-]{32,64})\b|-----BEGIN/.test(str)) {
      return false;
    }
    const lower = str.trim().toLowerCase();
    if (NOISE_STRINGS.has(lower)) return true;
    if (/^[\d._-]+$/.test(lower)) return true;
    // Any token without spaces or CJK characters that looks like an ID, slug, hash, or code identifier
    if (!lower.includes(' ') && !/[\u3000-\u9fff]/.test(str)) {
      if (str.length < 60) return true;
    }
    if (lower.length > 20 && !lower.includes(' ') && /^[a-zA-Z0-9+/=_-]+$/.test(str)) return true;
    return false;
  }

  // Parameter and object keys ignored during recursive scan to prevent false positives on tokens/hashes
  const EXCLUDED_SCAN_KEYS = new Set([
    'model', 'role', 'session_id', 'sessionid', 'id', 'timestamp', 'time',
    'at', 'f.sid', 'sig', 'signature', 'csrf', 'token', 'auth',
    'authorization', 'cookie', 'state', 'nonce', 'version', 'stream',
    'basetype', 'impressionguid', 'pagename', 'eventname', 'clienttimestamp',
    'seqnum', 'samplingrate', 'ikey', 'datavalues', 'correlationid', 'requestid',
    'deviceid', 'targeturi', 'responsecode', 'qos'
  ]);

  // Recursively extracts human-readable text and prompt payloads from JSON, FormData, URL-encoded strings, and nested RPC arrays (e.g. Google batchexecute f.req)
  function collectStringsFromData(data, depth = 0, collected = []) {
    if (data == null || depth > 32) return collected;

    if (typeof data === 'string') {
      const trimmed = data.trim();
      if (!trimmed) return collected;

      // 1. Check if string is a nested JSON structure (e.g. Google's inner f.req arrays)
      if ((trimmed.startsWith('[') && trimmed.endsWith(']')) ||
          (trimmed.startsWith('{') && trimmed.endsWith('}'))) {
        try {
          const parsed = JSON.parse(trimmed);
          collectStringsFromData(parsed, depth + 1, collected);
          return collected;
        } catch (_) {}
      }

      // 2. Check if string is URL-encoded form data (e.g. f.req=...&at=...)
      if (trimmed.includes('=') && !trimmed.startsWith('<') && depth < 2) {
        try {
          const params = new URLSearchParams(trimmed);
          let foundParam = false;
          for (const [key, val] of params.entries()) {
            if (EXCLUDED_SCAN_KEYS.has(key.toLowerCase())) continue;
            foundParam = true;
            collectStringsFromData(val, depth + 1, collected);
          }
          if (foundParam) return collected;
        } catch (_) {}
      }

      if (trimmed.length > 2 && !isNoiseString(trimmed)) {
        collected.push(trimmed);
      }
      return collected;
    }

    if (Array.isArray(data)) {
      for (const item of data) {
        collectStringsFromData(item, depth + 1, collected);
      }
      return collected;
    }

    if (typeof data === 'object') {
      if (typeof FormData !== 'undefined' && data instanceof FormData) {
        for (const [key, val] of data.entries()) {
          if (EXCLUDED_SCAN_KEYS.has(key.toLowerCase())) continue;
          collectStringsFromData(val, depth + 1, collected);
        }
        return collected;
      }

      if (typeof URLSearchParams !== 'undefined' && data instanceof URLSearchParams) {
        for (const [key, val] of data.entries()) {
          if (EXCLUDED_SCAN_KEYS.has(key.toLowerCase())) continue;
          collectStringsFromData(val, depth + 1, collected);
        }
        return collected;
      }

      for (const [key, val] of Object.entries(data)) {
        if (EXCLUDED_SCAN_KEYS.has(key.toLowerCase())) continue;
        collectStringsFromData(val, depth + 1, collected);
      }
      return collected;
    }

    return collected;
  }

  function isTelemetryPayload(data) {
    if (!data) return false;
    let text = data;
    if (typeof text !== 'string') {
      try {
        if (text instanceof ArrayBuffer || ArrayBuffer.isView(text)) {
          text = new TextDecoder('utf-8').decode(text);
        } else {
          text = JSON.stringify(text);
        }
      } catch (_) { return false; }
    }
    if (typeof text !== 'string') return false;

    // 1. Direct diagnostic / telemetry signatures
    if (text.includes('Ms.Qos.') || text.includes('OutgoingServiceRequest') ||
        text.includes('aria.microsoft.com') || text.includes('OneDataCollector') ||
        text.includes('ESTSClientTelemetry') || text.includes('WebWatson')) {
      return true;
    }

    // 2. Structural JSON event envelope detection
    const trimmed = text.trim();
    if (trimmed.startsWith('{') && trimmed.endsWith('}')) {
      try {
        const obj = JSON.parse(trimmed);
        if (obj && typeof obj === 'object') {
          // If payload contains explicit conversational prompt keys, it is NEVER telemetry!
          if (obj.prompt !== undefined || obj.messages !== undefined || obj.query !== undefined ||
              obj.contents !== undefined || obj.parts !== undefined || obj.input !== undefined ||
              obj.instructions !== undefined || obj.completion !== undefined) {
            return false;
          }

          const keys = Object.keys(obj).map(k => k.toLowerCase());
          const hasEventName = keys.some(k => k === 'name' || k === 'event' || k === 'eventname' || k === 'basetype');
          const hasTime = keys.some(k => k === 'time' || k === 'timestamp' || k === 'clienttimestamp');
          const hasTelemetryMeta = keys.some(k => k === 'ver' || k === 'version' || k === 'ikey' || k === 'samplingrate' || k === 'appinsights' || k === 'seq');

          if (hasEventName && (hasTime || hasTelemetryMeta)) {
            return true;
          }
        }
      } catch (_) {}
    }
    return false;
  }

  function extractPromptCandidates(body) {
    if (!body) return [];
    let rawText = body;
    if (typeof rawText !== 'string') {
      try {
        if (rawText instanceof ArrayBuffer || ArrayBuffer.isView(rawText)) {
          rawText = new TextDecoder('utf-8').decode(rawText);
        }
      } catch (_) {}
    }
    if (typeof rawText === 'string' && isTelemetryPayload(rawText)) {
      return [];
    }
    const strings = collectStringsFromData(rawText);
    if (!strings || strings.length === 0) return [];
    const clean = strings.filter(s => s.length > 3 && !isNoiseString(s));
    if (clean.length === 0) return [];

    // Prioritize clean strings that look like human prompts (contain spaces or CJK, length >= 8)
    const promptLike = clean.filter(s => (s.includes(' ') || /[\u3000-\u9fff]/.test(s)) && s.trim().length >= 8);
    if (promptLike.length > 0) {
      return promptLike;
    }
    return clean;
  }

  function extractPromptFromRequestBody(body) {
    const candidates = extractPromptCandidates(body);
    return candidates.length > 0 ? candidates.join('\n') : null;
  }

  // Communicate with Isolated-World content script via postMessage bridge
  function inspectPromptWithExtension(promptText, targetUrl) {
    return new Promise((resolve) => {
      const requestId = 'saif-net-' + Math.random().toString(36).substring(2) + Date.now().toString(36);

      const timeoutTimer = setTimeout(() => {
        window.removeEventListener('message', responseHandler);
        console.warn('[SAIF Interceptor] Network evaluation timeout. Blocking request via fail-closed posture.');
        resolve({
          verdict: 'BLOCK',
          reasons: ['SAIF evaluation timeout elapsed (3000ms). Blocked by enterprise security posture.']
        });
      }, 3000);

      function responseHandler(event) {
        if (event.source !== window || !event.data || event.data.type !== '__SAIF_INSPECT_RESPONSE__') return;
        if (event.data.requestId !== requestId) return;

        clearTimeout(timeoutTimer);
        window.removeEventListener('message', responseHandler);
        resolve(event.data);
      }

      window.addEventListener('message', responseHandler);

      window.postMessage({
        type: '__SAIF_INSPECT_REQUEST__',
        requestId,
        prompt: promptText,
        url: targetUrl
      }, '*');
    });
  }

  // Synchronous In-Browser Fast-Path Regex Scanner (<1ms zero-latency)
  function fastScanPrompt(text, customCategoryToggles = null, customRuleToggles = null) {
    if (isCurrentDomainWhitelisted()) return null;
    if (!text || typeof text !== 'string') return null;
    if (isPublicTestCredential(text.trim())) {
      return null;
    }

    const { globalIgnore, lineDirectives } = parseInlineDirectives(text);
    if (globalIgnore) {
      return null;
    }

    const active = getActiveToggles();
    const categoryToggles = customCategoryToggles || active.categoryToggles;
    const ruleToggles = customRuleToggles || active.ruleToggles;

    const matcher = getMatcher();
    if (typeof matcher === 'function') {
      const matches = matcher(text, categoryToggles, ruleToggles);
      if (matches && matches.length > 0) {
        return {
          verdict: 'BLOCK',
          reasons: matches.map(m => m.reason),
          triggeredRule: matches[0].name,
          riskScore: 0.95,
          evaluationChain: [{
            tier: 'dlp_fastpath',
            action: 'block',
            riskScore: 0.95,
            rule: matches[0].name,
            latencyMs: 0.1
          }],
          fastPath: true
        };
      }
    }

    // Custom Rules evaluation (<1ms)
    let customMatcher = typeof matchCustomRules === 'function' ? matchCustomRules : null;
    if (!customMatcher && typeof window !== 'undefined' && typeof window.matchCustomRules === 'function') {
      customMatcher = window.matchCustomRules;
    }
    if (customMatcher && activeCustomRules && activeCustomRules.length > 0) {
      const cMatches = customMatcher(text, activeCustomRules);
      const blockMatch = cMatches ? cMatches.find(m => m.action === 'BLOCK') : null;
      if (blockMatch) {
        return {
          verdict: 'BLOCK',
          reasons: [blockMatch.reason],
          triggeredRule: blockMatch.name,
          riskScore: 0.95,
          evaluationChain: [{
            tier: 'custom_rule_fastpath',
            action: 'block',
            riskScore: 0.95,
            rule: blockMatch.name,
            latencyMs: 0.1
          }],
          fastPath: true
        };
      }
    }

    if (matcher) {
      return null;
    } else {
      if (categoryToggles && categoryToggles['cloud_credentials'] === false && categoryToggles['api_keys'] === false) {
        return null;
      }
      const secretRegex = /(?:AKIA|ASIA)[0-9A-Z]{16}|eyJ[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+|gh[pousr]_[A-Za-z0-9_]{36,}|sk_live_[0-9a-zA-Z]{24,}|sk-(?:proj-)?[A-Za-z0-9_-]{32,}|-----BEGIN (?:RSA |EC )?PRIVATE KEY-----/g;
      let m;
      while ((m = secretRegex.exec(text)) !== null) {
        const token = m[0];
        if (isPublicTestCredential(token)) {
          continue;
        }
        const entropy = calculateShannonEntropy(token);
        if (entropy < 2.8) {
          continue;
        }
        const prefix = text.substring(0, m.index);
        const lineIndex = prefix.split('\n').length - 1;
        const currDir = lineDirectives.get(lineIndex);
        const prevDir = lineDirectives.get(lineIndex - 1);
        if ((currDir && currDir.has('*')) || (prevDir && prevDir.has('*'))) {
          continue;
        }

        return {
          verdict: 'BLOCK',
          reasons: ['Exposed Hard Secret Pattern Match'],
          triggeredRule: 'Instant Secret Match',
          riskScore: 0.95,
          evaluationChain: [{
            tier: 'dlp_fastpath',
            action: 'block',
            riskScore: 0.95,
            rule: 'Instant Secret Match',
            latencyMs: 0.1
          }],
          fastPath: true
        };
      }
    }
    return null;
  }

  // Evaluates extracted prompt candidates individually to avoid token dilution
  async function evaluatePayload(body, url) {
    if (isCurrentDomainWhitelisted()) return { verdict: 'ALLOW' };
    if (isIgnoredUrl(url)) return { verdict: 'ALLOW' };
    if (Date.now() < snoozeUntilTimestamp) {
      console.log('[SAIF Interceptor] Protection is snoozed. Allowing prompt transmission.');
      return { verdict: 'ALLOW', overridden: true, reason: 'Protection Snoozed' };
    }

    // Telemetry Envelope Pre-Check (Zero-Blind-Spot Hard-Secret Gate)
    if (isTelemetryPayload(body)) {
      let rawStr = '';
      if (typeof body === 'string') {
        rawStr = body;
      } else {
        try {
          if (body instanceof ArrayBuffer || ArrayBuffer.isView(body)) {
            rawStr = new TextDecoder('utf-8').decode(body);
          } else {
            rawStr = JSON.stringify(body);
          }
        } catch (_) {}
      }

      // Check if unredacted hard secrets are hidden inside the telemetry payload
      if (rawStr) {
        const secretMatch = fastScanPrompt(rawStr);
        if (secretMatch) {
          console.warn('[SAIF Interceptor] Hard secret detected inside telemetry payload. Blocking wire transmission.');
          return secretMatch;
        }
      }
      return { verdict: 'ALLOW', telemetry: true };
    }

    const candidates = extractPromptCandidates(body);
    if (!candidates || candidates.length === 0) return { verdict: 'ALLOW' };

    // Check if any candidate prompt was explicitly overridden via Break-Glass
    for (const cand of candidates) {
      if (isPromptOverridden(cand)) {
        console.log('[SAIF Interceptor] Candidate matches active Break-Glass override. Allowing transmission.');
        return { verdict: 'ALLOW', overridden: true, reason: 'Break-Glass Override' };
      }
    }

    console.log('[SAIF Interceptor] Intercepted outgoing AI network prompt. Evaluating candidate count:', candidates.length);

    // 0. In-Browser Fast-Path: Evaluate active rules synchronously in <1ms prior to network dispatch
    for (const cand of candidates) {
      const fastMatch = fastScanPrompt(cand);
      if (fastMatch) {
        console.warn('[SAIF Interceptor] In-Browser Fast-Path (<1ms) matched candidate:', fastMatch.reasons);
        return fastMatch;
      }
    }
    if (candidates.length > 1) {
      const fastMatch = fastScanPrompt(candidates.join('\n'));
      if (fastMatch) {
        console.warn('[SAIF Interceptor] In-Browser Fast-Path (<1ms) matched combined payload:', fastMatch.reasons);
        return fastMatch;
      }
    }

    // 1. Evaluate each candidate individually to prevent token dilution
    for (const cand of candidates) {
      const decision = await inspectPromptWithExtension(cand, url);
      if (decision && decision.verdict === 'BLOCK') {
        return decision;
      }
    }

    // 2. If individual candidates didn't trigger, evaluate joined text as fallback
    if (candidates.length > 1) {
      const joinedText = candidates.join('\n');
      const decision = await inspectPromptWithExtension(joinedText, url);
      if (decision && decision.verdict === 'BLOCK') {
        return decision;
      }
    }

    return { verdict: 'ALLOW' };
  }

  // -------------------------------------------------------------
  // Monkey-Patch window.fetch
  // -------------------------------------------------------------
  if (hasWindow && window.fetch) {
    window.fetch = async function (resource, init) {
      let url = '';
      let method = 'GET';
      let body = null;

      if (typeof resource === 'string') {
        url = resource;
      } else if (resource && typeof resource === 'object') {
        if (typeof resource.url === 'string') url = resource.url;
        if (typeof resource.method === 'string') method = resource.method.toUpperCase();
        try {
          if (typeof resource.clone === 'function') {
            const clone = resource.clone();
            body = await clone.text();
          }
        } catch (e) {}
      }

      if (init) {
        if (init.method) method = init.method.toUpperCase();
        if (init.body) {
          body = init.body;
          if (typeof Blob !== 'undefined' && body instanceof Blob) {
            try {
              body = await body.text();
            } catch (_) {}
          } else if (body instanceof ArrayBuffer || ArrayBuffer.isView(body)) {
            try {
              body = new TextDecoder('utf-8').decode(body);
            } catch (_) {}
          }
        }
      }

      if ((method === 'POST' || method === 'PUT') && !isIgnoredUrl(url)) {
        const candidates = extractPromptCandidates(body);

        if (candidates && candidates.length > 0) {
          try {
            const decision = await evaluatePayload(body, url);

            if (decision && decision.verdict === 'BLOCK') {
              console.warn('[SAIF Interceptor] SECURITY POLICY VIOLATION. Blocking network dispatch:', decision.reasons);

              // Signal content script to show high-visibility block UI
              window.postMessage({
                type: '__SAIF_SHOW_BLOCK_UI__',
                reasons: decision.reasons || ['Blocked by SAIF AI Firewall corporate security policy.'],
                prompt: candidates[0],
                triggeredRule: decision.triggeredRule,
                riskScore: decision.riskScore
              }, '*');

              // Generate synthetic HTTP 403 Forbidden Response
              const blockPayload = JSON.stringify({
                error: {
                  message: 'This prompt was blocked by corporate AI security policy.',
                  type: 'saif_security_policy_violation',
                  code: 'forbidden',
                  reasons: decision.reasons || ['Restricted sensitive data detected.']
                }
              });

              return new Response(blockPayload, {
                status: 403,
                statusText: 'Forbidden',
                headers: {
                  'Content-Type': 'application/json',
                  'X-SAIF-Enforcement': 'BLOCK'
                }
              });
            }
          } catch (err) {
            console.warn('[SAIF Interceptor] Inspection bridge exception, enforcing fail-closed block:', err.message);
            window.postMessage({
              type: '__SAIF_SHOW_BLOCK_UI__',
              reasons: ['Inspection bridge exception. Blocked by enterprise security posture.']
            }, '*');
            const blockPayload = JSON.stringify({
              error: {
                message: 'Inspection bridge exception. Blocked by enterprise security posture.',
                type: 'saif_security_policy_violation',
                code: 'forbidden'
              }
            });
            return new Response(blockPayload, {
              status: 403,
              statusText: 'Forbidden',
              headers: {
                'Content-Type': 'application/json',
                'X-SAIF-Enforcement': 'BLOCK'
              }
            });
          }
        }
      }

      return originalFetch.apply(this, arguments);
    };
  }

  // -------------------------------------------------------------
  // Monkey-Patch XMLHttpRequest
  // -------------------------------------------------------------
  if (hasWindow && typeof XMLHttpRequest !== 'undefined') {
    XMLHttpRequest.prototype.open = function (method, url) {
      this.__saif_method = (method || 'GET').toUpperCase();
      this.__saif_url = url || '';
      return originalXhrOpen.apply(this, arguments);
    };

    XMLHttpRequest.prototype.send = function (body) {
      const method = this.__saif_method || 'GET';
      const url = this.__saif_url || '';

      if ((method === 'POST' || method === 'PUT') && !isIgnoredUrl(url)) {
        const candidates = extractPromptCandidates(body);
        if (candidates && candidates.length > 0) {
          evaluatePayload(body, url).then(decision => {
            if (decision && decision.verdict === 'BLOCK') {
              window.postMessage({
                type: '__SAIF_SHOW_BLOCK_UI__',
                reasons: decision.reasons || ['Blocked by SAIF AI Firewall corporate security policy.'],
                prompt: candidates[0],
                triggeredRule: decision.triggeredRule,
                riskScore: decision.riskScore
              }, '*');
              try { this.abort(); } catch (e) {}
            } else {
              originalXhrSend.call(this, body);
            }
          }).catch((err) => {
            console.warn('[SAIF Interceptor] XHR inspection exception, enforcing fail-closed block:', err);
            window.postMessage({
              type: '__SAIF_SHOW_BLOCK_UI__',
              reasons: ['Inspection bridge exception. Blocked by enterprise security posture.']
            }, '*');
            try { this.abort(); } catch (e) {}
          });
          return;
        }
      }

      return originalXhrSend.apply(this, arguments);
    };
  }

  if (hasWindow) {
    console.log('[SAIF Interceptor] Main-World network hooking initialized successfully at document_start.');
  }

  // Node.js test environment exports
  try {
    if (typeof module !== 'undefined' && module && module.exports) {
      module.exports = {
        fastScanPrompt,
        extractPromptCandidates,
        collectStringsFromData,
        isNoiseString,
        isIgnoredUrl,
        getActiveToggles,
        setInterceptorToggles,
        isPromptOverridden,
        addOverriddenPrompt,
        setSnoozeUntil,
        getSnoozeUntil,
        evaluatePayload
      };
    }
  } catch (_) {}
})();
