// SAIF Popup Controller - Free Tier Extension UI
document.addEventListener('DOMContentLoaded', () => {
  if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
    return;
  }

  // 1. Fetch Stats & Status
  loadStats();
  setInterval(loadStats, 2000);

  // 2. Fetch Categories & Render Toggles
  loadCategories();

  // 3. Active Domain Whitelist Controls
  initActiveDomain();

  // 3b. Initialize Protection Snooze Controls
  initSnoozeControls();

  // 3c. Initialize Fail-Closed Offline Setting
  initOfflineToggle();

  // 3d. Initialize Egress Policy Engine Controls
  initEgressModeControls();

  const btnWhitelist = document.getElementById('btnToggleDomainWhitelist');
  if (btnWhitelist) {
    btnWhitelist.addEventListener('click', () => {
      if (!currentActiveDomain) return;
      const type = isCurrentDomainWhitelisted ? 'REVOKE_DOMAIN_ONCE' : 'ALLOW_DOMAIN_ONCE';
      chrome.runtime.sendMessage({ type, domain: currentActiveDomain }, () => {
        checkDomainWhitelistStatus();
      });
    });
  }

  // 4. Open Full Dashboard
  document.getElementById('btnOpenDashboard').addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard.html') });
  });

  // 5. Sync Heartbeat
  document.getElementById('btnSync').addEventListener('click', () => {
    const btn = document.getElementById('btnSync');
    btn.textContent = 'Syncing...';
    chrome.runtime.sendMessage({ type: 'TRIGGER_HEARTBEAT' }, () => {
      btn.textContent = 'Synced!';
      loadStats();
      setTimeout(() => { btn.textContent = 'Sync Heartbeat'; }, 1500);
    });
  });

  // 6. Clear History
  document.getElementById('btnClearEvents').addEventListener('click', () => {
    const btn = document.getElementById('btnClearEvents');
    btn.textContent = 'Cleared!';
    chrome.runtime.sendMessage({ type: 'CLEAR_RECENT_EVENTS' }, () => {
      loadStats();
      setTimeout(() => { btn.textContent = 'Clear History'; }, 1500);
    });
  });

  // 7. Real-time metric listener
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && (changes.totalEvaluations || changes.totalBlocks || changes.recentEvents)) {
        loadStats();
      }
    });
  }
});

let currentActiveDomain = '';
let isCurrentDomainWhitelisted = false;

function initActiveDomain() {
  if (typeof chrome === 'undefined' || !chrome.tabs || !chrome.tabs.query) {
    updateDomainUI('browser', false);
    return;
  }
  chrome.tabs.query({ currentWindow: true }, (tabs) => {
    let targetUrl = '';
    if (tabs && tabs.length > 0) {
      const activeTab = tabs.find(t => t.active);
      if (activeTab && activeTab.url && !activeTab.url.startsWith('chrome-extension://') && !activeTab.url.startsWith('chrome://')) {
        targetUrl = activeTab.url;
      } else {
        const webTab = tabs.find(t => t.url && !t.url.startsWith('chrome-extension://') && !t.url.startsWith('chrome://'));
        if (webTab) {
          targetUrl = webTab.url;
        } else if (activeTab && activeTab.url) {
          targetUrl = activeTab.url;
        }
      }
    }

    if (targetUrl) {
      try {
        const u = new URL(targetUrl);
        currentActiveDomain = u.hostname.toLowerCase();
      } catch (_) {
        currentActiveDomain = 'local';
      }
    } else {
      currentActiveDomain = 'local';
    }
    checkDomainWhitelistStatus();
  });
}

function checkDomainWhitelistStatus() {
  if (!currentActiveDomain) return;
  chrome.runtime.sendMessage({ type: 'GET_WHITELISTED_DOMAINS' }, (res) => {
    const list = (res && res.whitelisted) || [];
    isCurrentDomainWhitelisted = list.includes(currentActiveDomain);
    updateDomainUI(currentActiveDomain, isCurrentDomainWhitelisted);
  });
}

function updateDomainUI(domain, isWhitelisted) {
  const domainEl = document.getElementById('activeDomainName');
  const badgeEl = document.getElementById('domainStatusBadge');
  const btnEl = document.getElementById('btnToggleDomainWhitelist');

  if (domainEl) domainEl.textContent = domain || 'local';

  if (isWhitelisted) {
    if (badgeEl) {
      badgeEl.textContent = 'WHITELISTED';
      badgeEl.style.background = 'rgba(245, 158, 11, 0.15)';
      badgeEl.style.color = '#fbbf24';
    }
    if (btnEl) {
      btnEl.textContent = 'Revoke';
      btnEl.style.borderColor = '#ef4444';
      btnEl.style.background = 'rgba(239, 68, 68, 0.15)';
      btnEl.style.color = '#f87171';
    }
  } else {
    if (badgeEl) {
      badgeEl.textContent = 'PROTECTED';
      badgeEl.style.background = 'rgba(59, 130, 246, 0.15)';
      badgeEl.style.color = '#60a5fa';
    }
    if (btnEl) {
      btnEl.textContent = 'Allow Once';
      btnEl.style.borderColor = '#3b82f6';
      btnEl.style.background = 'rgba(59, 130, 246, 0.15)';
      btnEl.style.color = '#93c5fd';
    }
  }
}

function initOfflineToggle() {
  const toggle = document.getElementById('toggleFailClosedOffline');
  if (!toggle) return;
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(['failClosedOffline'], (stored) => {
      if (stored && stored.failClosedOffline === true) {
        toggle.checked = true;
      }
    });
  }
  toggle.addEventListener('change', (e) => {
    const checked = e.target.checked;
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.set({ failClosedOffline: checked });
    }
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
      chrome.runtime.sendMessage({ type: 'SET_FAIL_CLOSED_OFFLINE', enabled: checked });
    }
    loadStats();
  });
}

function loadStats() {
  chrome.runtime.sendMessage({ type: 'GET_SENSOR_STATS' }, (stats) => {
    if (stats) {
      if (document.getElementById('metricEvaluated')) {
        document.getElementById('metricEvaluated').textContent = stats.totalEvaluations || 0;
      }
      if (document.getElementById('metricBlocked')) {
        document.getElementById('metricBlocked').textContent = stats.totalBlocks || 0;
      }
      if (document.getElementById('metricRules')) {
        document.getElementById('metricRules').textContent = stats.activeRulesCount || 16;
      }
    }
  });

  const statusText = document.getElementById('statusText');
  const statusBadge = document.getElementById('statusBadge');
  const statusDot = document.getElementById('statusDot');
  const engineBadge = document.getElementById('engineBadge');

  const controller = (typeof AbortController !== 'undefined') ? new AbortController() : null;
  const timeoutId = controller ? setTimeout(() => controller.abort(), 250) : null;

  fetch('http://127.0.0.1:18080/health', { method: 'GET', signal: controller ? controller.signal : undefined })
    .then(res => res.json())
    .then(health => {
      if (timeoutId) clearTimeout(timeoutId);
      const profile = (health && (health.engineProfile || health.profile)) || 'light';
      const isC4 = profile === 'c4' || profile === 'decision';
      const isEngineer = !isC4 && (profile === 'engineer' || profile === 'r2');
      if (statusText) {
        if (isC4) {
          statusText.textContent = 'SAIF Light';
        } else if (isEngineer) {
          statusText.textContent = 'SAIF Deep Neural';
        } else {
          statusText.textContent = 'SAIF Neural';
        }
      }
      if (statusBadge) {
        if (isC4) {
          statusBadge.style.background = 'rgba(2, 132, 199, 0.15)';
          statusBadge.style.borderColor = 'rgba(2, 132, 199, 0.3)';
          statusBadge.style.color = '#38bdf8';
        } else if (isEngineer) {
          statusBadge.style.background = 'rgba(139, 92, 246, 0.15)';
          statusBadge.style.borderColor = 'rgba(139, 92, 246, 0.3)';
          statusBadge.style.color = '#c084fc';
        } else {
          statusBadge.style.background = 'rgba(34, 197, 94, 0.15)';
          statusBadge.style.borderColor = 'rgba(34, 197, 94, 0.3)';
          statusBadge.style.color = '#4ade80';
        }
      }
      if (statusDot) {
        statusDot.style.backgroundColor = isC4 ? '#0284c7' : (isEngineer ? '#8b5cf6' : '#22c55e');
      }
      if (engineBadge) {
        if (isC4) {
          engineBadge.textContent = 'Light';
          engineBadge.style.background = 'rgba(2, 132, 199, 0.15)';
          engineBadge.style.borderColor = 'rgba(2, 132, 199, 0.3)';
          engineBadge.style.color = '#38bdf8';
        } else if (isEngineer) {
          engineBadge.textContent = 'Deep Neural';
          engineBadge.style.background = 'rgba(139, 92, 246, 0.15)';
          engineBadge.style.borderColor = 'rgba(139, 92, 246, 0.3)';
          engineBadge.style.color = '#c084fc';
        } else {
          engineBadge.textContent = 'Neural';
          engineBadge.style.background = 'rgba(34, 197, 94, 0.15)';
          engineBadge.style.borderColor = 'rgba(34, 197, 94, 0.3)';
          engineBadge.style.color = '#4ade80';
        }
      }
      if (health && health.paused === true) {
        const remMinutes = Math.ceil((health.paused_remaining_sec || 900) / 60);
        if (statusText) statusText.textContent = `SNOOZED (${remMinutes}m)`;
        if (statusBadge) {
          statusBadge.style.background = 'rgba(245, 158, 11, 0.15)';
          statusBadge.style.borderColor = 'rgba(245, 158, 11, 0.3)';
          statusBadge.style.color = '#fbbf24';
        }
        if (statusDot) statusDot.style.backgroundColor = '#f59e0b';
        if (typeof window !== 'undefined' && typeof window.updateSnoozeUI === 'function') {
          window.updateSnoozeUI(true, remMinutes);
        }
      } else {
        if (typeof window !== 'undefined' && typeof window.updateSnoozeUI === 'function') {
          window.updateSnoozeUI(false, 0);
        }
      }

      if (typeof chrome !== 'undefined' && chrome.action) {
        try {
          if (health && health.paused === true) {
            chrome.action.setBadgeText({ text: 'OFF' });
            chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });
          } else {
            const badgeText = isC4 ? '⚡' : '🧠';
            const badgeColor = isC4 ? '#0284c7' : (isEngineer ? '#8b5cf6' : '#22c55e');
            chrome.action.setBadgeText({ text: badgeText });
            chrome.action.setBadgeBackgroundColor({ color: badgeColor });
          }
        } catch (_) {}
      }

      const updateBanner = document.getElementById('updateBanner');
      const updateTitle = document.getElementById('updateBannerTitle');
      const updateBtn = document.getElementById('btnTriggerUpdate');
      if (health && health.update_available) {
        if (updateBanner) {
          updateBanner.style.display = 'flex';
        }
        if (updateTitle && health.latest_version) {
          updateTitle.textContent = `Update v${health.latest_version} Available`;
        }
        if (updateBtn && !updateBtn.dataset.bound) {
          updateBtn.dataset.bound = 'true';
          updateBtn.addEventListener('click', () => {
            updateBtn.textContent = 'Updating...';
            updateBtn.disabled = true;
            fetch('http://127.0.0.1:18080/update/trigger', { method: 'POST' })
              .then(() => {
                updateBtn.textContent = 'Restarting...';
              })
              .catch(() => {
                updateBtn.textContent = 'Upgrade';
                updateBtn.disabled = false;
              });
          });
        }
      } else if (updateBanner) {
        updateBanner.style.display = 'none';
      }
    })
    .catch(() => {
      if (timeoutId) clearTimeout(timeoutId);
      let isFailClosed = false;
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(['failClosedOffline'], (stored) => {
          isFailClosed = stored && stored.failClosedOffline === true;
          applyOfflineStatus(isFailClosed);
        });
      } else {
        applyOfflineStatus(false);
      }
    });

  function applyOfflineStatus(isFailClosed) {
    if (statusText) {
      statusText.textContent = isFailClosed ? 'DISCONNECTED (FAIL-CLOSED)' : 'DISCONNECTED (FAIL-OPEN)';
    }
    if (statusBadge) {
      statusBadge.style.background = 'rgba(245, 158, 11, 0.15)';
      statusBadge.style.borderColor = 'rgba(245, 158, 11, 0.3)';
      statusBadge.style.color = '#fbbf24';
    }
    if (statusDot) statusDot.style.backgroundColor = '#f59e0b';
    if (engineBadge) {
      engineBadge.textContent = 'OFFLINE';
      engineBadge.style.background = 'rgba(245, 158, 11, 0.15)';
      engineBadge.style.borderColor = 'rgba(245, 158, 11, 0.3)';
      engineBadge.style.color = '#fbbf24';
    }
    if (typeof chrome !== 'undefined' && chrome.action) {
      try {
        chrome.action.setBadgeText({ text: 'OFF' });
        chrome.action.setBadgeBackgroundColor({ color: '#f59e0b' });
      } catch (_) {}
    }
  }
}

function loadCategories() {
  const fallbackCategories = (typeof RULE_CATEGORIES !== 'undefined' && RULE_CATEGORIES.length > 0)
    ? RULE_CATEGORIES
    : (typeof PRESIDIO_CATEGORIES !== 'undefined' ? PRESIDIO_CATEGORIES : (typeof window !== 'undefined' && window.RULE_CATEGORIES ? window.RULE_CATEGORIES : []));

  function renderCats(categories, categoryToggles, allRules = []) {
    const listEl = document.getElementById('categoryList');
    if (!listEl) return;
    listEl.innerHTML = '';
    categories.forEach(cat => {
      const isEnabled = categoryToggles[cat.id] !== false; // default true
      const catRules = allRules.filter(r => (r.presidioCategory === cat.id) || (r.category === cat.id));
      const card = document.createElement('div');
      card.className = 'category-card';
      card.innerHTML = `
        <div class="cat-info">
          <span>${cat.icon || '🛡️'}</span>
          <span class="cat-name">${escapeHtml(cat.name)}</span>
          ${catRules.length > 0 ? `<span style="font-size: 10px; color: #a1a1aa; margin-left: 2px;">(${catRules.length})</span>` : ''}
        </div>
        <label class="switch">
          <input type="checkbox" id="cat-toggle-${cat.id}" ${isEnabled ? 'checked' : ''}>
          <span class="slider"></span>
        </label>
      `;

      card.querySelector('input').addEventListener('change', (e) => {
        const checked = e.target.checked;
        chrome.runtime.sendMessage({
          type: 'SET_CATEGORY_TOGGLE',
          categoryId: cat.id,
          enabled: checked
        }, () => {
          loadStats();
        });
      });

      listEl.appendChild(card);
    });
  }

  // Immediate baseline render if available
  if (fallbackCategories.length > 0) {
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
      chrome.storage.local.get(['categoryToggles'], (stored) => {
        renderCats(fallbackCategories, (stored && stored.categoryToggles) || {}, (typeof STANDARD_RULES !== 'undefined' ? STANDARD_RULES : []));
      });
    } else {
      renderCats(fallbackCategories, {}, (typeof STANDARD_RULES !== 'undefined' ? STANDARD_RULES : []));
    }
  }

  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage({ type: 'GET_RULES_CATALOG', taxonomy: 'presidio' }, (res) => {
      if (chrome.runtime.lastError || !res) return;
      const cats = (Array.isArray(res.presidioCategories) && res.presidioCategories.length > 0)
        ? res.presidioCategories
        : (Array.isArray(res.categories) && res.categories.length > 0 ? res.categories : fallbackCategories);
      renderCats(cats, res.categoryToggles || {}, res.rules || []);
    });
  }
}

function initSnoozeControls() {
  const snoozeBadge = document.getElementById('snoozeStatusBadge');
  const btnResume = document.getElementById('btnResumeProtection');
  const countdownRow = document.getElementById('snoozeCountdownRow');
  const remainingText = document.getElementById('snoozeRemainingText');
  const snoozeButtons = document.querySelectorAll('.btn-snooze');

  function updateSnoozeUI(isSnoozed, remainingMinutes) {
    if (isSnoozed) {
      if (snoozeBadge) {
        snoozeBadge.textContent = 'SNOOZED';
        snoozeBadge.style.background = 'rgba(245, 158, 11, 0.15)';
        snoozeBadge.style.color = '#fbbf24';
      }
      if (btnResume) btnResume.style.display = 'block';
      if (countdownRow) countdownRow.style.display = 'block';
      if (remainingText) remainingText.textContent = (remainingMinutes || 15) + 'm remaining';
    } else {
      if (snoozeBadge) {
        snoozeBadge.textContent = 'ACTIVE';
        snoozeBadge.style.background = 'rgba(34, 197, 94, 0.15)';
        snoozeBadge.style.color = '#4ade80';
      }
      if (btnResume) btnResume.style.display = 'none';
      if (countdownRow) countdownRow.style.display = 'none';
    }
  }

  if (typeof window !== 'undefined') {
    window.updateSnoozeUI = updateSnoozeUI;
  }

  function fetchSnoozeStatus() {
    if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) return;
    chrome.runtime.sendMessage({ type: 'GET_SNOOZE_STATUS' }, (res) => {
      if (chrome.runtime.lastError || !res) return;
      updateSnoozeUI(res.isSnoozed, res.remainingMinutes);
    });
  }

  snoozeButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const minutes = parseInt(btn.getAttribute('data-minutes'), 10) || 15;
      chrome.runtime.sendMessage({ type: 'SNOOZE_PROTECTION', durationMinutes: minutes }, () => {
        fetchSnoozeStatus();
      });
    });
  });

  if (btnResume) {
    btnResume.addEventListener('click', () => {
      chrome.runtime.sendMessage({ type: 'RESUME_PROTECTION' }, () => {
        fetchSnoozeStatus();
      });
    });
  }

  fetchSnoozeStatus();
  setInterval(fetchSnoozeStatus, 5000);
}

function initEgressModeControls() {
  const badge = document.getElementById('egressModeBadge');
  const desc = document.getElementById('egressModeDesc');
  const buttons = document.querySelectorAll('.btn-egress-mode');

  function updateEgressUI(mode) {
    buttons.forEach(btn => {
      const btnMode = btn.getAttribute('data-mode');
      if (btnMode === mode) {
        btn.style.background = mode === 'audit_only' ? '#f59e0b' : (mode === 'strict' ? '#ef4444' : '#2563eb');
        btn.style.color = '#fff';
      } else {
        btn.style.background = 'transparent';
        btn.style.color = '#a1a1aa';
      }
    });

    if (badge) {
      if (mode === 'audit_only') {
        badge.textContent = 'AUDIT ONLY';
        badge.style.background = 'rgba(245, 158, 11, 0.15)';
        badge.style.color = '#fbbf24';
        badge.style.borderColor = 'rgba(245, 158, 11, 0.3)';
      } else if (mode === 'strict') {
        badge.textContent = 'STRICT';
        badge.style.background = 'rgba(239, 68, 68, 0.15)';
        badge.style.color = '#f87171';
        badge.style.borderColor = 'rgba(239, 68, 68, 0.3)';
      } else {
        badge.textContent = 'AI ONLY';
        badge.style.background = 'rgba(59, 130, 246, 0.15)';
        badge.style.color = '#60a5fa';
        badge.style.borderColor = 'rgba(59, 130, 246, 0.3)';
      }
    }

    if (desc) {
      if (mode === 'audit_only') {
        desc.textContent = 'Monitors all web traffic & user inputs, recording simulated blocks without disrupting users.';
      } else if (mode === 'strict') {
        desc.textContent = 'Inspects and strictly blocks sensitive egress across all sites and background network requests.';
      } else {
        desc.textContent = 'Protects all user inputs; only inspects network wire on AI domains.';
      }
    }
  }

  // Fetch current egress mode
  chrome.storage.local.get({ egressMode: 'ai_only' }, (res) => {
    const currentMode = res.egressMode || 'ai_only';
    updateEgressUI(currentMode);
  });

  buttons.forEach(btn => {
    btn.addEventListener('click', () => {
      const mode = btn.getAttribute('data-mode');
      if (!mode) return;
      chrome.storage.local.set({ egressMode: mode }, () => {
        chrome.runtime.sendMessage({ type: 'SET_EGRESS_MODE', mode }, () => {
          updateEgressUI(mode);
        });
      });
    });
  });
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
