// SAIF Content Script (Manifest V3)
// Intercepts user prompts across all web applications, search engines, and AI platforms
// Implements Capture-Phase Front-Door DOM Traps, Native Prototype Setter Injection, and Smart Restore Shimming

console.log('[SAIF Sensor] Semantic Interceptor active on DOM');

let port = null;
let keepAliveTimer = null;
const pendingRequests = new Map();
let lastFocusedComposer = null;
let lastTargetComposer = null;
let activeBlockedPrompt = null;
const knownBlockedPrompts = new Map(); // promptText -> reasons array
let preFlightTimer = null;
let blockGeneration = 0; // Incremented on every block event to invalidate stale async pre-flight results

let cachedDomainWhitelist = [];
let cachedSnoozeUntil = 0;
const inPageOverriddenPrompts = new Map(); // promptText -> expiryTimestamp
const dismissedPrompts = new Map(); // promptText -> expiryTimestamp
let cachedOmniOverrides = new Set();
let lastToastedUrl = ''; // SPA dedup: avoid re-toasting the same URL on popstate/pushState

let catalogModule = null;
function getCatalogModule() {
  if (catalogModule && catalogModule.canSanitizePrompt) {
    return catalogModule;
  }
  if (typeof require === 'function') {
    try {
      catalogModule = require('./rules_catalog.js');
      return catalogModule;
    } catch (e) {}
  }
  const g = typeof globalThis !== 'undefined' ? globalThis : (typeof window !== 'undefined' ? window : {});
  if (g.rulesCatalog) {
    catalogModule = g.rulesCatalog;
  } else {
    catalogModule = g;
  }
  return catalogModule;
}

if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
  chrome.storage.local.get(['omniOverrides'], (res) => {
    if (res && Array.isArray(res.omniOverrides)) {
      res.omniOverrides.forEach(o => cachedOmniOverrides.add(o));
    }
  });
  if (chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local' && changes.omniOverrides) {
        cachedOmniOverrides = new Set(changes.omniOverrides.newValue || []);
      }
    });
  }
}

function isProtectionSnoozed() {
  return Date.now() < cachedSnoozeUntil;
}

function isPromptDismissed(text) {
  if (!text) return false;
  const clean = text.trim();
  const now = Date.now();
  for (const [p, exp] of dismissedPrompts.entries()) {
    if (now >= exp) {
      dismissedPrompts.delete(p);
    } else if (clean === p || clean.includes(p) || p.includes(clean)) {
      return true;
    }
  }
  return false;
}

function addDismissedPrompt(promptText, ttlMs = 30000) {
  if (!promptText || typeof promptText !== 'string') return;
  const clean = promptText.trim();
  dismissedPrompts.set(clean, Date.now() + ttlMs);
}

function normalizePromptForMatching(text) {
  if (!text || typeof text !== 'string') return '';
  return text.replace(/\s+/g, ' ').trim();
}

function isPromptInPageOverridden(text) {
  if (!text) return false;
  if (isProtectionSnoozed()) return true;
  const clean = text.trim();
  const norm = normalizePromptForMatching(clean);
  const now = Date.now();
  if (typeof document !== 'undefined' && document.documentElement && document.documentElement.dataset) {
    const lastOverride = document.documentElement.dataset.saifLastOverride;
    if (lastOverride) {
      const cleanLast = lastOverride.trim();
      const normLast = normalizePromptForMatching(cleanLast);
      if (clean === cleanLast || clean.includes(cleanLast) || cleanLast.includes(clean) ||
          (norm.length >= 8 && normLast.length >= 8 && (norm === normLast || norm.includes(normLast) || normLast.includes(norm)))) {
        return true;
      }
    }
  }
  for (const [p, exp] of inPageOverriddenPrompts.entries()) {
    if (now >= exp) {
      inPageOverriddenPrompts.delete(p);
    } else {
      const normP = normalizePromptForMatching(p);
      if (clean === p || clean.includes(p) || p.includes(clean) ||
          (norm.length >= 8 && normP.length >= 8 && (norm === normP || norm.includes(normP) || normP.includes(norm)))) {
        return true;
      }
    }
  }
  return false;
}

const inPageOverriddenTokens = new Map(); // tokenString -> expiryTimestamp

function addInPageOverriddenToken(token, ttlMs = 60000) {
  if (!token || typeof token !== 'string') return;
  const clean = token.trim();
  if (!clean) return;
  inPageOverriddenTokens.set(clean, Date.now() + ttlMs);
}

function isTokenInPageOverridden(token) {
  if (!token || typeof token !== 'string') return false;
  if (isProtectionSnoozed()) return true;
  const clean = token.trim();
  if (!clean) return false;
  const now = Date.now();
  if (inPageOverriddenTokens.has(clean)) {
    if (now < inPageOverriddenTokens.get(clean)) {
      return true;
    }
    inPageOverriddenTokens.delete(clean);
  }
  for (const [t, exp] of inPageOverriddenTokens.entries()) {
    if (now >= exp) {
      inPageOverriddenTokens.delete(t);
    } else if (clean === t || clean.includes(t) || t.includes(clean)) {
      return true;
    }
  }
  return false;
}

function areAllPromptViolationsOverridden(promptText) {
  if (!promptText || typeof promptText !== 'string') return false;
  if (inPageOverriddenTokens.size === 0) return false;

  const cm = getCatalogModule();
  let rawMatches = [];
  if (cm && typeof cm.matchStandardRules === 'function') {
    rawMatches = cm.matchStandardRules(promptText, activeCategoryToggles, activeRuleToggles);
  } else if (typeof matchStandardRules === 'function') {
    rawMatches = matchStandardRules(promptText, activeCategoryToggles, activeRuleToggles);
  }

  if (!rawMatches || rawMatches.length === 0) {
    return false;
  }

  for (const m of rawMatches) {
    const tok = m.matchedToken || m.token || m.matched_text;
    if (!tok || !isTokenInPageOverridden(tok)) {
      return false;
    }
  }

  return true;
}

function addInPageOverriddenPrompt(promptText, ttlMs = 60000) {
  if (!promptText || typeof promptText !== 'string') return;
  const clean = promptText.trim();
  inPageOverriddenPrompts.set(clean, Date.now() + ttlMs);
  if (typeof document !== 'undefined' && document.documentElement) {
    try {
      if (!document.documentElement.dataset) document.documentElement.dataset = {};
      document.documentElement.dataset.saifLastOverride = clean;
    } catch (_) {}
  }
}

function setSubmissionFlag() {
  if (typeof document !== 'undefined' && document.documentElement) {
    try {
      if (!document.documentElement.dataset) document.documentElement.dataset = {};
      document.documentElement.dataset.saifSubmitting = String(Date.now());
      document.documentElement.setAttribute('data-saif-submitting', String(Date.now()));
    } catch (_) {}
  }
}

function burnInPageOverriddenPrompt(promptText) {
  if (!promptText) {
    inPageOverriddenPrompts.clear();
    inPageOverriddenTokens.clear();
  } else {
    const clean = promptText.trim();
    const norm = normalizePromptForMatching(clean);
    inPageOverriddenPrompts.delete(clean);
    knownBlockedPrompts.delete(clean);
    dismissedPrompts.delete(clean);
    dismissedPrompts.delete(norm);
    for (const [p] of inPageOverriddenPrompts.entries()) {
      const normP = normalizePromptForMatching(p);
      if (p === clean || p.includes(clean) || clean.includes(p) ||
          (norm.length >= 8 && normP.length >= 8 && (normP === norm || normP.includes(norm) || norm.includes(normP)))) {
        inPageOverriddenPrompts.delete(p);
        knownBlockedPrompts.delete(p);
        dismissedPrompts.delete(p);
        dismissedPrompts.delete(normP);
      }
    }
    for (const [tok] of inPageOverriddenTokens.entries()) {
      if (clean.includes(tok)) {
        inPageOverriddenTokens.delete(tok);
      }
    }
    if (inPageOverriddenPrompts.size === 0) {
      inPageOverriddenTokens.clear();
    }
  }
  if (typeof document !== 'undefined' && document.documentElement && document.documentElement.dataset) {
    try {
      delete document.documentElement.dataset.saifLastOverride;
    } catch (_) {}
  }
}

if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
  window.addEventListener('message', (e) => {
    if (!e.data || typeof e.data !== 'object') return;
    if (e.data.type === '__SAIF_BURN_OVERRIDE__') {
      blockGeneration++;
      burnInPageOverriddenPrompt(e.data.prompt);
      sendPortMessage({
        type: 'BURN_OVERRIDE_LEASE',
        prompt: e.data.prompt
      }).catch(() => {});
    }
  });
}

function isCurrentDomainWhitelisted() {
  if (typeof window === 'undefined' || !window.location) return false;
  const hostname = (window.location.hostname || '').toLowerCase();
  if (!hostname) return false;
  for (const domain of cachedDomainWhitelist) {
    if (hostname === domain || hostname.endsWith('.' + domain)) {
      return true;
    }
  }
  return false;
}

function syncWhitelistStateToDOM() {
  const isWhitelisted = isCurrentDomainWhitelisted();
  if (typeof document !== 'undefined' && document.documentElement) {
    document.documentElement.dataset.saifWhitelisted = isWhitelisted ? 'true' : 'false';
  }
  if (typeof window !== 'undefined' && typeof window.postMessage === 'function') {
    try {
      window.postMessage({
        type: '__SAIF_TOGGLES_UPDATE__',
        whitelistedDomains: cachedDomainWhitelist
      }, '*');
    } catch (_) {}
  }
}

let cachedEgressMode = 'ai_only';

function syncEgressModeToDOM() {
  if (typeof document !== 'undefined' && document.documentElement) {
    if (!document.documentElement.dataset) document.documentElement.dataset = {};
    document.documentElement.dataset.saifEgressMode = cachedEgressMode;
  }
  if (typeof window !== 'undefined' && typeof window.postMessage === 'function') {
    try {
      window.postMessage({
        type: '__SAIF_TOGGLES_UPDATE__',
        egressMode: cachedEgressMode
      }, '*');
    } catch (_) {}
  }
}

if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
  try {
    chrome.storage.local.get(['temporaryDomainWhitelist', 'snoozeUntil', 'egressMode'], (res) => {
      if (res && Array.isArray(res.temporaryDomainWhitelist)) {
        cachedDomainWhitelist = res.temporaryDomainWhitelist;
        syncWhitelistStateToDOM();
      }
      if (res && typeof res.snoozeUntil === 'number') {
        cachedSnoozeUntil = res.snoozeUntil;
      }
      if (res && res.egressMode) {
        cachedEgressMode = res.egressMode;
        syncEgressModeToDOM();
      } else {
        syncEgressModeToDOM();
      }
    });
    if (chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local') {
          if (changes.temporaryDomainWhitelist) {
            cachedDomainWhitelist = changes.temporaryDomainWhitelist.newValue || [];
            syncWhitelistStateToDOM();
          }
          if (changes.snoozeUntil) {
            cachedSnoozeUntil = changes.snoozeUntil.newValue || 0;
          }
          if (changes.egressMode) {
            cachedEgressMode = changes.egressMode.newValue || 'ai_only';
            syncEgressModeToDOM();
          }
        }
      });
    }
  } catch (_) {}
}

function checkSynchronousViolations(text) {
  if (!text || text.trim().length === 0) return null;
  if (isCurrentDomainWhitelisted()) return null;
  if (isProtectionSnoozed()) return null;
  if (isPromptInPageOverridden(text)) return null;
  if (isPublicTestCredential(text.trim())) return null;

  // Filter out existing redaction placeholders to prevent recursive false-positive re-blocks on sanitized prompt resubmissions
  const unmasked = text.replace(/\[REDACTED:[^\]]+\]/gi, ' ')
                       .replace(/\[[A-Z0-9_]+_REDACTED\]/gi, ' ')
                       .replace(/\[REDACTED\]/gi, ' ');

  const secretViolation = checkTextForSecrets(unmasked);
  if (secretViolation) return secretViolation;

  const clean = unmasked.trim();
  for (const [blockedText, reasons] of knownBlockedPrompts.entries()) {
    if (clean === blockedText) {
      return (reasons && reasons[0]) || 'Semantic Policy Violation';
    }
  }

  return null;
}

// -------------------------------------------------------------
// Progressive Guardrail UI: Dynamic In-Page Risk Card & Composer Purity
// -------------------------------------------------------------
function removeDynamicRiskCard() {
  if (typeof document === 'undefined') return;
  try {
    const existing = document.getElementById('saif-risk-card');
    if (existing) existing.remove();
  } catch (_) {}
}

function renderDynamicRiskCard(riskScore, reasons = [], promptText = '') {
  if (typeof document === 'undefined' || typeof document.createElement !== 'function') return null;

  // STRICT MUTUAL EXCLUSIVITY: If central security overlay modal is present, NEVER render risk card
  if (typeof document.getElementById === 'function' && document.getElementById('saif-security-overlay')) {
    removeDynamicRiskCard();
    return null;
  }

  // Search Engine Immunity: Do not render dynamic risk card on search results pages where prompt was already submitted
  if (typeof window !== 'undefined' && localIsSearchEngineUrl(window.location.href)) {
    removeDynamicRiskCard();
    return null;
  }

  const score = typeof riskScore === 'number' ? riskScore : 0.95;

  // Clean prompt: remove risk card
  if (score < 0.40) {
    removeDynamicRiskCard();
    return null;
  }

  const isBlock = score >= 0.75;
  const tierColor = isBlock ? '#ef4444' : '#f59e0b';
  const tierBg = isBlock ? 'rgba(239, 68, 68, 0.15)' : 'rgba(245, 158, 11, 0.15)';
  const badgeText = isBlock ? '🛑 Policy Violation Detected (Will Block on Submit)' : '⚠️ Potential Risk Detected (Medium Confidence)';
  const subtitle = isBlock
    ? 'This prompt contains restricted enterprise data and will be blocked upon submission.'
    : 'Sensitive Intellectual Property or Policy Guidance Advisory. Review before submitting.';

  const reasonList = Array.isArray(reasons) ? reasons : (reasons ? [reasons] : []);
  const primaryReason = reasonList[0] || (isBlock ? 'Restricted Enterprise Data' : 'Sensitive IP Advisory');

  let card = (typeof document.getElementById === 'function') ? document.getElementById('saif-risk-card') : null;
  if (!card) {
    card = document.createElement('div');
    card.id = 'saif-risk-card';
    card.style.cssText = `
      position: fixed; bottom: 24px; right: 24px; z-index: 999998;
      width: 360px; max-width: 90vw; background: #18181b;
      border: 1.5px solid ${tierColor}; border-radius: 12px;
      padding: 14px 16px; color: #f4f4f5;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.7);
      transition: border-color 0.2s ease, box-shadow 0.2s ease;
    `;
    card.style.borderColor = tierColor;
    const parent = document.body || document.documentElement;
    if (parent && typeof parent.appendChild === 'function') parent.appendChild(card);
  } else {
    // Dynamic morphing: update border and existing styling
    card.style.borderColor = tierColor;
  }

  card.setAttribute('data-risk-tier', isBlock ? 'high' : 'medium');
  card.setAttribute('data-risk-score', score.toFixed(2));

  card.innerHTML = `
    <div style="display: flex; align-items: center; justify-content: space-between; margin-bottom: 8px;">
      <span style="display: inline-block; background: ${tierBg}; color: ${tierColor}; font-size: 11px; font-weight: 700; padding: 3px 8px; border-radius: 9999px; border: 1px solid ${tierColor};">
        ${badgeText}
      </span>
      <span style="font-size: 11px; color: ${tierColor}; font-weight: 700;">${score.toFixed(2)}</span>
    </div>
    <div style="font-size: 13px; font-weight: 600; color: #f4f4f5; margin-bottom: 4px;">
      ${primaryReason}
    </div>
    <div style="font-size: 11px; color: #a1a1aa; line-height: 1.4;">
      ${subtitle}
    </div>
  `;

  return card;
}

function positionInlineTag(tag, host) {
  // Deliberately no-op: never position tags around input box
}

function applyComposerGuardrail(composer, riskTier = 'clean', tagText = '') {
  // Pure composer invariant: Native inputs/textareas remain completely untouched
  clearComposerGuardrail(composer);
}

function clearComposerGuardrail(composer) {
  if (typeof document === 'undefined') return;
  const existingTag = document.getElementById('saif-inline-tag');
  if (existingTag) {
    try { existingTag.remove(); } catch (_) {}
  }

  if (composer) {
    const host = editableHostOf(composer) || composer;
    if (host && host.style) {
      if (host.dataset) delete host.dataset.saifGuardrail;
      host.style.boxShadow = '';
      host.style.border = '';
      host.style.outline = '';
    }
  }
  try {
    const tracked = document.querySelectorAll('[data-saif-guardrail]');
    for (const el of tracked) {
      if (el.dataset) delete el.dataset.saifGuardrail;
      if (el.style) {
        el.style.boxShadow = '';
        el.style.border = '';
        el.style.outline = '';
      }
    }
  } catch (_) {}
  removeDynamicRiskCard();
}

function triggerPromptPreFlight(text) {
  if (!text || typeof text !== 'string') {
    removeDynamicRiskCard();
    return;
  }
  const clean = text.trim();
  if (isPromptInPageOverridden(clean) || isPromptInPageOverridden(text)) {
    removeDynamicRiskCard();
    knownBlockedPrompts.delete(clean);
    return;
  }
  if (clean.length < 10) {
    removeDynamicRiskCard();
    return;
  }

  // Fast synchronous check before debounce
  const syncViol = checkSynchronousViolations(clean);
  if (syncViol) {
    if (isOutcomeSuppressedByToggles(syncViol, clean)) {
      removeDynamicRiskCard();
      return;
    }
    knownBlockedPrompts.set(clean, [syncViol]);
    activeBlockedPrompt = clean;
    if (!isPromptDismissed(clean) && !isPromptInPageOverridden(clean)) {
      renderDynamicRiskCard(0.95, [syncViol], clean);
    } else {
      removeDynamicRiskCard();
    }
    return;
  }

  const capturedGeneration = blockGeneration; // Snapshot generation before async gap
  clearTimeout(preFlightTimer);
  preFlightTimer = setTimeout(() => {
    sendPortMessage({
      type: 'PRIME_EVALUATION',
      prompt: clean,
      categoryToggles: activeCategoryToggles,
      ruleToggles: activeRuleToggles
    }, 2000).then(res => {
      // Discard stale result if a synchronous block modal was shown during the async gap
      if (blockGeneration !== capturedGeneration) return;
      if (res && res.verdict === 'BLOCK') {
        const ruleName = res.triggeredRule || res.reasons?.[0];
        if (isOutcomeSuppressedByToggles(ruleName, clean)) {
          console.log('[SAIF Sensor] Upstream prime BLOCK suppressed by client rule toggle on input:', ruleName);
          removeDynamicRiskCard();
          return;
        }
        knownBlockedPrompts.set(clean, res.reasons || ['Prompt blocked by enterprise security policy.']);
        activeBlockedPrompt = clean;
        if (!isPromptDismissed(clean) && !isPromptInPageOverridden(clean)) {
          const score = typeof res.riskScore === 'number' ? res.riskScore : 0.95;
          renderDynamicRiskCard(score, (res.reasons && res.reasons.length > 0) ? res.reasons : ['Policy Violation Detected (Will Block on Submit)'], clean);
        } else {
          removeDynamicRiskCard();
        }
      } else if (res && typeof res.riskScore === 'number' && res.riskScore >= 0.4 && res.riskScore < 0.75) {
        if (!isPromptDismissed(clean) && !isPromptInPageOverridden(clean)) {
          renderDynamicRiskCard(res.riskScore, (res.reasons && res.reasons.length > 0) ? res.reasons : ['Potential Sensitive IP'], clean);
        } else {
          removeDynamicRiskCard();
        }
      } else {
        removeDynamicRiskCard();
      }
    }).catch(() => {});
  }, 120);
}

function abortPendingThinkingState(composer, originalPrompt) {
  if (typeof document === 'undefined') return;

  // 1. If Gemini / Claude / ChatGPT has a visible "Stop response" button, click it to abort the stream
  const stopButton = (typeof document.querySelector === 'function')
    ? document.querySelector('button[aria-label*="Stop"], button[aria-label*="stop"], .stop-button, [data-testid*="stop"]')
    : null;
  if (stopButton && typeof stopButton.click === 'function') {
    try { stopButton.click(); } catch (_) {}
  }

  // 2. Remove or hide any pending empty thinking-dots / pulsing-dots turn in chat
  const pendingDots = (typeof document.querySelectorAll === 'function')
    ? document.querySelectorAll('.thinking-dots, .sparkle-dots, .pulsing-dots, [aria-label*="Thinking"], [data-testid*="thinking"], .loading-dots')
    : [];
  for (const el of pendingDots) {
    try {
      const parentBubble = (el.closest && typeof el.closest === 'function')
        ? (el.closest('.pending-turn, .chat-turn, message-content, [role="article"], .model-response, .response-container') || el)
        : el;
      if (parentBubble && typeof parentBubble.remove === 'function') {
        parentBubble.remove();
      }
    } catch (_) {}
  }

  // 3. Restore the blocked prompt text into the composer if it was cleared
  const target = composer || findPromptInput();
  if (target && originalPrompt) {
    const currentText = getPromptText(target);
    if (!currentText || currentText.trim().length === 0) {
      injectSanitizedText(target, originalPrompt);
    }
  }
}

// -------------------------------------------------------------
// Core DLP Foundations: Canonical Whitelist, Entropy & Inline Directives
// -------------------------------------------------------------
var PUBLIC_TEST_CREDENTIALS = (typeof PUBLIC_TEST_CREDENTIALS !== 'undefined') ? PUBLIC_TEST_CREDENTIALS : new Set([
  'AKIAIOSFODNN7EXAMPLE',
  'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY',
  '000-00-0000',
  '0000-00-00-0000',
  '0000-00-00-0000'
]);

function isPublicTestCredential(token) {
  if (!token || typeof token !== 'string') return false;
  const t = token.trim();
  if (PUBLIC_TEST_CREDENTIALS.has(t)) return true;
  if (/^sk-(?:proj-)?test-[a-zA-Z0-9_-]+$/i.test(t)) return true;
  if (/^ghp_0{20,}$/.test(t)) return true;
  if (/^glpat-0{20,}$/.test(t)) return true;
  if (/^npm_0{20,}$/.test(t)) return true;
  if (/^AKIA0{16}$/.test(t)) return true;
  if (/^sk_live_0{20,}$/.test(t)) return true;
  return false;
}

function calculateShannonEntropy(str) {
  if (!str || typeof str !== 'string') return 0;
  const len = str.length;
  if (len === 0) return 0;
  const freq = {};
  for (let i = 0; i < len; i++) {
    const ch = str[i];
    freq[ch] = (freq[ch] || 0) + 1;
  }
  let entropy = 0;
  for (const ch in freq) {
    const p = freq[ch] / len;
    entropy -= p * Math.log2(p);
  }
  return entropy;
}

function parseInlineDirectives(text) {
  if (!text || typeof text !== 'string') {
    return { globalIgnore: false, lineDirectives: new Map() };
  }
  let globalIgnore = false;
  const lineDirectives = new Map();
  const lines = text.split('\n');
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const directiveMatch = line.match(/(?:\/\/|#|\/\*|<!--)\s*saif:(?:ignore|allow-sample|ignore-all|allow-all)(?:\[([a-zA-Z0-9_\-, ]+)\])?/i);
    if (directiveMatch) {
      if (line.includes('saif:ignore-all') || line.includes('saif:allow-all')) {
        globalIgnore = true;
      }
      const targets = new Set();
      const ruleSpec = directiveMatch[1];
      if (ruleSpec) {
        const parts = ruleSpec.split(',').map(s => s.trim().toLowerCase());
        for (const p of parts) targets.add(p);
      } else {
        targets.add('*');
      }
      lineDirectives.set(i, targets);
    }
  }
  return { globalIgnore, lineDirectives };
}

// -------------------------------------------------------------
// Synchronous Fast-Pattern Scanner for Capture-Phase Decisions
// -------------------------------------------------------------
const INSTANT_SECRET_PATTERNS = [
  { id: 'pat-aws-key', name: 'AWS Access Key ID', regex: /\bAKIA[0-9A-Z]{16}\b/g, placeholder: 'AWS_KEY', reason: 'Exposed AWS Access Key ID' },
  { id: 'pat-aws-temp-key', name: 'Temporary AWS Access Key', regex: /\bASIA[0-9A-Z]{16}\b/g, placeholder: 'AWS_TEMP_KEY', reason: 'Exposed Temporary AWS Access Key' },
  { id: 'pat-jwt-token', name: 'JSON Web Token', regex: /eyJ[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+\.[A-Za-z0-9-_=]+/g, placeholder: 'JWT_TOKEN', reason: 'Exposed JSON Web Token (JWT)' },
  { id: 'pat-gh-token', name: 'GitHub Token', regex: /\bgh[pousr]_[A-Za-z0-9_]{36,255}\b/g, placeholder: 'GITHUB_TOKEN', reason: 'Exposed GitHub Token' },
  { id: 'pat-gl-token', name: 'GitLab Token', regex: /\bglpat-[0-9a-zA-Z_\-]{20,255}\b/g, placeholder: 'GITLAB_TOKEN', reason: 'Exposed GitLab Personal Access Token' },
  { id: 'pat-stripe-key', name: 'Stripe Live API Key', regex: /\bsk_live_[0-9a-zA-Z]{24,100}\b/g, placeholder: 'STRIPE_KEY', reason: 'Exposed Stripe Live API Key' },
  { id: 'pat-openai-key', name: 'OpenAI Secret Key', regex: /\b(?:sk-(?:(?:proj-|admin-)[a-zA-Z0-9_\-]{32,64}|[a-zA-Z0-9]{32,64}))\b/g, placeholder: 'OPENAI_KEY', reason: 'Exposed OpenAI API Key' },
  { id: 'pat-anthropic-key', name: 'Anthropic API Key', regex: /\bsk-ant-[a-zA-Z0-9_\-]{32,64}\b/g, placeholder: 'ANTHROPIC_KEY', reason: 'Exposed Anthropic API Key' },
  { id: 'pat-ssn', name: 'US Social Security Number', regex: /\b\d{3}[- ]\d{2}[- ]\d{4}\b/g, placeholder: 'SSN', reason: 'Exposed US Social Security Number (SSN)' },
  { id: 'pat-private-key', name: 'Private Cryptographic Key', regex: /-----BEGIN (?:[A-Z0-9_-]+ )?PRIVATE KEY(?: BLOCK)?-----[\s\S]*?-----END (?:[A-Z0-9_-]+ )?PRIVATE KEY(?: BLOCK)?-----|-----BEGIN (?:[A-Z0-9_-]+ )?PRIVATE KEY(?: BLOCK)?-----[^\r\n]*/g, placeholder: 'PRIVATE_KEY', reason: 'Exposed Private Cryptographic Key' }
];

// -------------------------------------------------------------
// Dynamic Category and Rule Toggles Synchronization
// -------------------------------------------------------------
let activeCategoryToggles = {};
let activeRuleToggles = {};
let activeCustomRules = [];

function syncTogglesToMainWorld() {
  try {
    if (typeof document !== 'undefined' && document.documentElement) {
      document.documentElement.dataset.saifCategoryToggles = JSON.stringify(activeCategoryToggles);
      document.documentElement.dataset.saifRuleToggles = JSON.stringify(activeRuleToggles);
      document.documentElement.dataset.saifSnoozeUntil = String(cachedSnoozeUntil);
    }
  } catch (_) {}
  try {
    if (typeof window !== 'undefined' && window.postMessage) {
      window.postMessage({
        type: '__SAIF_TOGGLES_UPDATE__',
        categoryToggles: activeCategoryToggles,
        ruleToggles: activeRuleToggles,
        customRules: activeCustomRules,
        snoozeUntil: cachedSnoozeUntil
      }, '*');
    }
  } catch (_) {}
}

function setActiveToggles(catToggles = {}, rToggles = {}) {
  activeCategoryToggles = catToggles || {};
  activeRuleToggles = rToggles || {};
  syncTogglesToMainWorld();
}

if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
  chrome.storage.local.get(['categoryToggles', 'ruleToggles', 'custom_rules', 'snoozeUntil'], (res) => {
    if (res) {
      if (res.categoryToggles) activeCategoryToggles = res.categoryToggles;
      if (res.ruleToggles) activeRuleToggles = res.ruleToggles;
      if (Array.isArray(res.custom_rules)) activeCustomRules = res.custom_rules;
      if (typeof res.snoozeUntil === 'number') cachedSnoozeUntil = res.snoozeUntil;
      syncTogglesToMainWorld();
    }
  });

  if (chrome.storage.onChanged) {
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === 'local') {
        if (changes.categoryToggles) {
          activeCategoryToggles = changes.categoryToggles.newValue || {};
          dismissedPrompts.clear();
          knownBlockedPrompts.clear();
        }
        if (changes.ruleToggles) {
          activeRuleToggles = changes.ruleToggles.newValue || {};
          dismissedPrompts.clear();
          knownBlockedPrompts.clear();
        }
        if (changes.custom_rules) activeCustomRules = changes.custom_rules.newValue || [];
        if (changes.snoozeUntil) {
          cachedSnoozeUntil = changes.snoozeUntil.newValue || 0;
          if (cachedSnoozeUntil > Date.now()) {
            // Multi-tab reactive synchronization: if another tab activated Protection Snooze,
            // immediately unmount active ambient risk cards and security modals in this tab.
            removeDynamicRiskCard();
            const overlay = document.getElementById('saif-security-overlay');
            if (overlay) overlay.remove();
          }
        }
        syncTogglesToMainWorld();
      }
    });
  }
}

function checkTextForSecrets(text) {
  if (!text || text.length < 8) return null;

  // 1. Direct Whitelist Filter on whole prompt
  if (isPublicTestCredential(text)) {
    return null;
  }

  // 2. Inline Code Directives Check (// saif:ignore)
  const { globalIgnore, lineDirectives } = parseInlineDirectives(text);
  if (globalIgnore) {
    return null;
  }

  // 2.5. Custom Rules Check (Action Precedence: BLOCK)
  let customMatcher = typeof matchCustomRules === 'function' ? matchCustomRules : null;
  if (!customMatcher && typeof window !== 'undefined' && typeof window.matchCustomRules === 'function') {
    customMatcher = window.matchCustomRules;
  }
  if (!customMatcher && typeof globalThis !== 'undefined' && typeof globalThis.matchCustomRules === 'function') {
    customMatcher = globalThis.matchCustomRules;
  }
  if (customMatcher && activeCustomRules && activeCustomRules.length > 0) {
    const cMatches = customMatcher(text, activeCustomRules);
    if (cMatches && cMatches.length > 0) {
      const activeBlockMatches = cMatches.filter(m => m.action === 'BLOCK' && !isTokenInPageOverridden(m.token || m.matchedText || ''));
      if (activeBlockMatches.length > 0) {
        return activeBlockMatches[0].reason;
      }
    }
  }

  // 3. Delegate to matchStandardRules if loaded
  const matcher = (typeof matchStandardRules === 'function')
    ? matchStandardRules
    : (typeof window !== 'undefined' && typeof window.matchStandardRules === 'function'
      ? window.matchStandardRules
      : (typeof globalThis !== 'undefined' && typeof globalThis.matchStandardRules === 'function' ? globalThis.matchStandardRules : null));

  if (matcher) {
    const matches = matcher(text, activeCategoryToggles, activeRuleToggles);
    if (matches && matches.length > 0) {
      console.log('[SAIF Content] checkTextForSecrets raw matches:', JSON.stringify(matches.map(m => ({ rule: m.name, tok: m.matchedToken || m.token }))), 'overriddenTokens:', Array.from(inPageOverriddenTokens.keys()));
      const activeMatches = matches.filter(m => !isTokenInPageOverridden(m.matchedToken || m.token || m.matched_text || ''));
      console.log('[SAIF Content] checkTextForSecrets activeMatches count:', activeMatches.length);
      if (activeMatches.length > 0) {
        return activeMatches[0].reason;
      }
    }
    return null;
  }

  // 4. Built-in Instant Secret Patterns Fallback
  for (const p of INSTANT_SECRET_PATTERNS) {
    if (activeRuleToggles && activeRuleToggles[p.id] === false) continue;
    if (p.id === 'pat-ssn' && activeCategoryToggles && activeCategoryToggles['pii'] === false) continue;
    if (p.id && (p.id.includes('aws') || p.id.includes('cloud')) && activeCategoryToggles && activeCategoryToggles['cloud_credentials'] === false) continue;

    const rx = new RegExp(p.regex.source, 'g');
    let m;
    while ((m = rx.exec(text)) !== null) {
      const token = m[0];

      // Item-level override check
      if (isTokenInPageOverridden(token)) {
        continue;
      }

      // Whitelist fixture check
      if (isPublicTestCredential(token)) {
        continue;
      }

      // Shannon entropy check for high-entropy tokens
      const minEntropy = (p.id.includes('aws') || p.id.includes('key') || p.id.includes('token')) ? 2.8 : 0;
      if (minEntropy > 0) {
        const entropy = calculateShannonEntropy(token);
        if (entropy < minEntropy) {
          continue;
        }
      }

      // Line directive suppression check
      const prefix = text.substring(0, m.index);
      const lineIndex = prefix.split('\n').length - 1;
      const currDir = lineDirectives.get(lineIndex);
      const prevDir = lineDirectives.get(lineIndex - 1);
      const isSuppressed = (dir) => {
        if (!dir) return false;
        if (dir.has('*')) return true;
        const idLower = p.id.toLowerCase();
        const shortId = idLower.replace(/^pat-/, '');
        return dir.has(idLower) || dir.has(shortId);
      };
      if (isSuppressed(currDir) || isSuppressed(prevDir)) {
        continue;
      }

      return p.reason;
    }
  }
  return null;
}

function localSanitizeText(text) {
  if (!text) return { sanitized: text, replacements: 0 };

  const isWhitelist = (typeof isPublicTestCredential === 'function')
    ? isPublicTestCredential
    : (typeof globalThis !== 'undefined' && typeof globalThis.isPublicTestCredential === 'function' ? globalThis.isPublicTestCredential : null);

  const getEntropy = (typeof calculateShannonEntropy === 'function')
    ? calculateShannonEntropy
    : (typeof globalThis !== 'undefined' && typeof globalThis.calculateShannonEntropy === 'function' ? globalThis.calculateShannonEntropy : null);

  const parseDirectives = (typeof parseInlineDirectives === 'function')
    ? parseInlineDirectives
    : (typeof globalThis !== 'undefined' && typeof globalThis.parseInlineDirectives === 'function' ? globalThis.parseInlineDirectives : null);

  const isRuleActiveFn = (typeof isRuleActive === 'function')
    ? isRuleActive
    : (typeof globalThis !== 'undefined' && typeof globalThis.isRuleActive === 'function' ? globalThis.isRuleActive : null);

  if (parseDirectives) {
    const { globalIgnore } = parseDirectives(text);
    if (globalIgnore) return { sanitized: text, replacements: 0 };
  }

  let sanitized = text;
  let count = 0;

  const patterns = (typeof compiledRules !== 'undefined' && Array.isArray(compiledRules) && compiledRules.length > 0)
    ? compiledRules
    : INSTANT_SECRET_PATTERNS;

  for (const p of patterns) {
    // Check if this rule is disabled via category or rule toggles
    if (isRuleActiveFn && !isRuleActiveFn(p, activeCategoryToggles, activeRuleToggles)) {
      continue;
    }

    const rx = p.regexStr ? new RegExp(p.regexStr, 'g') : new RegExp(p.regex.source, 'g');
    if (!rx) continue;
    rx.lastIndex = 0;
    sanitized = sanitized.replace(rx, (match, offset, fullStr) => {
      // 1. Skip canonical public test credentials
      if (isWhitelist && isWhitelist(match)) {
        return match;
      }
      // 2. Skip low-entropy mock tokens
      const minEntropy = p.minEntropy || (p.id && (p.id.includes('aws') || p.id.includes('key') || p.id.includes('token')) ? 2.8 : 0);
      if (minEntropy > 0 && getEntropy) {
        if (getEntropy(match) < minEntropy) {
          return match;
        }
      }
      // 3. Skip line directives if present
      if (parseDirectives) {
        const prefix = fullStr.substring(0, offset);
        const lineIdx = prefix.split('\n').length - 1;
        const { lineDirectives } = parseDirectives(fullStr);
        const currDir = lineDirectives ? lineDirectives.get(lineIdx) : null;
        const prevDir = lineDirectives ? lineDirectives.get(lineIdx - 1) : null;
        const ruleId = (p.id || '').toLowerCase();
        if (currDir && (currDir.has('*') || currDir.has(ruleId))) return match;
        if (prevDir && (prevDir.has('*') || prevDir.has(ruleId))) return match;
      }

      count++;
      let trailingPunct = '';
      if (p.id === 'pat-db-uri' || p.id === 'pat-slack-webhook') {
        const pMatch = match.match(/[,.;:!?)]+$/);
        if (pMatch) {
          trailingPunct = pMatch[0];
        }
      }
      return `[${p.placeholder || 'SECRET'}_0]${trailingPunct}`;
    });
  }

  // Custom Rules REDACT sanitization
  let cMatcher = typeof matchCustomRules === 'function' ? matchCustomRules : null;
  if (!cMatcher && typeof window !== 'undefined' && typeof window.matchCustomRules === 'function') {
    cMatcher = window.matchCustomRules;
  }
  if (!cMatcher && typeof globalThis !== 'undefined' && typeof globalThis.matchCustomRules === 'function') {
    cMatcher = globalThis.matchCustomRules;
  }
  if (cMatcher && activeCustomRules && activeCustomRules.length > 0) {
    const cMatches = cMatcher(sanitized, activeCustomRules);
    const redactMatches = cMatches ? cMatches.filter(m => m.action === 'REDACT') : [];
    if (redactMatches.length > 0) {
      let customSanitizer = typeof sanitizeCustomPrompt === 'function' ? sanitizeCustomPrompt : null;
      if (!customSanitizer && typeof window !== 'undefined' && typeof window.sanitizeCustomPrompt === 'function') {
        customSanitizer = window.sanitizeCustomPrompt;
      }
      if (!customSanitizer && typeof globalThis !== 'undefined' && typeof globalThis.sanitizeCustomPrompt === 'function') {
        customSanitizer = globalThis.sanitizeCustomPrompt;
      }
      if (customSanitizer) {
        const cSanRes = customSanitizer(sanitized, redactMatches);
        sanitized = cSanRes.sanitizedText;
        count += cSanRes.replacements;
      }
    }
  }

  return { sanitized, replacements: count };
}

// -------------------------------------------------------------
// High-Bandwidth Persistent Port Pipeline & Keep-Alive Heartbeat
// -------------------------------------------------------------
function establishPortConnection() {
  if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.connect || !chrome.runtime.id) return;

  try {
    port = chrome.runtime.connect({ name: 'saif-channel' });

    port.onMessage.addListener((msg) => {
      if (msg.type === 'DOMAIN_WHITELIST_UPDATED') {
        cachedDomainWhitelist = msg.whitelisted || [];
        syncWhitelistStateToDOM();
        return;
      }

      if (msg.type === 'PONG') {
        return;
      }

      if (msg.requestId && pendingRequests.has(msg.requestId)) {
        const { resolve } = pendingRequests.get(msg.requestId);
        pendingRequests.delete(msg.requestId);
        resolve(msg);
      }
    });

    port.onDisconnect.addListener(() => {
      // Must read chrome.runtime.lastError to prevent Chrome flagging an unchecked runtime.lastError
      const err = chrome.runtime.lastError;
      if (err) {
        console.debug('[SAIF Sensor] Port disconnected:', err.message);
      } else {
        console.log('[SAIF Sensor] Port disconnected.');
      }
      port = null;
      clearInterval(keepAliveTimer);

      // Only attempt reconnection if the extension context is still valid
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
        setTimeout(establishPortConnection, 1000);
      }
    });

    clearInterval(keepAliveTimer);
    keepAliveTimer = setInterval(() => {
      if (port && typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
        try {
          port.postMessage({ type: 'PING' });
        } catch (e) {
          clearInterval(keepAliveTimer);
        }
      } else {
        clearInterval(keepAliveTimer);
      }
    }, 25000);

    console.log('[SAIF Sensor] Persistent port pipeline connected.');
  } catch (err) {
    console.warn('[SAIF Sensor] Connection failed:', err.message);
    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.id) {
      setTimeout(establishPortConnection, 2000);
    }
  }
}

establishPortConnection();

function sendPortMessage(payload, timeoutMs = 2500) {
  return new Promise((resolve) => {
    const requestId = crypto.randomUUID ? crypto.randomUUID() : ('req-' + Math.random());
    const message = { ...payload, requestId };

    let timer = setTimeout(() => {
      if (pendingRequests.has(requestId)) {
        console.warn(`[SAIF Sensor] Request ${requestId} timed out after ${timeoutMs}ms.`);
        pendingRequests.delete(requestId);
        if (payload.type === 'EVALUATE_PROMPT') {
          resolve({
            verdict: 'BLOCK',
            timeout: true,
            reasons: ['SAIF evaluation bridge timed out. Outgoing prompt blocked by enterprise security posture.']
          });
        } else {
          resolve(null);
        }
      }
    }, timeoutMs);

    pendingRequests.set(requestId, {
      resolve: (data) => {
        clearTimeout(timer);
        resolve(data);
      }
    });

    if (port) {
      try {
        port.postMessage(message);
        return;
      } catch (err) {
        console.warn('[SAIF Sensor] Port postMessage error:', err.message);
      }
    }

    if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage && chrome.runtime.id) {
      try {
        chrome.runtime.sendMessage(message, (res) => {
          const err = chrome.runtime.lastError;
          clearTimeout(timer);
          pendingRequests.delete(requestId);
          if (err) {
            console.debug('[SAIF Sensor] runtime.sendMessage notice:', err.message);
            if (payload.type === 'EVALUATE_PROMPT') {
              resolve({
                verdict: 'BLOCK',
                reasons: ['SAIF background worker reconnecting. Outgoing prompt blocked by enterprise security posture.'],
                error: err.message
              });
            } else {
              resolve(null);
            }
            return;
          }
          resolve(res || (payload.type === 'EVALUATE_PROMPT' ? {
            verdict: 'BLOCK',
            fallback: true,
            reasons: ['No response from evaluation service. Blocked by enterprise security posture.']
          } : null));
        });
      } catch (sendErr) {
        clearTimeout(timer);
        pendingRequests.delete(requestId);
        if (payload.type === 'EVALUATE_PROMPT') {
          resolve({
            verdict: 'BLOCK',
            offline: true,
            reasons: ['Extension runtime disconnected. Blocked by enterprise security posture.']
          });
        } else {
          resolve(null);
        }
      }
    } else {
      clearTimeout(timer);
      pendingRequests.delete(requestId);
      if (payload.type === 'EVALUATE_PROMPT') {
        resolve({
          verdict: 'BLOCK',
          offline: true,
          reasons: ['Extension runtime offline. Blocked by enterprise security posture.']
        });
      } else {
        resolve(null);
      }
    }
  });
}

// -------------------------------------------------------------
// Agnostic DOM Traversal & Shadow DOM Piercing
// -------------------------------------------------------------
function getEventTarget(e) {
  let target = e.target;
  if (e.composedPath && typeof e.composedPath === 'function') {
    const path = e.composedPath();
    if (path && path.length > 0) target = path[0];
  }
  if (target && target.nodeType === 3) {
    target = target.parentElement;
  }
  return target;
}

function isTextComposer(el) {
  if (!el || el.nodeType !== 1) return false;
  if (el.tagName === 'TEXTAREA') return true;
  if (el.isContentEditable) return true;
  if ((el.getAttribute && el.getAttribute('role') === 'button') || el.role === 'button') return false;
  if (el.tagName === 'INPUT') {
    if (el.name === 'btnK' || el.name === 'btnI') return false;
    const type = (el.type || 'text').toLowerCase();
    if (type === 'submit' || type === 'button' || type === 'hidden' || type === 'image' || type === 'reset' || type === 'checkbox' || type === 'radio' || type === 'password') {
      return false;
    }
    return true;
  }
  return false;
}

function editableHostOf(element) {
  if (!element || typeof element.closest !== 'function') return null;
  // Prefer the outermost contenteditable container so multi-paragraph prompts are captured in full
  const container = element.closest('[contenteditable="true"],[contenteditable=""],[contenteditable="plaintext-only"]');
  if (container) return container;
  if (element.isContentEditable) return element;
  if (isTextComposer(element)) return element;
  return null;
}

function findPromptInput() {
  if (typeof document === 'undefined') return null;
  const active = document.activeElement;
  if (isTextComposer(active)) {
    return editableHostOf(active) || active;
  }
  if (lastFocusedComposer && document.contains(lastFocusedComposer) && isTextComposer(lastFocusedComposer)) {
    return lastFocusedComposer;
  }
  // Check custom web components (e.g. Gemini rich-textarea, custom composers)
  const customRoots = document.querySelectorAll('rich-textarea, .input-area-container, [role="region"]');
  for (const rootEl of customRoots) {
    const root = rootEl.shadowRoot || rootEl;
    const inner = root.querySelector('[contenteditable="true"], textarea, [role="textbox"]');
    if (inner && isTextComposer(inner)) return inner;
  }
  const allInputs = document.querySelectorAll('textarea, [contenteditable="true"], input[name="q"], input[type="text"], input[type="search"], input:not([type])');
  for (const el of allInputs) {
    if (isTextComposer(el)) return el;
  }
  return null;
}

function getPromptText(element) {
  if (!element) return '';
  if (element.tagName === 'TEXTAREA' || element.tagName === 'INPUT') {
    return (element.value || '').trim();
  }
  if (element.isContentEditable || (element.getAttribute && element.getAttribute('contenteditable') === 'true') || (typeof element.closest === 'function' && element.closest('[contenteditable="true"]'))) {
    let blockTags = null;
    if (typeof element.querySelectorAll === 'function') {
      try {
        const found = element.querySelectorAll('p, li');
        if (found && found.length > 0) {
          blockTags = found;
        }
      } catch (_) {}
      if (!blockTags || blockTags.length === 0) {
        try {
          const pTags = element.querySelectorAll('p');
          const liTags = element.querySelectorAll('li');
          if ((pTags && pTags.length > 0) || (liTags && liTags.length > 0)) {
            blockTags = [...(pTags || []), ...(liTags || [])];
          }
        } catch (_) {}
      }
      if (!blockTags || blockTags.length === 0) {
        try {
          const divTags = element.querySelectorAll(':scope > div, div');
          if (divTags && divTags.length > 0) {
            blockTags = divTags;
          }
        } catch (_) {}
      }
    }
    if (blockTags && blockTags.length > 0) {
      const blockList = Array.from(blockTags).filter(el => {
        if (el.tagName === 'P' && typeof el.closest === 'function' && el.closest('li')) return false;
        return true;
      });
      const lines = [];
      for (const el of blockList) {
        let t = (el.innerText || el.textContent || '').replace(/\r\n/g, '\n').replace(/^\n+|\n+$/g, '');
        if (el.tagName === 'LI') {
          const trimmed = t.trim();
          if (trimmed && !trimmed.startsWith('-') && !trimmed.startsWith('•') && !trimmed.startsWith('*') && !/^\d+[\.\)]/.test(trimmed)) {
            t = '- ' + trimmed;
          }
        }
        lines.push(t);
      }
      return lines.join('\n').trim();
    }
  }
  return (element.innerText || element.textContent || '').trim();
}

// -------------------------------------------------------------
// Universal Prototype Setter Input Injection (React / Vue / Angular / Native)
// -------------------------------------------------------------
function setNativeControlValue(element, value) {
  const prototype = element.tagName === 'TEXTAREA'
    ? HTMLTextAreaElement.prototype
    : HTMLInputElement.prototype;
  const descriptor = Object.getOwnPropertyDescriptor(prototype, 'value');
  if (descriptor && descriptor.set) {
    descriptor.set.call(element, value);
  } else {
    element.value = value;
  }
}

function injectSanitizedText(targetElement, text) {
  if (!targetElement) return;

  targetElement.focus();

  if (targetElement.tagName === 'TEXTAREA' || targetElement.tagName === 'INPUT') {
    const start = targetElement.selectionStart ?? (targetElement.value ? targetElement.value.length : 0);
    const end = targetElement.selectionEnd ?? start;
    const currentVal = targetElement.value || '';
    const newVal = currentVal.substring(0, start) + text + currentVal.substring(end);

    setNativeControlValue(targetElement, newVal);

    const caretPos = start + text.length;
    try {
      targetElement.setSelectionRange(caretPos, caretPos);
    } catch (_) {}

    const inputEvt = new InputEvent('input', {
      bubbles: true,
      cancelable: true,
      inputType: 'insertFromPaste',
      data: text
    });
    targetElement.dispatchEvent(inputEvt);
    targetElement.dispatchEvent(new Event('change', { bubbles: true }));
  } else if (targetElement.isContentEditable) {
    let inserted = false;
    try {
      inserted = document.execCommand('insertText', false, text);
    } catch (_) {}

    if (!inserted) {
      const selection = window.getSelection();
      if (selection && selection.rangeCount > 0) {
        const range = selection.getRangeAt(0);
        range.deleteContents();
        const textNode = document.createTextNode(text);
        range.insertNode(textNode);
        range.setStartAfter(textNode);
        range.setEndAfter(textNode);
        selection.removeAllRanges();
        selection.addRange(range);
      } else {
        targetElement.textContent = (targetElement.textContent || '') + text;
      }
    }

    const inputEvt = new InputEvent('input', {
      bubbles: true,
      cancelable: true,
      inputType: 'insertFromPaste',
      data: text
    });
    targetElement.dispatchEvent(inputEvt);
  }
}

// -------------------------------------------------------------
// Capture-Phase Front-Door DOM Traps (Enter Key, Send Button & Form Submit)
// -------------------------------------------------------------
function handleKeydownInterception(e) {
  if (isCurrentDomainWhitelisted()) return;
  if (e.key !== 'Enter' || e.shiftKey || e.isComposing) return;

  const target = getEventTarget(e);
  const composer = editableHostOf(target) || (isTextComposer(target) ? target : null);
  if (!composer) return;

  lastTargetComposer = composer;
  const text = getPromptText(composer);
  const clean = (text || '').trim();

  // Instant removal of in-page card upon submission attempt; cancel any pending pre-flight debounce
  clearTimeout(preFlightTimer);
  removeDynamicRiskCard();

  if (isPromptInPageOverridden(clean) || isPromptInPageOverridden(text) || areAllPromptViolationsOverridden(text)) {
    console.log('[SAIF Sensor] Prompt matches in-page override. Bypassing keydown interception.');
    setSubmissionFlag();
    return;
  }

  const violation = checkSynchronousViolations(text);
  if (violation) {
    if (cachedEgressMode === 'audit_only') {
      console.log('[SAIF Sensor] Audit-Only mode: logging simulated Enter submission block without halting.');
      sendPortMessage({
        type: 'RECORD_SIMULATED_BLOCK_EVENT',
        prompt: text,
        reasons: [violation],
        triggeredRule: violation,
        riskScore: 0.85,
        originUrl: (typeof window !== 'undefined' && window.location) ? window.location.href : 'unknown'
      }, 1000).catch(() => {});
      return;
    }
    // HALT before page React/Vue/DeepSeek framework listener ever sees the event
    e.preventDefault();
    e.stopImmediatePropagation();
    console.warn('[SAIF Sensor] Synchronously blocked sensitive Enter keydown submission:', violation);
    activeBlockedPrompt = text;
    clearComposerGuardrail(composer);
    sendPortMessage({
      type: 'RECORD_BLOCK_EVENT',
      prompt: text,
      reasons: [violation],
      triggeredRule: violation,
      riskScore: 0.95
    }, 1000).catch(() => {});
    showBlockUI([violation], text, violation, 0.95, true);
    return;
  }

  // Check custom rules REDACT / WARN actions
  if (customMatcher && activeCustomRules && activeCustomRules.length > 0) {
    const cMatches = customMatcher(text, activeCustomRules);
    if (cMatches && cMatches.length > 0) {
      const redactMatches = cMatches.filter(m => m.action === 'REDACT');
      if (redactMatches.length > 0) {
        let customSanitizer = typeof sanitizeCustomPrompt === 'function' ? sanitizeCustomPrompt : null;
        if (!customSanitizer && typeof window !== 'undefined' && typeof window.sanitizeCustomPrompt === 'function') {
          customSanitizer = window.sanitizeCustomPrompt;
        }
        if (customSanitizer) {
          const sanRes = customSanitizer(text, redactMatches);
          if (sanRes.replacements > 0) {
            e.preventDefault();
            e.stopImmediatePropagation();
            injectSanitizedText(composer, sanRes.sanitizedText);
            console.log('[SAIF Sensor] In-place redacted custom tokens on Enter:', sanRes.replacements);
            return;
          }
        }
      }
      const warnMatches = cMatches.filter(m => m.action === 'WARN');
      if (warnMatches.length > 0) {
        renderDynamicRiskCard(0.60, warnMatches.map(m => m.reason), text);
      }
    }
  }

  // Check known blocked prompts cache
  if (knownBlockedPrompts.has(clean) && !isPromptDismissed(clean) && !isPromptInPageOverridden(clean) && !areAllPromptViolationsOverridden(text)) {
    e.preventDefault();
    e.stopImmediatePropagation();
    const reasons = knownBlockedPrompts.get(clean);
    activeBlockedPrompt = text;
    clearComposerGuardrail(composer);
    showBlockUI(reasons, text, reasons[0], 0.95, true);
    return;
  }
  
  if (clean.length > 0) {
    if (isPromptInPageOverridden(clean) || isPromptInPageOverridden(text) || areAllPromptViolationsOverridden(text)) return;
    const capturedGeneration = blockGeneration;
    // Asynchronously prime evaluation in background.js with saif.exe/Docker gateway
    sendPortMessage({
      type: 'PRIME_EVALUATION',
      prompt: text,
      categoryToggles: activeCategoryToggles,
      ruleToggles: activeRuleToggles,
      overriddenTokens: Array.from(inPageOverriddenTokens.keys())
    }, 3000).then(res => {
      if (blockGeneration !== capturedGeneration) return;
      if (isPromptInPageOverridden(clean) || isPromptInPageOverridden(text) || isPromptDismissed(clean) || areAllPromptViolationsOverridden(text)) return;
      if (res && res.verdict === 'BLOCK') {
        const ruleName = res.triggeredRule || res.reasons?.[0];
        if (isOutcomeSuppressedByToggles(ruleName, text)) {
          return;
        }
        knownBlockedPrompts.set(clean, res.reasons || ['Prompt blocked by enterprise security policy.']);
        activeBlockedPrompt = text;
        clearComposerGuardrail(composer);
        console.warn('[SAIF Sensor] Front-door evaluation returned BLOCK:', res.reasons);
        showBlockUI(res.reasons || ['Prompt blocked by SAIF AI Firewall policy.'], text, res.reasons?.[0], res.riskScore || 0.95, true);
      } else if (res && typeof res.riskScore === 'number' && res.riskScore >= 0.4 && res.riskScore < 0.75) {
        if (!isPromptDismissed(text) && !isPromptInPageOverridden(text)) {
          sendPortMessage({
            type: 'RECORD_ADVISORY_EVENT',
            prompt: text,
            reasons: res.reasons || [],
            riskScore: res.riskScore
          }).catch(() => {});
        }
      }
    }).catch(() => {});

  }
}

function isSubmitButtonElement(el) {
  if (!el || el.nodeType !== 1) return null;

  // Never treat an editable composer or its contents as a submit button
  if (editableHostOf(el)) return null;

  // 1. Standard button controls & ARIA button role, including submit inputs & Google Search buttons
  const btn = el.closest('button, [role="button"], input[type="submit"], input[type="button"], input[name="btnK"], input[name="btnI"]');
  if (btn) return btn;

  // 2. Clickable icon buttons (e.g. DeepSeek send icon)
  const svg = el.tagName === 'svg' ? el : el.closest('svg');
  if (svg) {
    const wrapper = svg.parentElement;
    if (wrapper && (typeof document === 'undefined' || wrapper !== document.body) && !editableHostOf(wrapper)) {
      return wrapper;
    }
    return svg;
  }

  return null;
}

function findSubmitButtonForComposer(composer) {
  if (!composer) return null;
  if (composer.form) {
    const btn = composer.form.querySelector('[data-testid="send-button"], button.send-button, #deepseek-send-btn, button[type="submit"], input[type="submit"], button');
    if (btn && btn !== composer) return btn;
  }
  let curr = composer.parentElement;
  while (curr && curr !== document.body) {
    if (curr.matches && curr.matches('form, .card, [role="region"], [role="dialog"], section, .input-area-container, .bottom-container, [class*="input"], [class*="composer"]')) {
      const btn = curr.querySelector('[data-testid="send-button"], button.send-button, #deepseek-send-btn, button[type="submit"], input[type="submit"], button.btn, button');
      if (btn && btn !== composer) return btn;
    }
    curr = curr.parentElement;
  }
  const container = composer.closest && composer.closest('form, .card, [role="region"], [role="dialog"], section, .input-area-container, .bottom-container, [class*="input"], [class*="composer"]');
  if (container) {
    const btn = container.querySelector('[data-testid="send-button"], button.send-button, #deepseek-send-btn, button[type="submit"], input[type="submit"], button.btn, button');
    if (btn && btn !== composer) return btn;
  }
  return null;
}

function resolveTargetComposer(buttonElement) {
  // 1. Direct active element if it's an actual text composer
  const active = typeof document !== 'undefined' ? document.activeElement : null;
  if (isTextComposer(active)) {
    return active;
  }

  // 2. If button belongs to an HTML <form> or container (.card, dialog, section), find text composer
  if (buttonElement && typeof buttonElement.closest === 'function') {
    const formId = buttonElement.getAttribute ? buttonElement.getAttribute('form') : null;
    const container = (formId && typeof document !== 'undefined' ? document.getElementById(formId) : null) ||
                      buttonElement.closest('form, .card, [role="region"], [role="dialog"], section, rich-textarea, .input-area-container, .bottom-container, [class*="input"], [class*="composer"]');
    if (container) {
      const candidates = container.querySelectorAll('textarea, input, [contenteditable="true"]');
      // Pass 1: Prioritize any composer in this container that contains a secret
      for (const cand of candidates) {
        if (isTextComposer(cand) && cand !== buttonElement) {
          const val = getPromptText(cand);
          if (val && checkTextForSecrets(val)) return cand;
        }
      }
      // Pass 2: Prefer non-empty text input
      for (const cand of candidates) {
        if (isTextComposer(cand) && cand !== buttonElement) {
          const val = getPromptText(cand);
          if (val) return cand;
        }
      }
      // Pass 3: Any text composer
      for (const cand of candidates) {
        if (isTextComposer(cand) && cand !== buttonElement) {
          return cand;
        }
      }
    }
  }

  // 3. Last focused composer (e.g. user typed into search bar, then moved cursor to click submit button)
  if (lastFocusedComposer && typeof document !== 'undefined' && document.contains(lastFocusedComposer) && isTextComposer(lastFocusedComposer)) {
    return lastFocusedComposer;
  }

  // 4. Global fallback
  return findPromptInput();
}

function handleClickInterception(e) {
  if (isCurrentDomainWhitelisted()) return;
  const target = getEventTarget(e);
  if (!target) return;

  // Ignore clicks inside our own security overlay
  if (target.closest && target.closest('#saif-security-overlay')) return;

  // Clicks on or inside an editable composer are ALWAYS cursor navigation or text editing
  if (editableHostOf(target)) return;

  const button = isSubmitButtonElement(target);
  if (!button) return;

  // Check the primary resolved composer
  const composer = resolveTargetComposer(button);
  let candidateText = '';
  let violation = null;
  if (composer) {
    lastTargetComposer = composer;
    candidateText = getPromptText(composer);
    violation = checkSynchronousViolations(candidateText);
  }

  // Also scan all text composers in the containing form, card, dialog, or section
  if (!violation && button && typeof button.closest === 'function') {
    const formId = button.getAttribute ? button.getAttribute('form') : null;
    const container = (formId && typeof document !== 'undefined' ? document.getElementById(formId) : null) ||
                      button.closest('form, .card, [role="region"], [role="dialog"], section, rich-textarea, .input-area-container, .bottom-container, [class*="input"], [class*="composer"]');
    if (container) {
      const candidates = container.querySelectorAll('textarea, input, [contenteditable="true"]');
      for (const cand of candidates) {
        if (isTextComposer(cand) && cand !== button) {
          const text = getPromptText(cand);
          if (!candidateText && text) {
            candidateText = text;
            lastTargetComposer = cand;
          }
          violation = checkSynchronousViolations(text);
          if (violation) {
            candidateText = text;
            lastTargetComposer = cand;
            break;
          }
        }
      }
    }
  }

  // Instant removal of in-page card upon submission attempt; cancel any pending pre-flight debounce
  clearTimeout(preFlightTimer);
  removeDynamicRiskCard();

  const clean = (candidateText || '').trim();

  if (isPromptInPageOverridden(clean) || isPromptInPageOverridden(candidateText) || areAllPromptViolationsOverridden(candidateText)) {
    console.log('[SAIF Sensor] Prompt matches in-page override. Bypassing click interception.');
    setSubmissionFlag();
    return;
  }

  if (violation) {
    if (cachedEgressMode === 'audit_only') {
      console.log('[SAIF Sensor] Audit-Only mode: logging simulated Send Button click block without halting.');
      sendPortMessage({
        type: 'RECORD_SIMULATED_BLOCK_EVENT',
        prompt: candidateText,
        reasons: [violation],
        triggeredRule: violation,
        riskScore: 0.85,
        originUrl: (typeof window !== 'undefined' && window.location) ? window.location.href : 'unknown'
      }, 1000).catch(() => {});
      return;
    }
    // HALT before page framework click listener can initiate request or spawn thinking dots
    e.preventDefault();
    e.stopImmediatePropagation();
    console.warn('[SAIF Sensor] Synchronously blocked sensitive Send Button click submission:', violation);
    activeBlockedPrompt = candidateText;
    clearComposerGuardrail(composer || lastTargetComposer);
    sendPortMessage({
      type: 'RECORD_BLOCK_EVENT',
      prompt: candidateText,
      reasons: [violation],
      triggeredRule: violation,
      riskScore: 0.95
    }, 1000).catch(() => {});
    showBlockUI([violation], candidateText, violation, 0.95, true);
    return;
  }

  // Check known blocked prompts cache
  if (knownBlockedPrompts.has(clean) && !isPromptDismissed(clean) && !isPromptInPageOverridden(clean) && !areAllPromptViolationsOverridden(candidateText)) {
    e.preventDefault();
    e.stopImmediatePropagation();
    const reasons = knownBlockedPrompts.get(clean);
    activeBlockedPrompt = candidateText;
    clearComposerGuardrail(composer || lastTargetComposer);
    showBlockUI(reasons, candidateText, reasons[0], 0.95, true);
    return;
  }

  if (clean.length > 0) {
    if (isPromptInPageOverridden(clean) || isPromptInPageOverridden(candidateText) || areAllPromptViolationsOverridden(candidateText)) {
      setSubmissionFlag();
      return;
    }
    const capturedGeneration = blockGeneration;
    // Asynchronously prime evaluation in background.js with saif.exe/Docker gateway
    sendPortMessage({
      type: 'PRIME_EVALUATION',
      prompt: candidateText,
      categoryToggles: activeCategoryToggles,
      ruleToggles: activeRuleToggles,
      overriddenTokens: Array.from(inPageOverriddenTokens.keys())
    }, 3000).then(res => {
      if (blockGeneration !== capturedGeneration) return;
      if (isPromptInPageOverridden(clean) || isPromptInPageOverridden(candidateText) || isPromptDismissed(clean) || areAllPromptViolationsOverridden(candidateText)) return;
      if (res && res.verdict === 'BLOCK') {
        const ruleName = res.triggeredRule || res.reasons?.[0];
        if (isOutcomeSuppressedByToggles(ruleName, candidateText)) {
          console.log('[SAIF Sensor] Upstream prime BLOCK suppressed by client rule toggle:', ruleName);
          return;
        }
        knownBlockedPrompts.set(clean, res.reasons || ['Prompt blocked by enterprise security policy.']);
        activeBlockedPrompt = candidateText;
        clearComposerGuardrail(composer || lastTargetComposer);
        console.warn('[SAIF Sensor] Front-door evaluation returned BLOCK:', res.reasons);
        showBlockUI(res.reasons || ['Prompt blocked by SAIF AI Firewall policy.'], candidateText, res.reasons?.[0], res.riskScore || 0.95, true);
      } else if (res && typeof res.riskScore === 'number' && res.riskScore >= 0.4 && res.riskScore < 0.75) {
        if (!isPromptDismissed(candidateText) && !isPromptInPageOverridden(candidateText)) {
          sendPortMessage({
            type: 'RECORD_ADVISORY_EVENT',
            prompt: candidateText,
            reasons: res.reasons || [],
            riskScore: res.riskScore
          }).catch(() => {});
        }
      }
    }).catch(() => {});
  }
}

function handleSubmitInterception(e) {
  if (isCurrentDomainWhitelisted()) return;
  const form = e.target;
  if (!form || typeof form.querySelectorAll !== 'function') return;

  // Instant removal of in-page card upon submission attempt; cancel any pending pre-flight debounce
  clearTimeout(preFlightTimer);
  removeDynamicRiskCard();

  let candidateText = '';
  // Scan all text inputs in the submitting form for secrets
  const candidates = form.querySelectorAll('textarea, input, [contenteditable="true"]');
  for (const cand of candidates) {
    if (isTextComposer(cand)) {
      const text = getPromptText(cand);
      if (!candidateText && text) candidateText = text;
      if (isPromptInPageOverridden(text) || areAllPromptViolationsOverridden(text)) {
        setSubmissionFlag();
        continue;
      }
      const violation = checkSynchronousViolations(text);
      if (violation) {
        if (cachedEgressMode === 'audit_only') {
          console.log('[SAIF Sensor] Audit-Only mode: logging simulated form submission block without halting.');
          sendPortMessage({
            type: 'RECORD_SIMULATED_BLOCK_EVENT',
            prompt: text,
            reasons: [violation],
            triggeredRule: violation,
            riskScore: 0.85,
            originUrl: (typeof window !== 'undefined' && window.location) ? window.location.href : 'unknown'
          }, 1000).catch(() => {});
          return;
        }
        e.preventDefault();
        e.stopImmediatePropagation();
        console.warn('[SAIF Sensor] Synchronously blocked sensitive form submission:', violation);
        activeBlockedPrompt = text;
        clearComposerGuardrail(cand);
        sendPortMessage({
          type: 'RECORD_BLOCK_EVENT',
          prompt: text,
          reasons: [violation],
          triggeredRule: violation,
          riskScore: 0.95
        }, 1000).catch(() => {});
        showBlockUI([violation], text, violation, 0.95, true);
        return;
      }
    }
  }

  const clean = (candidateText || '').trim();
  if (isPromptInPageOverridden(clean) || isPromptInPageOverridden(candidateText) || areAllPromptViolationsOverridden(candidateText)) {
    console.log('[SAIF Sensor] Prompt matches in-page override. Bypassing submit interception.');
    return;
  }

  if (knownBlockedPrompts.has(clean) && !isPromptDismissed(clean) && !isPromptInPageOverridden(clean) && !areAllPromptViolationsOverridden(candidateText)) {
    e.preventDefault();
    e.stopImmediatePropagation();
    const reasons = knownBlockedPrompts.get(clean);
    activeBlockedPrompt = candidateText;
    clearComposerGuardrail(lastTargetComposer);
    showBlockUI(reasons, candidateText, reasons[0], 0.95, true);
    return;
  }

  if (clean.length > 0) {
    if (isPromptInPageOverridden(clean) || isPromptInPageOverridden(candidateText) || areAllPromptViolationsOverridden(candidateText)) return;
    const capturedGeneration = blockGeneration;
    sendPortMessage({
      type: 'PRIME_EVALUATION',
      prompt: candidateText,
      categoryToggles: activeCategoryToggles,
      ruleToggles: activeRuleToggles,
      overriddenTokens: Array.from(inPageOverriddenTokens.keys())
    }, 3000).then(res => {
      if (blockGeneration !== capturedGeneration) return;
      if (isPromptInPageOverridden(clean) || isPromptInPageOverridden(candidateText) || isPromptDismissed(clean) || areAllPromptViolationsOverridden(candidateText)) return;
      if (res && res.verdict === 'BLOCK') {
        const ruleName = res.triggeredRule || res.reasons?.[0];
        if (isOutcomeSuppressedByToggles(ruleName, candidateText)) {
          console.log('[SAIF Sensor] Upstream prime BLOCK suppressed by client rule toggle:', ruleName);
          return;
        }
        knownBlockedPrompts.set(clean, res.reasons || ['Prompt blocked by enterprise security policy.']);
        activeBlockedPrompt = candidateText;
        clearComposerGuardrail(lastTargetComposer);
        console.warn('[SAIF Sensor] Front-door evaluation returned BLOCK:', res.reasons);
        showBlockUI(res.reasons || ['Prompt blocked by SAIF AI Firewall policy.'], candidateText, res.reasons?.[0], res.riskScore || 0.95, true);
      } else if (res && typeof res.riskScore === 'number' && res.riskScore >= 0.4 && res.riskScore < 0.75) {
        if (!isPromptDismissed(candidateText) && !isPromptInPageOverridden(candidateText)) {
          sendPortMessage({
            type: 'RECORD_ADVISORY_EVENT',
            prompt: candidateText,
            reasons: res.reasons || [],
            riskScore: res.riskScore
          }).catch(() => {});
        }
      }
    }).catch(() => {});
  }
}

// -------------------------------------------------------------
// Universal In-Place Paste Sanitization (Synchronous Masking + Background Vault Sync)
// -------------------------------------------------------------
function handlePasteInterception(e) {
  if (isCurrentDomainWhitelisted()) return;
  const targetEl = getEventTarget(e);
  const inputEl = editableHostOf(targetEl) || findPromptInput() || targetEl;

  // Password fields are strictly immune to paste interception to protect logins
  if (inputEl && inputEl.tagName === 'INPUT' && (inputEl.type || '').toLowerCase() === 'password') {
    return;
  }

  const clipboardText = (e.clipboardData || window.clipboardData)?.getData('text/plain');
  if (!clipboardText) return;

  // Preserve native verbatim paste so composer retains original text for submission threat triage
  // and trigger asynchronous pre-flight evaluation for live drafting risk badge
  triggerPromptPreFlight(clipboardText);
}

// -------------------------------------------------------------
// Smart Restore: Bidirectional Shimming on Copy
// -------------------------------------------------------------
async function handleCopyInterception(e) {
  const selection = window.getSelection()?.toString();
  if (!selection) return;

  if (/\[[A-Z_]+_\d+\]/.test(selection)) {
    console.log('[SAIF Sensor] Detected masked tokens in copied text. Applying Smart Restore...');

    e.preventDefault();
    e.stopPropagation();

    try {
      const response = await sendPortMessage({
        type: 'RESOLVE_TOKENS',
        text: selection
      }, 1500);

      const restoredText = (response && response.resolved) ? response.resolved : selection;

      if (e.clipboardData) {
        e.clipboardData.setData('text/plain', restoredText);
      } else if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(restoredText);
      }
      console.log('[SAIF Sensor] Smart Restore complete. Original secrets restored to clipboard.');
    } catch (err) {
      console.warn('[SAIF Sensor] Smart Restore resolution error:', err.message);
      if (e.clipboardData) {
        e.clipboardData.setData('text/plain', selection);
      }
    }
  }
}

function replaceInComposer(target, newText) {
  if (!target) return false;
  try {
    if (target.tagName === 'TEXTAREA' || target.tagName === 'INPUT') {
      target.value = newText;
      if (typeof target.dispatchEvent === 'function') {
        try { target.dispatchEvent(new Event('input', { bubbles: true, composed: true })); } catch (_) {}
        try { target.dispatchEvent(new Event('change', { bubbles: true, composed: true })); } catch (_) {}
      }
      try { target.focus(); } catch (_) {}
      return true;
    } else if (target.isContentEditable || (target.getAttribute && target.getAttribute('contenteditable') === 'true')) {
      const hasPTags = (typeof target.querySelectorAll === 'function' && target.querySelectorAll('p').length > 0) ||
                       (typeof target.closest === 'function' && target.closest('rich-textarea') !== null) ||
                       (typeof target.innerHTML === 'string' && target.innerHTML.includes('<p'));
      if (hasPTags) {
        const lines = newText.split('\n');
        const htmlParts = [];
        let inList = false;
        for (const line of lines) {
          const trimmed = line.trim();
          if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
            if (!inList) {
              htmlParts.push('<ul>');
              inList = true;
            }
            htmlParts.push(`<li>${escapeHtml(line)}</li>`);
          } else {
            if (inList) {
              htmlParts.push('</ul>');
              inList = false;
            }
            htmlParts.push(`<p>${escapeHtml(line) || '<br>'}</p>`);
          }
        }
        if (inList) {
          htmlParts.push('</ul>');
        }
        target.innerHTML = htmlParts.join('');
      } else {
        if (target.innerText !== undefined) {
          target.innerText = newText;
        } else {
          target.textContent = newText;
        }
      }
      if (typeof target.dispatchEvent === 'function') {
        try {
          target.dispatchEvent(new InputEvent('input', {
            bubbles: true,
            composed: true,
            cancelable: true,
            inputType: 'insertReplacementText',
            data: newText
          }));
        } catch (_) {
          try { target.dispatchEvent(new Event('input', { bubbles: true, composed: true })); } catch (_) {}
        }
        try { target.dispatchEvent(new Event('change', { bubbles: true, composed: true })); } catch (_) {}
      }
      try {
        target.focus();
        if (typeof window !== 'undefined' && window.getSelection) {
          const selection = window.getSelection();
          if (selection) {
            const range = document.createRange();
            range.selectNodeContents(target);
            range.collapse(false);
            selection.removeAllRanges();
            selection.addRange(range);
          }
        }
      } catch (_) {}
      return true;
    }
  } catch (err) {
    console.warn('[SAIF Sensor] replaceInComposer error:', err);
  }
  return false;
}

function escapeHtml(str) {
  if (!str || typeof str !== 'string') return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// -------------------------------------------------------------
// Unified SAIF In-Page Toast Component & Severity Palette
// -------------------------------------------------------------
const TOAST_THEMES = {
  block: {
    border: '#ef4444',
    text: '#f87171',
    icon: '🛑',
    defaultTitle: 'Security Policy Violation (Blocked)',
    defaultAction: 'Prompt blocked by policy.'
  },
  warn: {
    border: '#f59e0b',
    text: '#fbbf24',
    icon: '⚠️',
    defaultTitle: 'Potential Risk Detected (Review)',
    defaultAction: 'Review before sending.'
  },
  url: {
    border: '#ea580c',
    text: '#fb923c',
    icon: '🔗',
    defaultTitle: 'URL Security Warning (Sensitive Query)',
    defaultAction: 'Page loaded normally.'
  },
  override: {
    border: '#10b981',
    text: '#34d399',
    icon: '🛡️',
    defaultTitle: 'Break-Glass Override Active',
    defaultAction: 'Authorized exception recorded.'
  }
};

function showSaifToast({
  id = 'saif-toast',
  type = 'warn',
  title = null,
  reasons = [],
  snippet = null,
  riskScore = null,
  footerNote = null,
  duration = 6000
} = {}) {
  if (typeof document === 'undefined') return null;
  if (!document.body && document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      showSaifToast({ id, type, title, reasons, snippet, riskScore, footerNote, duration });
    }, { once: true });
    return null;
  }

  const theme = TOAST_THEMES[type] || TOAST_THEMES.warn;
  const existing = document.getElementById(id);
  if (existing) existing.remove();

  const score = typeof riskScore === 'number' ? riskScore : (type === 'block' ? 0.95 : 0.60);
  const toastTitle = title || theme.defaultTitle;
  const actionNote = footerNote || theme.defaultAction;

  let detailsHtml = '';
  if (snippet) {
    const cleanSnippet = escapeHtml(String(snippet).substring(0, 80));
    detailsHtml += `<div style="margin:0 0 8px 0; color:#a1a1aa; font-size:12px; font-family:monospace; background:#27272a; padding:4px 8px; border-radius:4px; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;">Snippet: ${cleanSnippet}</div>`;
  }

  const reasonArr = Array.isArray(reasons) ? reasons : (reasons ? [reasons] : []);
  if (reasonArr.length > 0) {
    const items = reasonArr.map(r => `<li style="margin-bottom:2px;">${escapeHtml(String(r))}</li>`).join('');
    detailsHtml += `<ul style="margin:0 0 8px 16px; padding:0; color:#a1a1aa; font-size:12px; list-style:disc;">${items}</ul>`;
  } else if (!snippet) {
    detailsHtml += `<ul style="margin:0 0 8px 16px; padding:0; color:#a1a1aa; font-size:12px; list-style:disc;"><li>Potential security event detected.</li></ul>`;
  }

  const toast = document.createElement('div');
  toast.id = id;
  toast.style.cssText = `
    position: fixed; bottom: 24px; right: 24px; z-index: 999998;
    background: #18181b; border: 1px solid ${theme.border}; color: #f4f4f5;
    padding: 14px 18px; border-radius: 8px; font-size: 13px; max-width: 340px;
    box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.6);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
  `;
  toast.innerHTML = `
    <div style="display:flex; align-items:center; gap:8px; margin-bottom:8px;">
      <span style="font-size:16px;">${theme.icon}</span>
      <div style="font-weight:600; color:${theme.text};">${escapeHtml(toastTitle)}</div>
    </div>
    ${detailsHtml}
    <div style="font-size:11px; color:#71717a;">
      Risk Score: <span style="color:${theme.text}; font-weight:600;">${score.toFixed(2)}</span> — ${escapeHtml(actionNote)}
    </div>
  `;

  const parent = document.body || document.documentElement;
  if (parent) parent.appendChild(toast);

  if (duration > 0) {
    setTimeout(() => {
      try { toast.remove(); } catch (_) {}
    }, duration);
  }
  return toast;
}

function showUrlWarningToast(violation, paramName, riskScore) {
  if (typeof document === 'undefined') return;
  const param = paramName || 'URL';
  const viol = violation || 'Credential';
  return showSaifToast({
    id: 'saif-url-warning-toast',
    type: 'url',
    title: 'URL Security Warning (Sensitive Query)',
    reasons: [`Page loaded normally, but parameter "${param}" contains sensitive data: ${viol}`],
    riskScore: typeof riskScore === 'number' ? riskScore : 0.95,
    footerNote: 'Page loaded normally.',
    duration: 4000
  });
}

function showAdvisoryToast(reasons, riskScore) {
  if (typeof document === 'undefined') return;
  if (typeof document.getElementById === 'function' && document.getElementById('saif-security-overlay')) return;
  return showSaifToast({
    id: 'saif-advisory-toast',
    type: 'warn',
    title: 'Potential Risk Detected (Review)',
    reasons: Array.isArray(reasons) ? reasons : (reasons ? [reasons] : []),
    riskScore: typeof riskScore === 'number' ? riskScore : 0.60,
    footerNote: 'Review before sending.',
    duration: 6000
  });
}

function showBlockToast(reasons, riskScore, snippet) {
  if (typeof document === 'undefined') return;
  return showSaifToast({
    id: 'saif-block-toast',
    type: 'block',
    title: 'Security Policy Violation (Blocked)',
    reasons: Array.isArray(reasons) ? reasons : (reasons ? [reasons] : []),
    snippet,
    riskScore: typeof riskScore === 'number' ? riskScore : 0.95,
    footerNote: 'Prompt blocked by policy.',
    duration: 6000
  });
}

function showOverrideToast(rule, riskScore) {
  if (typeof document === 'undefined') return;
  return showSaifToast({
    id: 'saif-override-toast',
    type: 'override',
    title: 'Break-Glass Override Active',
    reasons: [rule ? `Authorized bypass for: ${rule}` : 'Temporary user exception granted for this session.'],
    riskScore: typeof riskScore === 'number' ? riskScore : 0.50,
    footerNote: 'Authorized exception recorded.',
    duration: 5000
  });
}

function isOutcomeSuppressedByToggles(ruleOrReason, promptText) {
  if (promptText) {
    const catalog = getCatalogModule();
    if (catalog && typeof catalog.matchStandardRules === 'function') {
      const allMatches = catalog.matchStandardRules(promptText, {}, {});
      if (allMatches.length > 0) {
        const activeMatches = catalog.matchStandardRules(promptText, activeCategoryToggles, activeRuleToggles);
        if (activeMatches.length === 0) {
          return true;
        }
      }
    }
  }
  if (!ruleOrReason || typeof ruleOrReason !== 'string') return false;
  const isRuleActiveFn = (typeof isRuleActive === 'function') ? isRuleActive : ((typeof globalThis !== 'undefined' && typeof globalThis.isRuleActive === 'function') ? globalThis.isRuleActive : null);
  const rules = (typeof STANDARD_RULES !== 'undefined') ? STANDARD_RULES : ((typeof globalThis !== 'undefined' && globalThis.STANDARD_RULES) ? globalThis.STANDARD_RULES : []);
  if (isRuleActiveFn && rules && rules.length > 0) {
    const ruleDef = rules.find(r =>
      r.name === ruleOrReason ||
      r.id === ruleOrReason ||
      r.reason === ruleOrReason ||
      (r.reason && ruleOrReason.includes(r.reason)) ||
      (r.name && ruleOrReason.includes(r.name))
    );
    if (ruleDef && !isRuleActiveFn(ruleDef, activeCategoryToggles, activeRuleToggles)) {
      return true;
    }
  }
  const lower = ruleOrReason.toLowerCase();
  for (const [catId, active] of Object.entries(activeCategoryToggles || {})) {
    if (active === false && (lower.includes(catId) || (catId === 'pii' && (lower.includes('pii') || lower.includes('ssn') || lower.includes('social security'))))) {
      return true;
    }
  }
  for (const [rId, active] of Object.entries(activeRuleToggles || {})) {
    if (active === false) {
      if (rId === 'pat-ssn' && (lower.includes('ssn') || lower.includes('social security'))) return true;
      if (rId === 'pat-aws-key' && (lower.includes('aws') || lower.includes('akia'))) return true;
      if (rId === 'pat-aws-temp-key' && (lower.includes('aws') || lower.includes('asia'))) return true;
      if (rId === 'pat-credit-card' && (lower.includes('credit card') || lower.includes('card'))) return true;
      const baseId = rId.replace(/^pat-/, '').replace(/-/g, ' ');
      if (lower.includes(baseId)) return true;
    }
  }
  return false;
}

// -------------------------------------------------------------
// Security Block Modal Overlay
// -------------------------------------------------------------
function showBlockUI(reasons, promptText, triggeredRuleName, riskScoreVal, forceShow = false) {
  if (typeof document === 'undefined') return;
  console.log('[SAIF Content] showBlockUI CALLED! reasons:', JSON.stringify(reasons), 'rule:', triggeredRuleName, 'promptText substring:', (promptText || '').substring(0, 40));
  console.trace('[SAIF Content] showBlockUI trace:');
  const ruleCheck = triggeredRuleName || (reasons && reasons[0]);
  if (isOutcomeSuppressedByToggles(ruleCheck, promptText)) {
    console.log('[SAIF Sensor] Suppressed Block UI: rule disabled by toggle:', ruleCheck);
    return;
  }

  // Increment generation counter — invalidates any pending pre-flight async result
  blockGeneration++;

  // In audit_only mode, suppress the block modal and log simulated event
  if (cachedEgressMode === 'audit_only') {
    console.log('[SAIF Sensor] Audit-Only mode: suppressing Block UI modal and logging simulated event.');
    const resolvedPrompt = promptText || activeBlockedPrompt;
    const resolvedRule = triggeredRuleName || (reasons && reasons[0]) || 'Policy Violation';
    const resolvedScore = typeof riskScoreVal === 'number' ? riskScoreVal : 0.85;
    sendPortMessage({
      type: 'RECORD_SIMULATED_BLOCK_EVENT',
      prompt: resolvedPrompt,
      reasons: reasons || [resolvedRule],
      triggeredRule: resolvedRule,
      riskScore: resolvedScore,
      originUrl: typeof window !== 'undefined' && window.location ? window.location.href : 'unknown'
    }, 1000).catch(() => {});
    return;
  }

  // STRICT MUTUAL EXCLUSIVITY: Destroy any floating risk card before showing modal
  removeDynamicRiskCard();

  const parent = document.body || document.documentElement;
  if (!parent) return;

  const resolvedPrompt = promptText || activeBlockedPrompt;
  if (resolvedPrompt && isPromptInPageOverridden(resolvedPrompt)) {
    console.log('[SAIF Sensor] Suppressing Block UI modal: prompt is in-page overridden.');
    return;
  }
  if (resolvedPrompt && areAllPromptViolationsOverridden(resolvedPrompt)) {
    console.log('[SAIF Sensor] Suppressing Block UI modal: all secrets in prompt are authorized overridden tokens.');
    return;
  }
  if (!forceShow && resolvedPrompt && isPromptDismissed(resolvedPrompt)) {
    return;
  }
  if (forceShow && resolvedPrompt) {
    dismissedPrompts.delete(resolvedPrompt.trim());
  }
  const resolvedRule = triggeredRuleName || (reasons && reasons[0]) || 'Policy Violation';
  const resolvedScore = typeof riskScoreVal === 'number' ? riskScoreVal : 0.95;

  const existingOverlay = document.getElementById('saif-security-overlay');
  if (existingOverlay) existingOverlay.remove();

  const overlay = document.createElement('div');
  overlay.id = 'saif-security-overlay';
  overlay.style.cssText = `
    position: fixed; top: 0; left: 0; width: 100vw; height: 100vh;
    background: rgba(9, 9, 11, 0.88); backdrop-filter: blur(8px); z-index: 9999999;
    display: flex; flex-direction: column; align-items: center; justify-content: center;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; color: white;
  `;

  // 1. Gather all violations from prompt
  const cm = getCatalogModule();
  const violations = [];
  let secretMatches = [];

  if (cm && typeof cm.sanitizePrompt === 'function') {
    const res = cm.sanitizePrompt(resolvedPrompt, activeCategoryToggles, activeRuleToggles);
    if (res && Array.isArray(res.details)) secretMatches = res.details;
  } else if (typeof sanitizePrompt === 'function') {
    const res = sanitizePrompt(resolvedPrompt, activeCategoryToggles, activeRuleToggles);
    if (res && Array.isArray(res.details)) secretMatches = res.details;
  }

  for (const d of secretMatches) {
    const rId = (d.ruleId || '').toLowerCase();
    const isCred = rId.includes('key') || rId.includes('token') || rId.includes('secret') || rId.includes('aws') || rId.includes('stripe') || rId.includes('openai');
    violations.push({
      id: d.ruleId || 'sec-violation',
      rule_id: d.ruleId || 'sec-violation',
      ruleId: d.ruleId || 'sec-violation',
      category: isCred ? 'Credentials' : 'PII / Sensitive',
      ruleName: d.ruleName || d.ruleId || 'Sensitive Data Pattern',
      rule_name: d.ruleName || d.ruleId || 'Sensitive Data Pattern',
      severity: 'High',
      remediable: true,
      token: d.token || '',
      matched_text: d.token || '',
      start: d.start,
      end: d.end,
      placeholder: d.placeholder ? `[${d.placeholder}_REDACTED]` : '[REDACTED]',
      guidance: 'Deterministic pattern detected. Can be automatically sanitized without altering prompt semantics.'
    });
  }

  // Fallback: When catalog module is unavailable in isolated world, consult localSanitizeText
  if (violations.length === 0 && resolvedPrompt) {
    const localCheck = localSanitizeText(resolvedPrompt);
    if (localCheck && localCheck.replacements > 0) {
      violations.push({
        id: 'local-secret',
        rule_id: 'local-secret',
        ruleId: 'local-secret',
        category: 'Credentials',
        ruleName: resolvedRule || 'Sensitive Credential',
        rule_name: resolvedRule || 'Sensitive Credential',
        severity: 'High',
        remediable: true,
        token: '',
        matched_text: '',
        start: -1,
        end: -1,
        placeholder: '[REDACTED]',
        guidance: 'Deterministic credential pattern detected. Can be automatically sanitized.'
      });
    }
  }

  // Custom Rules matching
  let cMatcher = (cm && typeof cm.matchCustomRules === 'function')
    ? cm.matchCustomRules
    : (typeof matchCustomRules === 'function' ? matchCustomRules : null);
  if (cMatcher && Array.isArray(activeCustomRules) && activeCustomRules.length > 0) {
    const cMatches = cMatcher(resolvedPrompt, activeCustomRules);
    for (const c of cMatches) {
      const isRedact = c.action === 'REDACT';
      violations.push({
        id: c.id || c.slug || 'custom-violation',
        rule_id: c.id || c.slug || 'custom-violation',
        ruleId: c.id || c.slug || 'custom-violation',
        category: 'Custom Policy',
        ruleName: c.name || 'Custom Rule',
        rule_name: c.name || 'Custom Rule',
        severity: c.severity || 'High',
        remediable: isRedact,
        token: c.matchedToken || '',
        matched_text: c.matchedToken || '',
        start: c.index !== undefined ? c.index : -1,
        end: (c.index !== undefined && c.length !== undefined) ? (c.index + c.length) : -1,
        placeholder: c.placeholder ? `[${c.placeholder}]` : '[REDACTED]',
        guidance: isRedact ? 'Custom rule configured for automatic redaction.' : 'Custom rule requires manual prompt editing or review.'
      });
    }
  }

  // 2. Extract Semantic Policy Violations from prompt text and daemon feedback
  const semanticCategories = [
    {
      id: 'pat-phoenix',
      ruleName: 'Project Phoenix Technical Leak',
      category: 'Trade Secrets & IP',
      keywords: ['phoenix wing spar', 'titanium-alloy grade 5', 'project phoenix', 'dual-redundant hydraulic circuit', 'phoenix logic', 'wing spar']
    },
    {
      id: 'sem-pii-records',
      ruleName: 'PII Records',
      category: 'HR & PII',
      keywords: ['Employee ID: EMP-PH-99', 'Salary: 150000', 'user_id: 882734']
    },
    {
      id: 'sem-financial-forecast',
      ruleName: 'Financial Forecast & MNPI',
      category: 'Financial Data',
      keywords: ['gross margin forecast', '68.4 percent', 'target acquisition valuation', 'EBITDA multiple analysis', 'Project Titan', 'projected EPS variance']
    },
    {
      id: 'sem-healthcare',
      ruleName: 'Healthcare & Clinical Records (HIPAA)',
      category: 'Health & Medical',
      keywords: ['Executive physical summary report', 'health benefits enrollment card', 'biopsy report', 'controlled substance schedule']
    },
    {
      id: 'sem-banking',
      ruleName: 'Global Banking & Financial PII',
      category: 'Financial Data',
      keywords: ['corporate treasury bank account details', 'settlement routing numbers', 'wire transfer instructions', 'beneficiary IBAN']
    },
    {
      id: 'sem-passport',
      ruleName: 'National Identity & Passports',
      category: 'Government ID',
      keywords: ['passport scan details', 'diplomatic identification record', 'taxpayer identification number ITIN']
    },
    {
      id: 'sem-infrastructure',
      ruleName: 'Sensitive Infrastructure',
      category: 'Infrastructure',
      keywords: ['saif-production-cluster-internal-only', 'kubernetes namespace', 'internal-dev-jump-host']
    }
  ];

  const listReasons = Array.isArray(reasons) && reasons.length > 0 ? reasons : [resolvedRule];
  const isSemanticContext = listReasons.some(r => {
    const l = (r || '').toLowerCase();
    return l.includes('semantic') || l.includes('phoenix') || l.includes('policy') || l.includes('leak') || l.includes('forecast') || l.includes('infrastructure');
  }) || (resolvedRule && (resolvedRule.toLowerCase().includes('semantic') || resolvedRule.toLowerCase().includes('phoenix')));

  if (resolvedPrompt) {
    for (const cat of semanticCategories) {
      for (const kw of cat.keywords) {
        let searchPos = 0;
        while (searchPos < resolvedPrompt.length) {
          const kwIdx = resolvedPrompt.indexOf(kw, searchPos);
          if (kwIdx === -1) break;

          let sentStart = Math.max(0, resolvedPrompt.lastIndexOf('\n', kwIdx) + 1);
          const priorPeriod = resolvedPrompt.lastIndexOf('. ', kwIdx);
          if (priorPeriod !== -1 && priorPeriod >= sentStart) {
            sentStart = priorPeriod + 2;
          }
          let sentEnd = resolvedPrompt.indexOf('. ', kwIdx);
          const nextNewline = resolvedPrompt.indexOf('\n', kwIdx);
          if (sentEnd === -1 || (nextNewline !== -1 && nextNewline < sentEnd)) {
            sentEnd = nextNewline;
          }
          if (sentEnd === -1) {
            sentEnd = resolvedPrompt.length;
          }
          const parenIdx = resolvedPrompt.indexOf(' (', kwIdx);
          if (parenIdx !== -1 && parenIdx < sentEnd) {
            sentEnd = parenIdx;
          }

          let snippet = resolvedPrompt.substring(sentStart, sentEnd).trim();
          if (snippet.length > 5) {
            const spanStart = resolvedPrompt.indexOf(snippet, sentStart);
            const spanEnd = spanStart !== -1 ? (spanStart + snippet.length) : (kwIdx + kw.length);
            const realStart = spanStart !== -1 ? spanStart : kwIdx;
            const alreadyCovered = violations.some(v => v.start === realStart && v.end === spanEnd);
            if (!alreadyCovered) {
              violations.push({
                id: cat.id,
                rule_id: cat.id,
                ruleId: cat.id,
                category: cat.category,
                ruleName: cat.ruleName,
                rule_name: cat.ruleName,
                severity: 'High',
                origin: 'SEMANTIC_ONNX',
                remediable: false,
                token: snippet,
                matched_text: snippet,
                start: realStart,
                end: spanEnd,
                placeholder: `[REDACTED: ${cat.ruleName}]`,
                guidance: 'Semantic policy rule or threat detected. Can be automatically sanitized or reviewed.'
              });
            }
          }
          searchPos = kwIdx + kw.length;
        }
      }
    }
  }

  // Fallback: If no granular matches found, construct from reasons
  if (violations.length === 0) {
    for (const r of listReasons) {
      const isCred = r.toLowerCase().includes('key') || r.toLowerCase().includes('token') || r.toLowerCase().includes('secret');
      const isSem = r.toLowerCase().includes('semantic') || r.toLowerCase().includes('phoenix') || r.toLowerCase().includes('policy') || r.toLowerCase().includes('leak');
      const cleanRuleName = r.replace(/^Semantic Policy Violation:\s*/i, '').trim();
      const snippet = resolvedPrompt && resolvedPrompt.length > 80 ? (resolvedPrompt.substring(0, 80) + '...') : (resolvedPrompt || '');
      violations.push({
        id: isSem ? 'sem-policy-violation' : 'policy-violation',
        rule_id: isSem ? 'sem-policy-violation' : 'policy-violation',
        ruleId: isSem ? 'sem-policy-violation' : 'policy-violation',
        category: isCred ? 'Credentials' : (isSem ? 'Trade Secrets & IP' : 'Security Policy'),
        ruleName: cleanRuleName || r,
        rule_name: cleanRuleName || r,
        severity: 'High',
        origin: isSem ? 'SEMANTIC_ONNX' : 'REGEX_DLP',
        remediable: false,
        token: snippet,
        matched_text: snippet,
        start: -1,
        end: -1,
        placeholder: `[REDACTED: ${cleanRuleName || 'Violation'}]`,
        guidance: 'Semantic policy rule or threat detected. Manual prompt review required.'
      });
    }
  }

  // Helper to compute sanitized string via descending offset replacement
  function computeSanitizedText(itemsToRemediate) {
    const validItems = itemsToRemediate.filter(v => (v.remediable || v.origin === 'SEMANTIC_ONNX') && typeof v.start === 'number' && v.start >= 0 && typeof v.end === 'number' && v.end > v.start);
    if (validItems.length === 0) {
      if (cm && typeof cm.sanitizePrompt === 'function') {
        return cm.sanitizePrompt(resolvedPrompt, activeCategoryToggles, activeRuleToggles).sanitized;
      }
      return localSanitizeText(resolvedPrompt).sanitized;
    }
    // Sort ascending by start offset
    const sorted = [...validItems].sort((a, b) => a.start === b.start ? b.end - a.end : a.start - b.start);
    const merged = [];
    for (const curr of sorted) {
      if (merged.length === 0) {
        merged.push({ start: curr.start, end: curr.end, placeholder: curr.placeholder });
        continue;
      }
      const last = merged[merged.length - 1];
      if (curr.start >= last.start && curr.end <= last.end) {
        continue;
      }
      if (curr.start < last.end) {
        if (curr.end > last.end) last.end = curr.end;
        continue;
      }
      merged.push({ start: curr.start, end: curr.end, placeholder: curr.placeholder });
    }
    // Replace from back to front
    merged.sort((a, b) => b.start - a.start);
    let text = resolvedPrompt;
    for (const item of merged) {
      text = text.slice(0, item.start) + item.placeholder + text.slice(item.end);
    }
    return text;
  }

  const remediableCount = violations.filter(v => v.remediable && v.origin !== 'SEMANTIC_ONNX').length;
  const totalCount = violations.length;

  // Cleanup handler for listeners
  let keyListener = null;
  let bridgeListener = null;
  const cleanupAndClose = () => {
    if (keyListener && typeof document !== 'undefined' && typeof document.removeEventListener === 'function') {
      document.removeEventListener('keydown', keyListener);
    }
    if (bridgeListener && typeof window !== 'undefined' && typeof window.removeEventListener === 'function') {
      window.removeEventListener('message', bridgeListener);
    }
  };

  const handleDismiss = () => {
    blockGeneration++;
    cleanupAndClose();
    if (resolvedPrompt) {
      addDismissedPrompt(resolvedPrompt, 30000);
      knownBlockedPrompts.delete(resolvedPrompt.trim());
    }
    if (typeof document !== 'undefined' && document.querySelectorAll) {
      try {
        document.querySelectorAll('#saif-security-overlay').forEach(el => el.remove());
      } catch (_) {
        overlay.remove();
      }
    } else {
      overlay.remove();
    }
    abortPendingThinkingState(lastTargetComposer, activeBlockedPrompt);
    const target = lastTargetComposer || findPromptInput();
    if (target) {
      try { target.focus(); } catch (_) {}
    }
  };

  const handleRedact = (sanitizedText, triageMeta) => {
    blockGeneration++;
    cleanupAndClose();
    const cleanPrompt = sanitizedText || computeSanitizedText(violations);
    if (resolvedPrompt) {
      addDismissedPrompt(resolvedPrompt, 30000);
      knownBlockedPrompts.delete(resolvedPrompt.trim());
      sendPortMessage({ type: 'PURGE_EVALUATION_CACHE', prompt: resolvedPrompt }, 500).catch(() => {});
    }
    // For item-level overrides (when unredacted tokens are preserved by user choice in triage),
    // register cleanPrompt in inPageOverriddenPrompts, post __SAIF_BREAK_GLASS_DISPATCH__ to interceptor.js,
    // and notify background.js via RECORD_OVERRIDE_EVENT BEFORE replacing in composer to prevent input event race.
    const overriddenTokens = (triageMeta && Array.isArray(triageMeta.overridden_tokens)) ? triageMeta.overridden_tokens : [];
    if (overriddenTokens.length > 0) {
      for (const tok of overriddenTokens) {
        addInPageOverriddenToken(tok, 60000);
      }
    }

    const hasItemOverride = overriddenTokens.length > 0 || (triageMeta && (
      (triageMeta.selected && Object.values(triageMeta.selected).some(a => a === 'override')) ||
      (triageMeta.selected_items && Object.values(triageMeta.selected_items).some(a => a === 'override'))
    )) || (cleanPrompt && (checkSynchronousViolations(cleanPrompt) || (violations && violations.some(v => !v.remediable))));

    if (cleanPrompt) {
      if (!hasItemOverride) {
        addDismissedPrompt(cleanPrompt, 30000);
      }
      knownBlockedPrompts.delete(cleanPrompt.trim());
      sendPortMessage({ type: 'PURGE_EVALUATION_CACHE', prompt: cleanPrompt }, 500).catch(() => {});
    }

    if (hasItemOverride && cleanPrompt) {
      const pClean = cleanPrompt.trim();
      addInPageOverriddenPrompt(pClean, 60000);
      if (typeof window !== 'undefined' && typeof window.postMessage === 'function') {
        window.postMessage({
          type: '__SAIF_BREAK_GLASS_DISPATCH__',
          prompt: cleanPrompt,
          rule: 'Item-Level Override',
          tokens: overriddenTokens
        }, '*');
      }
      sendPortMessage({
        type: 'RECORD_OVERRIDE_EVENT',
        prompt: cleanPrompt,
        tokens: overriddenTokens,
        reasons: ['Item-Level Override'],
        triggeredRule: 'Item-Level Override',
        riskScore: resolvedScore || 0.85
      }, 1000).catch(() => {});
    }

    const target = lastTargetComposer || findPromptInput();
    if (target) {
      replaceInComposer(target, cleanPrompt);
    }

    overlay.remove();
    if (target && typeof target.focus === 'function') {
      try { target.focus(); } catch (_) {}
    }
  };

  const handleOverride = () => {
    blockGeneration++;
    cleanupAndClose();
    const pText = (resolvedPrompt || '').trim();
    const allTokens = (violations || []).map(v => (v.token || v.matched_text || '')).filter(Boolean);
    allTokens.forEach(tok => addInPageOverriddenToken(tok, 60000));

    if (pText) {
      addInPageOverriddenPrompt(pText, 60000);
      knownBlockedPrompts.delete(pText);
    }
    if (typeof window !== 'undefined' && typeof window.postMessage === 'function') {
      window.postMessage({
        type: '__SAIF_BREAK_GLASS_DISPATCH__',
        prompt: resolvedPrompt,
        rule: resolvedRule,
        tokens: allTokens
      }, '*');
    }
    sendPortMessage({
      type: 'RECORD_OVERRIDE_EVENT',
      prompt: resolvedPrompt,
      reasons: reasons || ['Break-Glass Override'],
      triggeredRule: resolvedRule,
      riskScore: resolvedScore
    }, 1000).catch(() => {});
    overlay.remove();
    const target = lastTargetComposer || findPromptInput();
    if (target) {
      try {
        target.focus();
        const submitBtn = findSubmitButtonForComposer(target);
        if (submitBtn) {
          setSubmissionFlag();
          setTimeout(() => {
            try { submitBtn.click(); } catch (_) {}
          }, 50);
        }
      } catch (_) {}
    }
  };

  const modal = document.createElement('div');
  modal.id = 'saif-modal-container';
  modal.style.cssText = 'width: 94vw; max-width: 900px; display: flex; flex-direction: column; align-items: center;';

  // Overlay Header Bar with Quick Action Controls
  const overlayBar = document.createElement('div');
  overlayBar.id = 'saif-legacy-overlay-bar';
  overlayBar.style.cssText = 'width: 100%; display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; font-size: 13px; color: #f87171; font-weight: 600;';
  overlayBar.innerHTML = `
    <div style="display:flex; align-items:center; gap: 8px;">
      <span style="font-size: 14px;">🛡️</span>
      <span id="saif-modal-title">Prompt Blocked by SAIF Firewall</span>
    </div>
  `;

  const actionsRight = document.createElement('div');
  actionsRight.style.cssText = 'display: flex; gap: 8px; align-items: center;';

  let sanitizeBtn = null;
  if (remediableCount > 0) {
    sanitizeBtn = document.createElement('button');
    sanitizeBtn.id = 'saif-sanitize-btn';
    sanitizeBtn.type = 'button';
    sanitizeBtn.textContent = '🛡️ Sanitize Prompt (Enter / R)';
    sanitizeBtn.style.cssText = 'background: rgba(16, 185, 129, 0.15); border: 1px solid #10b981; color: #34d399; border-radius: 6px; padding: 4px 12px; cursor: pointer; font-size: 12px; font-weight: 600;';
    sanitizeBtn.onclick = () => handleRedact();
    actionsRight.appendChild(sanitizeBtn);
  }

  const breakGlassBtn = document.createElement('button');
  breakGlassBtn.id = 'saif-break-glass-btn';
  breakGlassBtn.type = 'button';
  breakGlassBtn.textContent = 'Review & Send Anyway';
  breakGlassBtn.style.cssText = 'background: rgba(245, 158, 11, 0.15); border: 1px solid #f59e0b; color: #fbbf24; border-radius: 6px; padding: 4px 12px; cursor: pointer; font-size: 12px; font-weight: 600;';
  actionsRight.appendChild(breakGlassBtn);

  const dismissBtn = document.createElement('button');
  dismissBtn.id = 'saif-dismiss-btn';
  dismissBtn.type = 'button';
  dismissBtn.textContent = 'Acknowledge & Dismiss (Esc)';
  dismissBtn.style.cssText = 'background: rgba(255,255,255,0.08); border: 1px solid rgba(255,255,255,0.2); color: #d1d5db; border-radius: 6px; padding: 4px 12px; cursor: pointer; font-size: 12px; font-weight: 500;';
  dismissBtn.onclick = () => handleDismiss();
  actionsRight.appendChild(dismissBtn);

  overlayBar.appendChild(actionsRight);
  modal.appendChild(overlayBar);
  modal.appendChild(actionsRight);

  // Semantic guidance description for semantic exemption assertions
  const desc = document.createElement('p');
  desc.style.display = 'none';
  desc.textContent = (isSemanticContext || violations.some(v => v.origin === 'SEMANTIC_ONNX'))
    ? 'Semantic policy rule or threat detected. Manual prompt review required.'
    : 'Corporate AI security violations detected.';
  modal.appendChild(desc);

  // Hidden metadata container for deterministic test assertions
  const semanticMeta = document.createElement('div');
  semanticMeta.style.display = 'none';
  semanticMeta.id = 'saif-meta-reasons';
  semanticMeta.textContent = (reasons || []).join(' ') + ' ' + (resolvedRule || '');
  modal.appendChild(semanticMeta);

  // Break-Glass Confirmation Drawer
  const confirmDrawer = document.createElement('div');
  confirmDrawer.id = 'saif-confirm-drawer';
  confirmDrawer.style.cssText = 'display: none; width: 100%; text-align: left; background: rgba(24, 24, 27, 0.95); border: 1px dashed #f59e0b; border-radius: 8px; padding: 12px; margin-bottom: 8px;';
  confirmDrawer.innerHTML = `
    <div style="font-size: 12px; color: #fbbf24; font-weight: 600; margin-bottom: 6px; text-align: left;">⚠️ Break-Glass Security Override</div>
    <div style="font-size: 11px; color: #a1a1aa; line-height: 1.4; margin-bottom: 8px; text-align: left;">
      Bypassing inspection transmits sensitive content to the external AI platform. This event will be permanently recorded in your local workstation audit log as <strong style="color:#fbbf24;">OVERRIDDEN</strong>.
    </div>
    <label style="display: flex; align-items: center; gap: 8px; font-size: 12px; color: #f4f4f5; cursor: pointer; margin-bottom: 8px; text-align: left;">
      <input type="checkbox" id="saif-ack-checkbox" style="cursor: pointer; width: 14px; height: 14px; flex-shrink: 0;" />
      <span style="text-align: left;">I understand the risk and authorize this prompt bypass</span>
    </label>
    <div style="display: flex; gap: 8px;">
      <button id="saif-confirm-override-btn" disabled style="padding: 6px 12px; background: #713f12; color: #a1a1aa; font-weight: 600; border: none; border-radius: 6px; cursor: not-allowed; font-size: 12px;">Confirm & Send Prompt</button>
      <button id="saif-cancel-override-btn" style="padding: 6px 12px; background: transparent; color: #a1a1aa; border: 1px solid #3f3f46; border-radius: 6px; cursor: pointer; font-size: 12px;">Cancel</button>
    </div>
  `;
  breakGlassBtn.onclick = () => {
    confirmDrawer.style.display = 'block';
    const ack = confirmDrawer.querySelector('#saif-ack-checkbox');
    const conf = confirmDrawer.querySelector('#saif-confirm-override-btn');
    const canc = confirmDrawer.querySelector('#saif-cancel-override-btn');
    if (ack && conf) {
      ack.onchange = () => {
        if (ack.checked) {
          conf.disabled = false;
          conf.style.background = '#f59e0b';
          conf.style.color = '#000';
          conf.style.cursor = 'pointer';
        } else {
          conf.disabled = true;
          conf.style.background = '#713f12';
          conf.style.color = '#a1a1aa';
          conf.style.cursor = 'not-allowed';
        }
      };
      conf.onclick = () => handleOverride();
    }
    if (canc) {
      canc.onclick = () => {
        confirmDrawer.style.display = 'none';
        if (ack) ack.checked = false;
        if (conf) {
          conf.disabled = true;
          conf.style.background = '#713f12';
          conf.style.color = '#a1a1aa';
          conf.style.cursor = 'not-allowed';
        }
      };
    }
  };
  modal.appendChild(confirmDrawer);

  // 2. Mount isolated triage webview iframe
  const iframe = document.createElement('iframe');
  iframe.id = 'saif-triage-frame';
  iframe.src = (typeof chrome !== 'undefined' && chrome.runtime && typeof chrome.runtime.getURL === 'function')
    ? chrome.runtime.getURL('triage.html')
    : 'triage.html';
  iframe.style.cssText = `
    width: 100%; height: 86vh; max-height: 800px;
    border: none; border-radius: 14px; box-shadow: 0 20px 40px rgba(0,0,0,0.6);
    background: transparent;
  `;
  modal.appendChild(iframe);
  overlay.appendChild(modal);

  const sendPayloadToIframe = () => {
    try {
      if (iframe.contentWindow) {
        iframe.contentWindow.postMessage({
          type: 'SAIF_TRIAGE_LOAD',
          payload: {
            prompt: resolvedPrompt,
            violations: violations,
            sanitized_prompt: computeSanitizedText(violations)
          }
        }, '*');
      }
    } catch (_) {}
  };

  iframe.onload = sendPayloadToIframe;

  // 3. postMessage bridge between host content script and isolated iframe
  bridgeListener = (e) => {
    if (!e.data) return;
    if (e.data.type === 'SAIF_TRIAGE_INIT') {
      sendPayloadToIframe();
    } else if (e.data.type === 'SAIF_TRIAGE_DECISION') {
      if (e.data.action === 'redact') {
        handleRedact(e.data.sanitized_prompt, e.data);
      } else if (e.data.action === 'override') {
        handleOverride();
      } else if (e.data.action === 'cancel') {
        handleDismiss();
      }
    }
  };
  if (typeof window !== 'undefined' && typeof window.addEventListener === 'function') {
    window.addEventListener('message', bridgeListener);
  }

  // Keyboard Hotkeys
  keyListener = (e) => {
    const activeEl = (typeof document !== 'undefined') ? document.activeElement : null;
    const isInput = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA');

    if (e.key === 'Escape') {
      handleDismiss();
    } else if (!isInput && (e.key === 'r' || e.key === 'R' || e.key === 'Enter')) {
      e.preventDefault();
      handleRedact();
    } else if (!isInput && (e.key === 'b' || e.key === 'B')) {
      e.preventDefault();
      handleOverride();
    }
  };
  if (typeof document !== 'undefined' && typeof document.addEventListener === 'function') {
    document.addEventListener('keydown', keyListener);
  }

  parent.appendChild(overlay);
}

function localIsSearchEngineUrl(urlStr) {
  if (!urlStr || typeof urlStr !== 'string') return false;
  try {
    const parsed = new URL(urlStr.includes('://') ? urlStr : 'http://' + urlStr);
    const host = parsed.hostname.toLowerCase();
    const path = parsed.pathname.toLowerCase();
    return (host === 'google.com' || host === 'www.google.com' || /^www\.google\.[a-z.]+$/.test(host) || /^google\.[a-z.]+$/.test(host) ||
      host === 'bing.com' || host === 'www.bing.com' ||
      host === 'duckduckgo.com' || host === 'www.duckduckgo.com' ||
      host === 'search.yahoo.com' || host === 'kagi.com' || host === 'search.brave.com') && (path.startsWith('/search') || host.includes('duckduckgo'));
  } catch (_) { return false; }
}

// -------------------------------------------------------------
// In-Page Document URL Gatekeeper (Defense-in-Depth for Omnibox / Search Engines)
// -------------------------------------------------------------
function inspectDocumentUrl() {
  if (isCurrentDomainWhitelisted()) return false;
  if (typeof window === 'undefined' || !window.location) return false;
  const urlStr = window.location.href;
  if (!urlStr || urlStr.startsWith('chrome-extension://') || urlStr.includes('blocked.html') || urlStr.startsWith('about:')) {
    return false;
  }
  if (isCurrentDomainWhitelisted()) {
    return false;
  }

  // Check if this URL is a verified public search engine
  const cm = getCatalogModule();
  const isSearch = (cm && typeof cm.isSearchEngineUrl === 'function')
    ? cm.isSearchEngineUrl(urlStr)
    : (typeof isSearchEngineUrl === 'function' ? isSearchEngineUrl(urlStr) : localIsSearchEngineUrl(urlStr));

  if (!isSearch) {
    // REAL WEBSITE URL IMMUNITY:
    // If an exposed secret is found in query params OR URL path, show passive security warning toast.
    // SPA dedup: only toast once per unique URL to avoid firing on every popstate/pushState.
    if (urlStr === lastToastedUrl) return false;
    try {
      const url = new URL(urlStr);
      let toasted = false;

      // 1. Scan query parameters
      for (const [key, val] of url.searchParams.entries()) {
        const violation = checkSynchronousViolations(val);
        if (violation) {
          lastToastedUrl = urlStr;
          showUrlWarningToast(violation, key, 0.95);
          toasted = true;
          break;
        }
      }

      // 2. Scan decoded URL pathname (e.g. /api/AKIAKEY or /dumbadmin=AKIAKEY)
      if (!toasted) {
        let decodedPath = url.pathname;
        try { decodedPath = decodeURIComponent(url.pathname); } catch (_) {}
        const pathViolation = checkSynchronousViolations(decodedPath);
        if (pathViolation) {
          lastToastedUrl = urlStr;
          showUrlWarningToast(pathViolation, 'URL path', 0.95);
        }
      }
      // NOTE: url.hash is intentionally NOT scanned — fragments are never sent to the server.
    } catch (_) {}
    return false; // NEVER divert real website URLs to blocked.html!
  }

  try {
    const url = new URL(urlStr);
    const SEARCH_PARAMS = ['q', 'query', 'p', 'search_query', 'wd', 'text', 'keyword'];

    const performDivert = (queryVal, violationReason) => {
      const reasonToUse = violationReason || 'Policy Violation';
      console.warn('[SAIF Sensor] Synchronously blocked sensitive query in page URL:', reasonToUse);

      // 1. Immediately halt rendering and suppress sensitive calculator/results DOM
      if (document.documentElement) {
        document.documentElement.innerHTML = '';
      }

      // 2. Notify background service worker to record audit event & trigger desktop toast
      sendPortMessage({
        type: 'RECORD_BLOCK_EVENT',
        prompt: queryVal,
        reasons: [reasonToUse],
        triggeredRule: reasonToUse,
        riskScore: 0.95
      }, 1000).catch(() => {});

      // 3. Request background worker to divert active tab to blocked warning page
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({
          type: 'DIVERT_TAB_TO_BLOCKED_PAGE',
          violation: reasonToUse,
          hostname: url.hostname,
          query: queryVal,
          dest: url.href
        }, () => {});
      }

      // 4. Immediately divert window to local blocked warning page with destination preservation
      const queryArg = queryVal ? `&query=${encodeURIComponent(queryVal)}` : '';
      const blockedUrl = (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.getURL)
        ? chrome.runtime.getURL(`blocked.html?reason=${encodeURIComponent(reasonToUse)}&target=${encodeURIComponent(url.hostname)}&snippet=${encodeURIComponent(queryVal.substring(0, 80))}&dest=${encodeURIComponent(url.href)}${queryArg}`)
        : `blocked.html?reason=${encodeURIComponent(reasonToUse)}&target=${encodeURIComponent(url.hostname)}&snippet=${encodeURIComponent(queryVal.substring(0, 80))}&dest=${encodeURIComponent(url.href)}${queryArg}`;
      try {
        window.location.replace(blockedUrl);
      } catch (_) {}
    };

    for (const param of SEARCH_PARAMS) {
      const val = url.searchParams.get(param);
      if (val && val.trim().length > 0) {
        if (cachedOmniOverrides.has(val) || isPromptInPageOverridden(val) || isPromptDismissed(val)) {
          continue;
        }
        const violation = checkSynchronousViolations(val);
        if (violation) {
          if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get(['omniOverrides'], (res) => {
              const currentOverrides = new Set(res?.omniOverrides || []);
              if (currentOverrides.has(val) || currentOverrides.has(val.trim()) || currentOverrides.has(url.href) || currentOverrides.has(url.hostname)) {
                return;
              }
              performDivert(val, violation);
            });
            return true;
          }

          performDivert(val, violation);
          return true;
        } else if (val.trim().length >= 10) {
          // Asynchronously prime evaluation for search engine / Omnibox queries
          sendPortMessage({
            type: 'PRIME_EVALUATION',
            prompt: val.trim(),
            categoryToggles: activeCategoryToggles,
            ruleToggles: activeRuleToggles
          }, 3000).then(res => {
            if (res && res.verdict === 'BLOCK') {
              if (cachedOmniOverrides.has(val) || isPromptInPageOverridden(val) || isPromptDismissed(val)) {
                return;
              }
              const reason = (res.reasons && res.reasons[0]) || res.triggeredRule || 'Semantic Policy Violation';
              knownBlockedPrompts.set(val.trim(), res.reasons || [reason]);
              if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                chrome.storage.local.get(['omniOverrides'], (resStorage) => {
                  const currentOverrides = new Set(resStorage?.omniOverrides || []);
                  if (currentOverrides.has(val) || currentOverrides.has(val.trim()) || currentOverrides.has(url.href) || currentOverrides.has(url.hostname)) {
                    return;
                  }
                  performDivert(val, reason);
                });
              } else {
                performDivert(val, reason);
              }
            } else if (res && typeof res.riskScore === 'number' && res.riskScore >= 0.4 && res.riskScore < 0.75) {
              if (!isPromptDismissed(val.trim()) && !isPromptInPageOverridden(val.trim())) {
                sendPortMessage({
                  type: 'RECORD_ADVISORY_EVENT',
                  prompt: val.trim(),
                  reasons: res.reasons || [],
                  riskScore: res.riskScore
                }).catch(() => {});
              }
            }
          }).catch(() => {});
        }
      }
    }
  } catch (_) {}
  return false;
}

// -------------------------------------------------------------
// Main-World PostMessage Security Bridge & Capture-Phase Initialization
// -------------------------------------------------------------
if (typeof window !== 'undefined') {
  // Execute immediate pre-flight URL scan at document_start
  inspectDocumentUrl();
  if (typeof document !== 'undefined' && document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', inspectDocumentUrl);
  }

  // Intercept client-side SPA history state transitions on search engines
  try {
    if (window.history && window.history.pushState) {
      const origPush = window.history.pushState;
      window.history.pushState = function(...args) {
        const ret = origPush.apply(this, args);
        inspectDocumentUrl();
        return ret;
      };
    }
    if (window.history && window.history.replaceState) {
      const origReplace = window.history.replaceState;
      window.history.replaceState = function(...args) {
        const ret = origReplace.apply(this, args);
        inspectDocumentUrl();
        return ret;
      };
    }
  } catch (_) {}

  window.addEventListener('popstate', inspectDocumentUrl, { capture: true });
  window.addEventListener('hashchange', inspectDocumentUrl, { capture: true });

  // Track focused composer across the page
  window.addEventListener('focusin', (e) => {
    const host = editableHostOf(getEventTarget(e));
    if (host) {
      lastFocusedComposer = host;
    }
  }, { capture: true });

  window.addEventListener('message', async (event) => {
    if (event.source !== window || !event.data || typeof event.data !== 'object') return;

    if (event.data.type === '__SAIF_INSPECT_REQUEST__') {
      const { requestId, prompt, url } = event.data;
      if (prompt && (isPromptDismissed(prompt) || isPromptInPageOverridden(prompt))) {
        window.postMessage({
          type: '__SAIF_INSPECT_RESPONSE__',
          requestId,
          verdict: 'ALLOW',
          reasons: ['Clean - Sanitized / Overridden Prompt Allowed']
        }, '*');
        return;
      }
      if (prompt && areAllPromptViolationsOverridden(prompt)) {
        window.postMessage({
          type: '__SAIF_INSPECT_RESPONSE__',
          requestId,
          verdict: 'ALLOW',
          reasons: ['Clean - Item-Level Overridden Tokens Allowed']
        }, '*');
        return;
      }
      try {
        const response = await sendPortMessage({
          type: 'EVALUATE_PROMPT',
          prompt,
          categoryToggles: activeCategoryToggles,
          ruleToggles: activeRuleToggles,
          overriddenTokens: Array.from(inPageOverriddenTokens.keys())
        }, 2500);

        window.postMessage({
          type: '__SAIF_INSPECT_RESPONSE__',
          requestId,
          verdict: response && response.verdict ? response.verdict : 'BLOCK',
          reasons: response && response.reasons ? response.reasons : ['SAIF evaluation bridge returned empty response. Outgoing prompt blocked.']
        }, '*');
      } catch (err) {
        console.warn('[SAIF Sensor] Evaluation error in bridge:', err.message);
        window.postMessage({
          type: '__SAIF_INSPECT_RESPONSE__',
          requestId,
          verdict: 'BLOCK',
          reasons: [err.message || 'SAIF bridge evaluation exception. Outgoing prompt blocked.']
        }, '*');
      }
    }

    if (event.data.type === '__SAIF_SHOW_BLOCK_UI__') {
      const reasons = event.data.reasons || ['Prompt blocked by SAIF AI Firewall policy.'];
      const prompt = event.data.prompt;
      const triggeredRule = event.data.triggeredRule || (reasons && reasons[0]) || 'Policy Violation';
      const riskScore = event.data.riskScore || 0.95;
      if (prompt) {
        knownBlockedPrompts.set(prompt.trim(), reasons);
        activeBlockedPrompt = prompt;
        // Asynchronously notify background service worker to record in rolling audit history and trigger desktop toast
        sendPortMessage({
          type: 'RECORD_BLOCK_EVENT',
          prompt,
          reasons,
          triggeredRule,
          riskScore
        }, 1000).catch(() => {});
      }
      abortPendingThinkingState(lastTargetComposer, prompt);
      clearComposerGuardrail(lastTargetComposer);
      showBlockUI(reasons, prompt, triggeredRule, riskScore);
    }

    if (event.data.type === '__SAIF_RECORD_SIMULATED_BLOCK__') {
      const reasons = event.data.reasons || ['Policy Violation (Simulated)'];
      const prompt = event.data.prompt;
      const triggeredRule = event.data.triggeredRule || (reasons && reasons[0]) || 'Policy Violation (Simulated)';
      const riskScore = typeof event.data.riskScore === 'number' ? event.data.riskScore : 0.85;
      const originUrl = event.data.originUrl || ((typeof window !== 'undefined' && window.location) ? window.location.href : 'unknown');
      const evaluationChain = event.data.evaluationChain || [];

      sendPortMessage({
        type: 'RECORD_SIMULATED_BLOCK_EVENT',
        prompt,
        reasons,
        triggeredRule,
        riskScore,
        originUrl,
        evaluationChain
      }, 1000).catch(() => {});
    }

    // E2E Test Hook: simulate a PRIME_EVALUATION WARN response for advisory toast testing
    if (event.data.type === '__SAIF_TEST_ADVISORY_TOAST__') {
      const reasons = event.data.reasons || [];
      const riskScore = typeof event.data.riskScore === 'number' ? event.data.riskScore : 0.60;
      showAdvisoryToast(reasons, riskScore);
    }

    // E2E Test Hook: simulate a block toast
    if (event.data.type === '__SAIF_TEST_BLOCK_TOAST__') {
      const reasons = event.data.reasons || ['Security Policy Violation'];
      const riskScore = typeof event.data.riskScore === 'number' ? event.data.riskScore : 0.95;
      showBlockToast(reasons, riskScore, event.data.snippet || null);
    }

    // E2E Test Hook: simulate an override toast
    if (event.data.type === '__SAIF_TEST_OVERRIDE_TOAST__') {
      const rule = event.data.rule || 'Break-Glass Override';
      const riskScore = typeof event.data.riskScore === 'number' ? event.data.riskScore : 0.50;
      showOverrideToast(rule, riskScore);
    }

    // E2E Test Hook: simulate dynamic risk card
    if (event.data.type === '__SAIF_TEST_RENDER_RISK_CARD__') {
      const reasons = event.data.reasons || [];
      const riskScore = typeof event.data.riskScore === 'number' ? event.data.riskScore : 0.60;
      renderDynamicRiskCard(riskScore, reasons, event.data.promptText || '');
    }

    if (event.data.type === '__SAIF_TEST_REMOVE_RISK_CARD__') {
      removeDynamicRiskCard();
    }

    // E2E Test Hook: simulate activating Protection Snooze across tabs
    if (event.data.type === '__SAIF_TEST_SET_SNOOZE__') {
      const mins = event.data.snoozeMinutes || 5;
      const until = Date.now() + (mins * 60 * 1000);
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.set({ snoozeUntil: until });
      }
    }
  });

  // Real-Time Input Pre-Flight: monitors typing, pasting, autocomplete, and focus in composers
  const handleComposerUpdate = (e) => {
    const target = getEventTarget(e);
    const composer = editableHostOf(target) || (isTextComposer(target) ? target : null);
    if (!composer) return;
    lastFocusedComposer = composer;
    lastTargetComposer = composer;
    const text = getPromptText(composer);
    if (!text) {
      removeDynamicRiskCard();
      return;
    }
    const clean = text.trim();
    if (isPromptInPageOverridden(clean) || isPromptInPageOverridden(text)) {
      removeDynamicRiskCard();
      knownBlockedPrompts.delete(clean);
      return;
    }
    if (clean.length >= 10) {
      const syncViol = checkSynchronousViolations(text);
      if (syncViol) {
        knownBlockedPrompts.set(clean, [syncViol]);
        activeBlockedPrompt = text;
        if (!isPromptDismissed(clean) && !isPromptInPageOverridden(clean)) {
          renderDynamicRiskCard(0.95, [syncViol], clean);
        } else {
          removeDynamicRiskCard();
        }
      } else {
        triggerPromptPreFlight(text);
      }
    } else {
      removeDynamicRiskCard();
    }
  };

  window.addEventListener('input', handleComposerUpdate, { capture: true, passive: true });
  window.addEventListener('change', handleComposerUpdate, { capture: true, passive: true });
  window.addEventListener('focusin', handleComposerUpdate, { capture: true, passive: true });

  // Scan existing prefilled composers on DOM ready (e.g. Google search results pages)
  const checkInitialComposers = () => {
    const composer = findPromptInput();
    if (composer) {
      const text = getPromptText(composer);
      if (text && text.trim().length >= 10) {
        const syncViol = checkSynchronousViolations(text);
        if (syncViol) {
          knownBlockedPrompts.set(text.trim(), [syncViol]);
          activeBlockedPrompt = text;
          if (!isPromptDismissed(text.trim()) && !isPromptInPageOverridden(text.trim())) {
            renderDynamicRiskCard(0.95, [syncViol], text.trim());
          } else {
            removeDynamicRiskCard();
          }
        } else {
          triggerPromptPreFlight(text);
        }
      }
    }
  };
  if (typeof document !== 'undefined') {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', checkInitialComposers, { once: true });
    } else {
      setTimeout(checkInitialComposers, 100);
    }
  }

  // Attach Capture-Phase Listeners on Window (Fires BEFORE framework event handlers)
  window.addEventListener('keydown', handleKeydownInterception, { capture: true, passive: false });
  window.addEventListener('click', handleClickInterception, { capture: true, passive: false });
  window.addEventListener('submit', handleSubmitInterception, { capture: true, passive: false });
  window.addEventListener('paste', handlePasteInterception, { capture: true, passive: false });
  window.addEventListener('copy', handleCopyInterception, { capture: true, passive: false });
}

// Node.js test environment exports
try {
  if (typeof module !== 'undefined' && module && module.exports) {
    module.exports = {
      findPromptInput,
      getPromptText,
      injectSanitizedText,
      handlePasteInterception,
      handleCopyInterception,
      handleKeydownInterception,
      handleClickInterception,
      handleSubmitInterception,
      isSubmitButtonElement,
      isTextComposer,
      resolveTargetComposer,
      checkTextForSecrets,
      checkSynchronousViolations,
      knownBlockedPrompts,
      localSanitizeText,
      setActiveToggles,
      showBlockUI,
      sendPortMessage,
      inspectDocumentUrl,
      isCurrentDomainWhitelisted,
      findSubmitButtonForComposer,
      isPromptInPageOverridden,
      addInPageOverriddenPrompt,
      burnInPageOverriddenPrompt,
      isTokenInPageOverridden,
      addInPageOverriddenToken,
      inPageOverriddenTokens,
      isPromptDismissed,
      addDismissedPrompt,
      replaceInComposer,
      showUrlWarningToast,
      showAdvisoryToast,
      showBlockToast,
      showOverrideToast,
      showSaifToast,
      renderDynamicRiskCard,
      removeDynamicRiskCard,
      applyComposerGuardrail,
      clearComposerGuardrail,
      TOAST_THEMES,
      getCatalogModule,
      triggerPromptPreFlight,
      getBlockGeneration: () => blockGeneration,
      getEgressMode: () => cachedEgressMode,
      setEgressMode: (m) => { cachedEgressMode = m; syncEgressModeToDOM(); }
    };
  }
} catch (e) {}
