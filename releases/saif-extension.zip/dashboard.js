// SAIF Dashboard Controller - Free Tier Developer Edition
let allRules = (typeof STANDARD_RULES !== 'undefined' ? STANDARD_RULES : (typeof window !== 'undefined' && window.STANDARD_RULES ? window.STANDARD_RULES : []));
let allCategories = (typeof RULE_CATEGORIES !== 'undefined' ? RULE_CATEGORIES : (typeof window !== 'undefined' && window.RULE_CATEGORIES ? window.RULE_CATEGORIES : []));
let ruleToggles = {};
let categoryToggles = {};
let currentCategoryFilter = 'all';
let currentSearchQuery = '';
let cachedLoadedEvents = [];
let currentAuditSearchQuery = '';
let customRules = [];
let currentCustomSearchQuery = '';

if (typeof document !== 'undefined') {
  document.addEventListener('DOMContentLoaded', () => {
    initTabs();
    initSearchAndFilter();
    loadRules();
    loadCustomRules();
    initCustomRulesUI();
    loadAuditLogs();
    loadDiagnostics();
    initSandbox();
    setInterval(loadDiagnostics, 2000);

    document.getElementById('btnClearAuditLogs').addEventListener('click', () => {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ type: 'CLEAR_RECENT_EVENTS' }, () => {
          loadAuditLogs();
        });
      }
    });

    document.getElementById('btnExportLogs').addEventListener('click', () => {
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ type: 'GET_RECENT_EVENTS' }, (res) => {
          const events = (res && res.events) || [];
          const blob = new Blob([JSON.stringify(events, null, 2)], { type: 'application/json' });
          const url = URL.createObjectURL(blob);
          const a = document.createElement('a');
          a.href = url;
          a.download = `saif-audit-logs-${new Date().toISOString().substring(0, 10)}.json`;
          a.click();
          URL.revokeObjectURL(url);
        });
      }
    });

    const btnCsv = document.getElementById('btnExportCsv');
    if (btnCsv) {
      btnCsv.addEventListener('click', () => {
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
          chrome.runtime.sendMessage({ type: 'GET_RECENT_EVENTS' }, (res) => {
            const events = (res && res.events) || [];
            const csvData = exportAuditCsv(events);
            const blob = new Blob([csvData], { type: 'text/csv;charset=utf-8;' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `saif-audit-logs-${new Date().toISOString().substring(0, 10)}.csv`;
            a.click();
            URL.revokeObjectURL(url);
          });
        }
      });
    }

    const auditSearchInput = document.getElementById('auditSearchInput');
    if (auditSearchInput) {
      auditSearchInput.addEventListener('input', (e) => {
        currentAuditSearchQuery = (e.target.value || '').toLowerCase().trim();
        renderAuditLogs();
      });
    }

        // Wire Category Master Toggle Button
    const btnToggleMaster = document.getElementById('btnToggleCategoryMaster');
    if (btnToggleMaster) {
      btnToggleMaster.addEventListener('click', () => {
        if (currentCategoryFilter === 'all') return;
        const currentVal = categoryToggles[currentCategoryFilter] !== false;
        const newVal = !currentVal;
        categoryToggles[currentCategoryFilter] = newVal;
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ categoryToggles });
        }
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
          chrome.runtime.sendMessage({
            type: 'SET_CATEGORY_TOGGLE',
            categoryId: currentCategoryFilter,
            enabled: newVal
          });
        }
        renderRules();
      });
    }

    document.getElementById('btnTestAgent').addEventListener('click', () => {
      const btn = document.getElementById('btnTestAgent');
      btn.textContent = 'Probing (:18080)...';
      loadDiagnostics(() => {
        btn.textContent = 'Probe Complete!';
        setTimeout(() => { btn.textContent = 'Probe Agent (:18080)'; }, 1500);
      });
    });

    // Live sync when background worker logs new events or updates toggles
    if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.onChanged) {
      chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local') {
          if (changes.recentEvents) {
            loadAuditLogs();
          }
          if (changes.ruleToggles || changes.categoryToggles) {
            loadRules();
          }
          if (changes.custom_rules) {
            loadCustomRules();
          }
        }
      });
    }

    // Auto-refresh when tab or window regains focus
    if (typeof window !== 'undefined' && window.addEventListener) {
      window.addEventListener('focus', () => {
        loadAuditLogs();
        loadDiagnostics();
      });
    }

    // Wire Profile Switcher Buttons (Phase 11.9)
    const btnSwitchC4 = document.getElementById('btnSwitchC4');
    const btnSwitchLight = document.getElementById('btnSwitchLight');
    const btnSwitchEngineer = document.getElementById('btnSwitchEngineer');
    const profileSwitchStatus = document.getElementById('profileSwitchStatus');

    function updateProfileButtonActive(activeProfile) {
      if (!btnSwitchLight || !btnSwitchEngineer) return;
      const allBtns = [
        { el: btnSwitchC4, name: 'c4' },
        { el: btnSwitchLight, name: 'light' },
        { el: btnSwitchEngineer, name: 'engineer' }
      ];
      allBtns.forEach(({ el, name }) => {
        if (!el) return;
        const matches = (activeProfile === name) ||
          (name === 'engineer' && activeProfile === 'r2') ||
          (name === 'light' && activeProfile === 'r4') ||
          (name === 'c4' && activeProfile === 'decision');
        if (matches) {
          el.classList.add('btn-profile-active');
          el.classList.remove('btn-profile-inactive');
        } else {
          el.classList.remove('btn-profile-active');
          el.classList.add('btn-profile-inactive');
        }
      });
    }
    window.updateProfileButtonActive = updateProfileButtonActive;

    function switchProfile(targetProfile) {
      if (profileSwitchStatus) {
        profileSwitchStatus.textContent = `Switching to ${targetProfile}...`;
        profileSwitchStatus.style.color = '#93c5fd';
      }
      if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
        chrome.runtime.sendMessage({ type: 'SWITCH_PROFILE', profile: targetProfile }, (res) => {
          if (res && res.success) {
            if (profileSwitchStatus) {
              const dispName = (targetProfile === 'c4' || targetProfile === 'decision') ? 'SAIF LIGHT' : ((targetProfile === 'engineer' || targetProfile === 'r2') ? 'SAIF DEEP NEURAL' : 'SAIF NEURAL');
              profileSwitchStatus.textContent = `Successfully switched to ${dispName}!`;
              profileSwitchStatus.style.color = '#34d399';
              setTimeout(() => { if (profileSwitchStatus && profileSwitchStatus.textContent.includes('Successfully')) profileSwitchStatus.textContent = ''; }, 3000);
            }
            updateProfileButtonActive(targetProfile);
            loadDiagnostics();
          } else {
            const errMsg = (res && res.error) || 'Failed to switch profile';
            // Direct POST fallback
            fetch('http://127.0.0.1:18080/api/v1/agent/profile', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ profile: targetProfile })
            })
            .then(r => r.json().then(data => ({ ok: r.ok, data })))
            .then(({ ok, data }) => {
              if (ok && data && data.status === 'ok') {
                if (profileSwitchStatus) {
                  const dispName = (targetProfile === 'c4' || targetProfile === 'decision') ? 'SAIF LIGHT' : ((targetProfile === 'engineer' || targetProfile === 'r2') ? 'SAIF DEEP NEURAL' : 'SAIF NEURAL');
              profileSwitchStatus.textContent = `Successfully switched to ${dispName}!`;
                  profileSwitchStatus.style.color = '#34d399';
                  setTimeout(() => { if (profileSwitchStatus && profileSwitchStatus.textContent.includes('Successfully')) profileSwitchStatus.textContent = ''; }, 3000);
                }
                updateProfileButtonActive(targetProfile);
                loadDiagnostics();
              } else {
                if (profileSwitchStatus) {
                  profileSwitchStatus.textContent = `⚠️ Switch failed: ${(data && data.message) || errMsg}`;
                  profileSwitchStatus.style.color = '#f87171';
                }
              }
            })
            .catch(err => {
              if (profileSwitchStatus) {
                profileSwitchStatus.textContent = `⚠️ Switch failed: ${errMsg || err.message || 'Agent offline'}`;
                profileSwitchStatus.style.color = '#f87171';
              }
            });
          }
        });
      }
    }

    if (btnSwitchC4) {
      btnSwitchC4.addEventListener('click', () => switchProfile('c4'));
    }
    if (btnSwitchLight) {
      btnSwitchLight.addEventListener('click', () => switchProfile('light'));
    }
    if (btnSwitchEngineer) {
      btnSwitchEngineer.addEventListener('click', () => switchProfile('engineer'));
    }

    // Wire Fail-Closed Offline Toggle
    const toggleFailClosed = document.getElementById('diagToggleFailClosed');
    if (toggleFailClosed) {
      if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
        chrome.storage.local.get(['failClosedOffline'], (data) => {
          toggleFailClosed.checked = !!data.failClosedOffline;
        });
      }
      toggleFailClosed.addEventListener('change', (e) => {
        const val = e.target.checked;
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
          chrome.runtime.sendMessage({ type: 'SET_FAIL_CLOSED_OFFLINE', enabled: val });
        }
      });
    }
  });
}

function initTabs() {
  const navItems = document.querySelectorAll('.sidebar .nav-item');
  const tabs = document.querySelectorAll('.tab-content');

  navItems.forEach(item => {
    item.addEventListener('click', () => {
      navItems.forEach(n => n.classList.remove('active'));
      tabs.forEach(t => t.classList.remove('active'));

      item.classList.add('active');
      const targetTabId = item.getAttribute('data-tab');
      const targetTab = document.getElementById(targetTabId);
      if (targetTab) {
        targetTab.classList.add('active');
      }

      if (targetTabId === 'tab-audit') {
        loadAuditLogs();
      } else if (targetTabId === 'tab-system') {
        loadDiagnostics();
      } else if (targetTabId === 'tab-custom') {
        loadCustomRules();
      }
    });
  });
}

function initSearchAndFilter() {
  const searchInput = document.getElementById('ruleSearchInput');
  searchInput.addEventListener('input', (e) => {
    currentSearchQuery = (e.target.value || '').toLowerCase().trim();
    renderRules();
  });

  const pillBtns = document.querySelectorAll('#categoryPillContainer .pill-btn');
  pillBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      pillBtns.forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      currentCategoryFilter = btn.getAttribute('data-cat');
      renderRules();
    });
  });
}

function loadRules() {
  // Ensure baseline rules are loaded from local catalog if available
  if (!allRules || allRules.length === 0) {
    if (typeof window !== 'undefined' && window.STANDARD_RULES && window.STANDARD_RULES.length > 0) {
      allRules = window.STANDARD_RULES;
    } else if (typeof STANDARD_RULES !== 'undefined' && STANDARD_RULES.length > 0) {
      allRules = STANDARD_RULES;
    }
  }
  if (!allCategories || allCategories.length === 0) {
    if (typeof window !== 'undefined' && window.RULE_CATEGORIES && window.RULE_CATEGORIES.length > 0) {
      allCategories = window.RULE_CATEGORIES;
    } else if (typeof RULE_CATEGORIES !== 'undefined' && RULE_CATEGORIES.length > 0) {
      allCategories = RULE_CATEGORIES;
    }
  }

  // Immediate synchronous render of available rules
  renderRules();

  // Overlay saved toggles directly from local storage
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(['ruleToggles', 'categoryToggles'], (stored) => {
      if (stored) {
        if (stored.ruleToggles) ruleToggles = stored.ruleToggles;
        if (stored.categoryToggles) categoryToggles = stored.categoryToggles;
        renderRules();
      }
    });
  }

  // Query background service worker for dynamic updates
  if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage({ type: 'GET_RULES_CATALOG' }, (res) => {
      if (chrome.runtime.lastError || !res) return;
      if (Array.isArray(res.categories) && res.categories.length > 0) {
        allCategories = res.categories;
      }
      if (Array.isArray(res.rules) && res.rules.length > 0) {
        allRules = res.rules;
      }
      if (res.categoryToggles) categoryToggles = res.categoryToggles;
      if (res.ruleToggles) ruleToggles = res.ruleToggles;
      renderRules();
    });
  }
}

function renderRules() {
  const container = document.getElementById('rulesGrid');
  container.innerHTML = '';

  // Update Category Master Toggle Header
  const masterContainer = document.getElementById('categoryMasterContainer');
  const masterIcon = document.getElementById('masterCategoryIcon');
  const masterTitle = document.getElementById('masterCategoryTitle');
  const masterDesc = document.getElementById('masterCategoryDesc');
  const masterCount = document.getElementById('masterCategoryCount');
  const masterBtn = document.getElementById('btnToggleCategoryMaster');

  if (masterContainer) {
    if (currentCategoryFilter === 'all') {
      masterContainer.style.display = 'none';
    } else {
      masterContainer.style.display = 'flex';
      const catObj = allCategories.find(c => c.id === currentCategoryFilter);
      if (catObj && masterTitle) {
        if (masterIcon) masterIcon.textContent = catObj.icon || '🛡️';
        masterTitle.textContent = catObj.name;
        if (masterDesc) masterDesc.textContent = catObj.description || '';
      } else if (masterTitle) {
        masterTitle.textContent = currentCategoryFilter.toUpperCase();
      }
      if (masterCount) {
        const catCount = allRules.filter(r => r.category === currentCategoryFilter || r.presidioCategory === currentCategoryFilter || r.legacyCategory === currentCategoryFilter).length;
        masterCount.textContent = `${catCount} Rule${catCount === 1 ? '' : 's'}`;
      }
      if (masterBtn) {
        const isCatEnabled = categoryToggles[currentCategoryFilter] !== false;
        masterBtn.textContent = isCatEnabled ? 'Disable Entire Category' : 'Enable Entire Category';
        masterBtn.className = isCatEnabled ? 'btn btn-secondary' : 'btn btn-primary';
      }
    }
  }


  const filtered = allRules.filter(rule => {
    // Category match (supports canonical categories, legacyCategory, and Presidio taxonomy)
    if (currentCategoryFilter !== 'all') {
      const matchCanonical = rule.category === currentCategoryFilter;
      const matchPresidio = rule.presidioCategory === currentCategoryFilter;
      const matchLegacy = rule.legacyCategory === currentCategoryFilter;
      if (!matchCanonical && !matchPresidio && !matchLegacy) return false;
    }
    // Search match
    if (currentSearchQuery) {
      const matchName = (rule.name || '').toLowerCase().includes(currentSearchQuery);
      const matchDesc = (rule.description || '').toLowerCase().includes(currentSearchQuery);
      const matchRegex = (rule.regexStr || '').toLowerCase().includes(currentSearchQuery);
      const matchReason = (rule.reason || '').toLowerCase().includes(currentSearchQuery);
      const matchPlaceholder = (rule.redactionPlaceholder || '').toLowerCase().includes(currentSearchQuery);
      const matchEngine = (rule.engineSpec || '').toLowerCase().includes(currentSearchQuery) || (rule.engineType || '').toLowerCase().includes(currentSearchQuery) || (rule.cpagSpec || '').toLowerCase().includes(currentSearchQuery);
      if (!matchName && !matchDesc && !matchRegex && !matchReason && !matchPlaceholder && !matchEngine) return false;
    }
    return true;
  });

  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: var(--text-muted);">
        No matching rules found for the current search/category filter.
      </div>
    `;
    return;
  }

  filtered.forEach(rule => {
    const isCategoryEnabled = categoryToggles[rule.category] !== false;
    let isRuleEnabled = rule.enabledByDefault;
    if (ruleToggles[rule.id] !== undefined) {
      isRuleEnabled = ruleToggles[rule.id] === true;
    }
    const isEffective = isCategoryEnabled && isRuleEnabled;

    const card = document.createElement('div');
    card.className = 'rule-card';
    card.setAttribute('data-rule-id', rule.id);
    card.setAttribute('data-engine-type', rule.engineType || 'regex');

    let badgeClass = 'badge-high';
    if (rule.severity === 'Critical') badgeClass = 'badge-critical';
    else if (rule.severity === 'Medium') badgeClass = 'badge-medium';

    // Modular Multi-Badge Rendering & Specification Parity
    const engines = Array.isArray(rule.engines) && rule.engines.length > 0
      ? rule.engines
      : (rule.engineType === 'cpag_algorithmic' ? ['CPAG 2.0', 'Triage'] : (rule.engineType === 'neural_onnx' ? ['Neural', 'Triage'] : (rule.engineType === 'dlp_cpag' ? ['DLP', 'CPAG 2.0'] : ['DLP'])));

    const badgesHtml = engines.map(eng => {
      let cls = 'badge-engine-dlp';
      let icon = '🛡️';
      if (eng === 'CPAG 2.0') { cls = 'badge-engine-cpag'; icon = '⚡'; }
      else if (eng === 'Neural') { cls = 'badge-engine-neural'; icon = '🧠'; }
      else if (eng === 'Triage') { cls = 'badge-engine-triage'; icon = '⚖️'; }
      return `<span class="badge-engine ${cls}">${icon} ${escapeHtml(eng)}</span>`;
    }).join(' ');

    let engineContentHtml = `
      <div class="rule-engine-container" data-engine-spec="${escapeHtml(rule.engineType || 'regex')}">
        <!-- CPAG 2.0 ALGORITHMIC -->
        <!-- DLP + CPAG DE-OBFUSCATION -->
        <div class="engine-badges-row">
          ${badgesHtml}
        </div>
      </div>
    `;

    card.innerHTML = `
      <div>
        <div class="rule-card-header">
          <div class="rule-name-wrap">
            <div class="rule-title">${escapeHtml(rule.name)}</div>
            <div class="rule-meta">
              <span class="badge ${badgeClass}">${escapeHtml(rule.severity || 'High')}</span>
              <span style="font-size: 11px; color: var(--text-muted);">${escapeHtml(rule.category)}${rule.presidioCategory ? ` &bull; <span style="color:#a78bfa;">${escapeHtml(rule.presidioCategory)}</span>` : ''}</span>
            </div>
          </div>
          <label class="switch">
            <input type="checkbox" id="toggle-${rule.id}" ${isEffective ? 'checked' : ''}>
            <span class="slider"></span>
          </label>
        </div>
        <p class="rule-desc">${escapeHtml(rule.description || '')}</p>
      </div>
      <div>
        ${engineContentHtml}
      </div>
    `;

    const toggleInput = card.querySelector(`#toggle-${rule.id}`);
    if (toggleInput) {
      toggleInput.addEventListener('change', (e) => {
        const checked = e.target.checked;
        ruleToggles[rule.id] = checked;
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
          chrome.storage.local.set({ ruleToggles });
        }
        if (typeof chrome !== 'undefined' && chrome.runtime && chrome.runtime.sendMessage) {
          chrome.runtime.sendMessage({
            type: 'SET_RULE_TOGGLE',
            ruleId: rule.id,
            enabled: checked
          });
        }
      });
    }

    container.appendChild(card);
  });
}

function loadAuditLogs() {
  if (typeof chrome === 'undefined') return;

  const fetchFromStorageFallback = () => {
    if (chrome.storage && chrome.storage.local) {
      chrome.storage.local.get('recentEvents', (store) => {
        cachedLoadedEvents = (store && store.recentEvents) || [];
        renderAuditLogs();
      });
    } else {
      cachedLoadedEvents = [];
      renderAuditLogs();
    }
  };

  if (chrome.runtime && chrome.runtime.sendMessage) {
    chrome.runtime.sendMessage({ type: 'GET_RECENT_EVENTS' }, (res) => {
      if (res && Array.isArray(res.events) && res.events.length > 0) {
        cachedLoadedEvents = res.events;
        renderAuditLogs();
      } else {
        fetchFromStorageFallback();
      }
    });
  } else {
    fetchFromStorageFallback();
  }
}

function renderAuditLogs() {
  const events = cachedLoadedEvents || [];
  const tbody = document.getElementById('auditTableBody');
  const emptyState = document.getElementById('auditEmptyState');
  const countLabel = document.getElementById('auditCountLabel');

  if (!tbody) return;
  tbody.innerHTML = '';

  const filtered = events.filter(evt => {
    if (!currentAuditSearchQuery) return true;
    const q = currentAuditSearchQuery;
    const matchRule = (evt.triggeredRule || (evt.reasons && evt.reasons[0]) || '').toLowerCase().includes(q);
    const matchSnippet = (evt.promptSnippet || '').toLowerCase().includes(q);
    const matchDest = (formatOrigin(evt.originUrl) || '').toLowerCase().includes(q);
    const matchVerdict = (evt.verdict || '').toLowerCase().includes(q);
    return matchRule || matchSnippet || matchDest || matchVerdict;
  });

  if (countLabel) {
    if (currentAuditSearchQuery) {
      countLabel.textContent = `Showing ${filtered.length} of ${events.length} events`;
    } else {
      countLabel.textContent = `Showing ${events.length} event${events.length === 1 ? '' : 's'}`;
    }
  }

  if (filtered.length === 0) {
    if (emptyState) emptyState.style.display = 'block';
    return;
  }
  if (emptyState) emptyState.style.display = 'none';

  filtered.forEach((evt, idx) => {
    const tr = document.createElement('tr');
    tr.className = 'audit-row';
    tr.id = `audit-row-${idx}`;

    const isBlock = evt.verdict === 'BLOCK';
    const isOverridden = evt.verdict === 'OVERRIDDEN';
    const pillClass = isBlock ? 'block' : (isOverridden ? 'overridden' : 'allow');
    const timeStr = evt.timestamp ? new Date(evt.timestamp).toLocaleTimeString() : 'Just now';
    
    const scoreNum = typeof evt.riskScore === 'number' ? evt.riskScore : (isBlock || isOverridden ? 0.95 : 0.0);
    let scoreClass = 'score-clean';
    if (scoreNum >= 0.8) scoreClass = isOverridden ? 'score-med' : 'score-high';
    else if (scoreNum >= 0.4) scoreClass = 'score-med';
    else if (scoreNum > 0.0) scoreClass = 'score-low';

    const ruleText = evt.triggeredRule || (evt.reasons && evt.reasons[0]) || (isBlock ? 'Policy Violation' : (isOverridden ? 'Break-Glass Override' : 'Clean - Safe'));

    tr.innerHTML = `
      <td style="font-family: monospace; font-size: 11px;">${escapeHtml(timeStr)}</td>
      <td><span class="verdict-pill ${pillClass}">${escapeHtml(evt.verdict || 'UNKNOWN')}</span></td>
      <td><span class="score-badge ${scoreClass}">${scoreNum.toFixed(4)}</span></td>
      <td style="font-size: 12px; color: #93c5fd;">${escapeHtml(formatOrigin(evt.originUrl))}</td>
      <td style="font-family: monospace; font-size: 11px; max-width: 280px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${escapeHtml(evt.promptSnippet || '')}</td>
      <td style="font-size: 11px; color: var(--text-secondary);">${escapeHtml(ruleText)}${evt.presidioCategory ? ` <span class="badge badge-medium" style="font-size:9px; padding:1px 4px; margin-left:4px; color:#a78bfa; background:rgba(139,92,246,0.15); border:1px solid rgba(139,92,246,0.3); border-radius:3px;">${escapeHtml(evt.presidioCategory)}</span>` : ''}</td>
      <td style="text-align: center; font-size: 11px; color: var(--text-muted); cursor: pointer;" id="trace-toggle-${idx}">▼</td>
    `;

    // Create expandable detail drawer for evaluationChain
    const drawerTr = document.createElement('tr');
    drawerTr.id = `audit-drawer-${idx}`;
    drawerTr.style.display = 'none';

    const chain = Array.isArray(evt.evaluationChain) && evt.evaluationChain.length > 0
      ? evt.evaluationChain
      : [
          { tier: 'dlp', action: isBlock ? 'block' : 'allow', riskScore: isBlock ? 0.95 : 0.0, rule: ruleText, latencyMs: 0.2 }
        ];

    const chainStepsHtml = chain.map((step) => {
      const stepActionColor = step.action === 'block' ? '#f87171' : '#34d399';
      const stepScore = typeof step.riskScore === 'number' ? step.riskScore.toFixed(4) : '-';
      return `
        <div class="chain-step">
          <span class="chain-step-tier">${escapeHtml(step.tier || 'scan')}</span>
          <span style="color: ${stepActionColor}; font-weight: 600; font-size: 10px; text-transform: uppercase;">${escapeHtml(step.action || 'allow')}</span>
          <span style="color: var(--text-secondary); font-family: monospace;">score: ${escapeHtml(stepScore)}</span>
          <span style="color: var(--text-muted); font-size: 10px;">${escapeHtml(step.rule || '')}</span>
          <span style="color: var(--text-muted); font-size: 10px;">(${step.latencyMs || 0}ms)</span>
        </div>
      `;
    }).join('<span class="chain-arrow">→</span>');

    drawerTr.innerHTML = `
      <td colspan="7" style="padding: 0;">
        <div class="chain-drawer">
          <div style="font-size: 11px; font-weight: 600; color: var(--text-muted); margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.5px;">
            Evaluation Pipeline Trace (Zero-Trust Security Tiers):
          </div>
          <div class="chain-timeline">
            ${chainStepsHtml}
          </div>
        </div>
      </td>
    `;

    const toggleDrawer = () => {
      const isShown = drawerTr.style.display !== 'none';
      drawerTr.style.display = isShown ? 'none' : 'table-row';
      const arrowEl = document.getElementById(`trace-toggle-${idx}`);
      if (arrowEl) arrowEl.textContent = isShown ? '▼' : '▲';
    };

    tr.addEventListener('click', toggleDrawer);

    tbody.appendChild(tr);
    tbody.appendChild(drawerTr);
  });
}

function loadDiagnostics(callback) {
  if (typeof chrome === 'undefined' || !chrome.runtime || !chrome.runtime.sendMessage) {
    return;
  }

  chrome.runtime.sendMessage({ type: 'GET_STATUS' }, (status) => {
    if (status) {
      if (status.gatewayUrl) {
        const gwEl = document.getElementById('diagGatewayEndpoint');
        if (gwEl) gwEl.textContent = status.gatewayUrl;
      }
      if (status.tenantId) {
        document.getElementById('diagTenantId').textContent = status.tenantId;
      }
      if (status.sensorId) {
        document.getElementById('diagSensorId').textContent = status.sensorId;
      }
    }

    // Direct probe to 18080
    fetch('http://127.0.0.1:18080/health', { method: 'GET' })
      .then(res => res.json())
      .then(health => {
        const text = health.model_loaded ? 'Online / Local Neural Engine Ready' : 'Connected / Model Initializing';
        document.getElementById('diagAgentModelStatus').textContent = text;
        document.getElementById('headerStatusText').textContent = 'Agent Connected (Local Control Plane)';
        
        const profile = health.engineProfile || health.profile || 'light';
        if (typeof updateProfileButtonActive === 'function') updateProfileButtonActive(profile);
        const profileBadge = document.getElementById('diagActiveProfileBadge');
        if (profileBadge) {
          if (profile === 'c4' || profile === 'decision') {
            profileBadge.textContent = 'SAIF LIGHT';
            profileBadge.style.background = 'rgba(2, 132, 199, 0.15)';
            profileBadge.style.color = '#38bdf8';
            profileBadge.style.borderColor = 'rgba(2, 132, 199, 0.3)';
          } else if (profile === 'engineer' || profile === 'r2') {
            profileBadge.textContent = 'SAIF DEEP NEURAL (8,192T)';
            profileBadge.style.background = 'rgba(139, 92, 246, 0.15)';
            profileBadge.style.color = '#a78bfa';
            profileBadge.style.borderColor = 'rgba(139, 92, 246, 0.3)';
          } else {
            profileBadge.textContent = 'SAIF NEURAL (512T)';
            profileBadge.style.background = 'rgba(34, 197, 94, 0.15)';
            profileBadge.style.color = '#4ade80';
            profileBadge.style.borderColor = 'rgba(34, 197, 94, 0.3)';
          }
        }
        const profileName = document.getElementById('diagProfileName');
        if (profileName) {
          if (profile === 'c4' || profile === 'decision') {
            profileName.textContent = 'SAIF Light (Deterministic Rules Engine)';
          } else if (profile === 'engineer' || profile === 'r2') {
            profileName.textContent = 'SAIF Deep Neural (Extended Context / 8,192T)';
          } else {
            profileName.textContent = 'SAIF Neural (On-Device Local / 512T)';
          }
        }
        const horizon = document.getElementById('diagContextHorizon');
        if (horizon) {
          if (profile === 'c4' || profile === 'decision') {
            horizon.textContent = 'Deterministic / Rule Filtering';
          } else {
            horizon.textContent = `${health.contextHorizonTokens || (profile === 'engineer' ? 8192 : 512)} tokens`;
          }
        }
        const rulesLoaded = document.getElementById('diagRulesLoaded');
        if (rulesLoaded) rulesLoaded.textContent = `${health.rulesLoaded || 42} rules active (Presidio Taxonomy)`;
        const ramEl = document.getElementById('diagAgentRam');
        if (ramEl) {
          const memMb = health.idleMemoryMb ? Math.round(health.idleMemoryMb) : (profile === 'c4' || profile === 'decision' ? 118 : (profile === 'engineer' || profile === 'r2' ? 485 : 246));
          ramEl.textContent = `${memMb} MB RSS (Dynamic Load)`;
        }
        const memEl = document.getElementById('diagMemoryMb');
        if (memEl) {
          if (profile === 'c4' || profile === 'decision') {
            memEl.textContent = `${health.idleMemoryMb ? Math.round(health.idleMemoryMb) : 118} MB (Deterministic)`;
          } else {
            memEl.textContent = `${health.idleMemoryMb ? Math.round(health.idleMemoryMb) : (profile === 'engineer' ? 485 : 246)} MB idle`;
          }
        }

        const badge = document.getElementById('headerStatusBadge');
        if (badge) {
          badge.style.background = 'rgba(16, 185, 129, 0.1)';
          badge.style.borderColor = 'rgba(16, 185, 129, 0.25)';
          badge.style.color = '#10b981';
          const dot = badge.querySelector('.status-dot');
          if (dot) {
            dot.style.background = '#10b981';
            dot.style.boxShadow = '0 0 8px #10b981';
          }
        }
      })
      .catch(() => {
        document.getElementById('diagAgentModelStatus').textContent = 'Offline (Decoupled Mode Active)';
        document.getElementById('headerStatusText').textContent = 'Autonomous Decoupled Mode';
        const ramEl = document.getElementById('diagAgentRam');
        if (ramEl) ramEl.textContent = '0 MB (Offline)';
        const profileBadge = document.getElementById('diagActiveProfileBadge');
        if (profileBadge) {
          profileBadge.textContent = 'OFFLINE';
          profileBadge.style.background = 'rgba(245, 158, 11, 0.15)';
          profileBadge.style.color = '#fbbf24';
          profileBadge.style.borderColor = 'rgba(245, 158, 11, 0.3)';
        }
        const badge = document.getElementById('headerStatusBadge');
        if (badge) {
          badge.style.background = 'rgba(245, 158, 11, 0.15)';
          badge.style.borderColor = 'rgba(245, 158, 11, 0.3)';
          badge.style.color = '#fbbf24';
          const dot = badge.querySelector('.status-dot');
          if (dot) {
            dot.style.background = '#f59e0b';
            dot.style.boxShadow = '0 0 8px #f59e0b';
          }
        }
      })
      .finally(() => {
        if (typeof callback === 'function') callback();
      });
  });
}

function formatOrigin(urlStr) {
  if (!urlStr || urlStr === 'unknown' || urlStr === 'popup') return 'Local Browser';
  try {
    const u = new URL(urlStr);
    return u.hostname;
  } catch (_) {
    return urlStr;
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function exportAuditCsv(events) {
  if (!Array.isArray(events)) return '';
  const headers = ['Timestamp', 'Verdict', 'RiskScore', 'Destination', 'TriggeredRule', 'PromptSnippet', 'LatencyMs'];
  const rows = events.map(evt => {
    const time = evt.timestamp ? new Date(evt.timestamp).toISOString() : '';
    const verdict = evt.verdict || 'BLOCK';
    const score = typeof evt.riskScore === 'number' ? evt.riskScore.toFixed(4) : '0.9500';
    const destination = formatOrigin(evt.originUrl);
    const rule = (evt.triggeredRule || (evt.reasons && evt.reasons[0]) || 'Policy Violation').replace(/"/g, '""');
    const snippet = (evt.promptSnippet || '').replace(/"/g, '""');
    const latency = evt.evaluationChain && evt.evaluationChain[0] ? (evt.evaluationChain[0].latencyMs || 0) : 0;
    return `"${time}","${verdict}","${score}","${destination}","${rule}","${snippet}","${latency}"`;
  });
  return [headers.join(','), ...rows].join('\r\n');
}

function initSandbox() {
  const grid = document.getElementById('sandboxVectorGrid');
  if (!grid) return;

  const catalog = (typeof rulesCatalog !== 'undefined' ? rulesCatalog : (typeof window !== 'undefined' && window.rulesCatalog ? window.rulesCatalog : null));
  const vectors = (catalog && Array.isArray(catalog.SANDBOX_VECTORS))
    ? catalog.SANDBOX_VECTORS
    : (typeof SANDBOX_VECTORS !== 'undefined' ? SANDBOX_VECTORS : []);

  grid.innerHTML = '';
  vectors.forEach(v => {
    const card = document.createElement('div');
    card.className = 'vector-card';
    card.innerHTML = `
      <div>
        <div class="vector-header">
          <span class="vector-title">${escapeHtml(v.name)}</span>
          <span class="vector-badge ${escapeHtml(v.category)}">${escapeHtml(v.category)}</span>
        </div>
        <div class="vector-desc">${escapeHtml(v.description)}</div>
        <div class="vector-preview">${escapeHtml(v.prompt.substring(0, 75))}...</div>
      </div>
      <button class="btn btn-secondary btn-try-vector" data-vector-id="${escapeHtml(v.id)}" style="width: 100%; margin-top: 10px; font-weight: 600;">
        🧪 Try Vector
      </button>
    `;
    const tryBtn = card.querySelector('.btn-try-vector');
    if (tryBtn) {
      tryBtn.addEventListener('click', () => {
        const input = document.getElementById('sandboxCustomInput');
        if (input) {
          input.value = v.prompt;
        }
        runSandboxInspection(v.prompt);
      });
    }
    grid.appendChild(card);
  });

  const btnRun = document.getElementById('btnSandboxRun');
  if (btnRun) {
    btnRun.addEventListener('click', () => {
      const input = document.getElementById('sandboxCustomInput');
      const text = input ? input.value : '';
      if (text && text.trim()) {
        runSandboxInspection(text.trim());
      }
    });
  }

  const btnReset = document.getElementById('btnSandboxReset');
  if (btnReset) {
    btnReset.addEventListener('click', () => {
      const input = document.getElementById('sandboxCustomInput');
      if (input) input.value = '';
      const hud = document.getElementById('sandboxHud');
      if (hud) hud.style.display = 'none';
    });
  }

  const btnCopy = document.getElementById('btnCopySanitized');
  if (btnCopy) {
    btnCopy.addEventListener('click', () => {
      const maskedEl = document.getElementById('sandboxMaskedText');
      if (maskedEl && maskedEl.textContent) {
        if (typeof navigator !== 'undefined' && navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(maskedEl.textContent).then(() => {
            btnCopy.textContent = '✅ Copied!';
            setTimeout(() => { btnCopy.textContent = '📋 Copy Redacted Prompt'; }, 2000);
          }).catch(() => {});
        }
      }
    });
  }

  // Hash check on load: if #sandbox or #tab-sandbox, activate sandbox tab
  if (typeof window !== 'undefined' && (window.location.hash === '#sandbox' || window.location.hash === '#tab-sandbox')) {
    const navItem = document.getElementById('navSandbox');
    if (navItem) navItem.click();
  }
}

function runSandboxInspection(promptText) {
  const hud = document.getElementById('sandboxHud');
  const latencyPill = document.getElementById('sandboxLatencyPill');
  const rulePill = document.getElementById('sandboxRulePill');
  const verdictPill = document.getElementById('sandboxVerdictPill');
  const scorePill = document.getElementById('sandboxScorePill');
  const originalTextEl = document.getElementById('sandboxOriginalText');
  const maskedTextEl = document.getElementById('sandboxMaskedText');
  const semanticNotice = document.getElementById('sandboxSemanticNotice');
  const btnCopy = document.getElementById('btnCopySanitized');

  // Helper: update the score pill with color-coded severity
  function setScorePill(score, label) {
    if (!scorePill) return;
    let bg = 'rgba(16, 185, 129, 0.12)', color = '#34d399';
    if (score >= 0.9) { bg = 'rgba(239, 68, 68, 0.15)'; color = '#f87171'; }
    else if (score >= 0.75) { bg = 'rgba(251, 146, 60, 0.15)'; color = '#fb923c'; }
    else if (score >= 0.4) { bg = 'rgba(245, 158, 11, 0.15)'; color = '#fbbf24'; }
    scorePill.style.background = bg;
    scorePill.style.color = color;
    scorePill.textContent = `🎯 Risk: ${score.toFixed(2)} ${label}`;
  }

  if (!hud) return null;
  hud.style.display = 'block';

  const startTime = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();

  const catalog = (typeof rulesCatalog !== 'undefined' ? rulesCatalog : (typeof window !== 'undefined' && window.rulesCatalog ? window.rulesCatalog : null));

  const ruleTypeSelect = document.getElementById('sandboxRuleType');
  const selectedType = ruleTypeSelect ? ruleTypeSelect.value : 'regex';

  // Check if semantic concept leak
  const isSemantic = (selectedType === 'semantic') && (
    promptText.toLowerCase().includes('phoenix') ||
    promptText.toLowerCase().includes('wing spar') ||
    promptText.toLowerCase().includes('titanium') ||
    promptText.toLowerCase().includes('flight controller') ||
    promptText.toLowerCase().includes('orbital telemetry')
  );

  if (isSemantic) {
    const latency = (16 + Math.random() * 8).toFixed(1);
    if (latencyPill) latencyPill.textContent = `⏱️ ${latency}ms (On-Device Neural)`;
    if (rulePill) rulePill.textContent = '🛡️ Semantic Concept Leak (Engineering Trade Secrets)';
    if (verdictPill) {
      verdictPill.textContent = 'BLOCK';
      verdictPill.style.background = 'rgba(239, 68, 68, 0.15)';
      verdictPill.style.color = '#f87171';
    }
    setScorePill(0.82, 'HIGH');

    if (semanticNotice) semanticNotice.style.display = 'block';
    if (btnCopy) btnCopy.style.display = 'none';

    if (originalTextEl) originalTextEl.innerHTML = `<span class="diff-highlight-exposed">${escapeHtml(promptText)}</span>`;
    if (maskedTextEl) maskedTextEl.innerHTML = `<span style="color:#a1a1aa; font-style:italic;">[Autoregressive text redaction disabled for semantic vectors in Free Tier]</span>`;
    return { verdict: 'BLOCK', isSemantic: true, latencyMs: parseFloat(latency) };
  }

  if (semanticNotice) semanticNotice.style.display = 'none';

  // Run standard DLP rules check (only if regex type is selected)
  const matches = (selectedType !== 'semantic' && catalog && typeof catalog.matchStandardRules === 'function')
    ? catalog.matchStandardRules(promptText, categoryToggles, ruleToggles)
    : [];

  const now = (typeof performance !== 'undefined' && performance.now) ? performance.now() : Date.now();
  const elapsed = (now - startTime).toFixed(2);
  const latencyDisplay = elapsed < 0.1 ? '< 0.5ms (Instant Client Regex)' : `${elapsed}ms (Instant Client Regex)`;
  if (latencyPill) latencyPill.textContent = `⏱️ ${latencyDisplay}`;

  if (matches && matches.length > 0) {
    const primaryRule = matches[0].reason;
    if (rulePill) rulePill.textContent = `🛡️ ${primaryRule}`;
    if (verdictPill) {
      verdictPill.textContent = 'BLOCK';
      verdictPill.style.background = 'rgba(239, 68, 68, 0.15)';
      verdictPill.style.color = '#f87171';
    }

    // Derive risk score from rule severity (use highest across all matches)
    const SEVERITY_SCORE = { Critical: 0.95, High: 0.90, Medium: 0.65, Low: 0.25 };
    const SEVERITY_LABEL = { Critical: 'CRITICAL', High: 'HIGH', Medium: 'MEDIUM', Low: 'LOW' };
    let topScore = 0;
    let topSeverity = 'High';
    for (const m of matches) {
      const s = SEVERITY_SCORE[m.severity] || 0.90;
      if (s > topScore) { topScore = s; topSeverity = m.severity || 'High'; }
    }
    setScorePill(topScore, SEVERITY_LABEL[topSeverity] || 'HIGH');

    const sanitizeRes = (catalog && typeof catalog.sanitizePrompt === 'function')
      ? catalog.sanitizePrompt(promptText, categoryToggles, ruleToggles)
      : { sanitized: promptText, replacementsCount: 0 };

    if (originalTextEl) originalTextEl.textContent = promptText;
    if (maskedTextEl) maskedTextEl.innerHTML = highlightRedactedDiff(promptText, sanitizeRes.sanitized);

    if (btnCopy) btnCopy.style.display = 'inline-block';
    return { verdict: 'BLOCK', rule: primaryRule, sanitized: sanitizeRes.sanitized, riskScore: topScore, latencyMs: parseFloat(elapsed) };
  } else {
    if (rulePill) rulePill.textContent = '🛡️ None (Clean Prompt)';
    if (verdictPill) {
      verdictPill.textContent = 'ALLOW';
      verdictPill.style.background = 'rgba(16, 185, 129, 0.15)';
      verdictPill.style.color = '#34d399';
    }
    setScorePill(0.00, 'CLEAN');

    if (originalTextEl) originalTextEl.textContent = promptText;
    if (maskedTextEl) maskedTextEl.textContent = promptText;

    if (btnCopy) btnCopy.style.display = 'none';
    return { verdict: 'ALLOW', riskScore: 0.00, latencyMs: parseFloat(elapsed) };
  }
}

function highlightRedactedDiff(original, sanitized) {
  if (original === sanitized) return escapeHtml(sanitized);
  const escaped = escapeHtml(sanitized);
  return escaped.replace(/\[[A-Z_]+_REDACTED\]/g, (match) => {
    return `<span class="diff-highlight-masked" style="color:#34d399; background:rgba(16,185,129,0.15); padding:2px 4px; border-radius:4px; font-weight:600;">${match}</span>`;
  });
}

// -------------------------------------------------------------
// Custom Rules Controller (Phase 11.8)
// -------------------------------------------------------------
function generateSlug(text) {
  if (!text) return '';
  return text.toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

function checkReDoS(pattern) {
  if (!pattern) return { valid: true, error: null };
  try {
    new RegExp(pattern);
  } catch (err) {
    return { valid: false, error: err.message };
  }
  // Check for catastrophic nested quantifier patterns e.g. (a+)+ or (.*)*
  if (/(\([^)]*(\+|\*|\{[0-9]+,[0-9]*\})[^)]*\)(\+|\*|\{[0-9]+,[0-9]*\}))/.test(pattern)) {
    return { valid: false, error: 'Potential ReDoS hazard: nested quantifiers detected' };
  }
  return { valid: true, error: null };
}

function loadCustomRules(callback) {
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.get(['custom_rules'], (res) => {
      customRules = (res && Array.isArray(res.custom_rules)) ? res.custom_rules : [];
      renderCustomRules();
      if (typeof callback === 'function') callback(customRules);
    });
  } else if (typeof localStorage !== 'undefined') {
    try {
      const stored = localStorage.getItem('saif_custom_rules');
      customRules = stored ? JSON.parse(stored) : [];
    } catch (_) {
      customRules = [];
    }
    renderCustomRules();
    if (typeof callback === 'function') callback(customRules);
  } else {
    renderCustomRules();
    if (typeof callback === 'function') callback(customRules);
  }
}

function saveCustomRulesStorage(rules, callback) {
  customRules = rules;
  if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
    chrome.storage.local.set({ custom_rules: rules }, () => {
      syncCustomRulesToAgent(rules);
      if (typeof callback === 'function') callback();
    });
  } else if (typeof localStorage !== 'undefined') {
    try {
      localStorage.setItem('saif_custom_rules', JSON.stringify(rules));
    } catch (_) {}
    syncCustomRulesToAgent(rules);
    if (typeof callback === 'function') callback();
  } else {
    syncCustomRulesToAgent(rules);
    if (typeof callback === 'function') callback();
  }
}

function syncCustomRulesToAgent(rules) {
  if (typeof fetch !== 'undefined') {
    fetch('http://127.0.0.1:18080/api/v1/rules/custom', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(rules)
    }).catch(() => {});
  }
}

function renderCustomRules() {
  const tableBody = document.getElementById('customRulesTableBody');
  const emptyState = document.getElementById('customEmptyState');
  const countLabel = document.getElementById('customCountLabel');

  if (!tableBody) return;

  let filtered = customRules;
  if (currentCustomSearchQuery) {
    filtered = customRules.filter(r => {
      const name = (r.name || '').toLowerCase();
      const slug = (r.slug || '').toLowerCase();
      const pat = (r.pattern || '').toLowerCase();
      return name.includes(currentCustomSearchQuery) || slug.includes(currentCustomSearchQuery) || pat.includes(currentCustomSearchQuery);
    });
  }

  if (countLabel) {
    countLabel.textContent = `${filtered.length} rule${filtered.length === 1 ? '' : 's'} configured`;
  }

  tableBody.innerHTML = '';
  if (filtered.length === 0) {
    if (emptyState) emptyState.style.display = 'block';
    return;
  }
  if (emptyState) emptyState.style.display = 'none';

  filtered.forEach(rule => {
    const tr = document.createElement('tr');
    tr.setAttribute('data-rule-id', rule.id);

    const typeBadgeClass = rule.type === 'semantic' ? 'semantic' : (rule.type === 'regex' ? 'developer' : 'cloud');
    const actionClass = (rule.action || 'BLOCK').toLowerCase();

    const targetSummary = rule.type === 'semantic'
      ? `${(rule.prototypes || []).length} prototypes (sensitivity: ${rule.sensitivity || 0.85})`
      : escapeHtml(rule.pattern || '');

    tr.innerHTML = `
      <td>
        <div style="font-weight: 600; color: #f4f4f5;">${escapeHtml(rule.name || 'Unnamed')}</div>
        <div style="margin-top: 3px;">
          <code class="directive-tag" title="Click to copy directive" data-slug="${escapeHtml(rule.slug || '')}">// saif:ignore[${escapeHtml(rule.slug || '')}]</code>
        </div>
      </td>
      <td>
        <span class="vector-badge ${typeBadgeClass}">${escapeHtml((rule.type || 'keyword').toUpperCase())}</span>
      </td>
      <td style="font-family: monospace; font-size: 11px; max-width: 240px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: #a1a1aa;">
        ${targetSummary}
      </td>
      <td style="text-align: center;">
        <span class="action-badge ${actionClass}">${escapeHtml(rule.action || 'BLOCK')}</span>
      </td>
      <td style="text-align: center;">
        <input type="checkbox" class="custom-toggle" data-id="${escapeHtml(rule.id)}" ${rule.enabled !== false ? 'checked' : ''} style="cursor: pointer;">
      </td>
      <td style="text-align: center;">
        <button class="btn btn-secondary btn-delete-custom" data-id="${escapeHtml(rule.id)}" style="padding: 3px 8px; font-size: 11px; color: #f87171;">Delete</button>
      </td>
    `;

    tableBody.appendChild(tr);
  });

  // Attach toggle listeners
  tableBody.querySelectorAll('.custom-toggle').forEach(chk => {
    chk.addEventListener('change', (e) => {
      const id = e.target.getAttribute('data-id');
      const enabled = e.target.checked;
      toggleCustomRule(id, enabled);
    });
  });

  // Attach delete listeners
  tableBody.querySelectorAll('.btn-delete-custom').forEach(btn => {
    btn.addEventListener('click', (e) => {
      const id = e.target.getAttribute('data-id');
      deleteCustomRule(id);
    });
  });

  // Attach directive tag copy listeners
  tableBody.querySelectorAll('.directive-tag').forEach(tag => {
    tag.addEventListener('click', () => {
      const text = tag.textContent;
      if (typeof navigator !== 'undefined' && navigator.clipboard) {
        navigator.clipboard.writeText(text);
        const original = tag.textContent;
        tag.textContent = 'Copied!';
        setTimeout(() => { tag.textContent = original; }, 1000);
      }
    });
  });
}

function toggleCustomRule(id, enabled) {
  const updated = customRules.map(r => {
    if (r.id === id) {
      return { ...r, enabled };
    }
    return r;
  });
  saveCustomRulesStorage(updated, () => {
    renderCustomRules();
  });
}

function deleteCustomRule(id) {
  const updated = customRules.filter(r => r.id !== id);
  saveCustomRulesStorage(updated, () => {
    renderCustomRules();
  });
}

function getDraftCustomRuleFromModal() {
  const name = (document.getElementById('customRuleName')?.value || '').trim();
  const slug = (document.getElementById('customRuleSlug')?.value || '').trim() || generateSlug(name);
  const type = document.getElementById('customRuleType')?.value || 'keyword';
  const pattern = (document.getElementById('customRulePattern')?.value || '').trim();
  const protoText = document.getElementById('customRulePrototypes')?.value || '';
  const prototypes = protoText.split('\n').map(s => s.trim()).filter(Boolean);
  const sensitivity = parseFloat(document.getElementById('customRuleSensitivity')?.value || '0.85');
  const action = document.getElementById('customRuleAction')?.value || 'BLOCK';

  return {
    id: 'draft-rule',
    slug,
    name: name || 'Draft Rule',
    type,
    pattern: (type === 'keyword' || type === 'regex') ? pattern : undefined,
    prototypes: type === 'semantic' ? prototypes : undefined,
    sensitivity: type === 'semantic' ? sensitivity : 0.85,
    action,
    enabled: true
  };
}

function testCustomRuleSandbox() {
  const sandboxInput = document.getElementById('customRuleSandboxInput');
  const statusEl = document.getElementById('customRuleSandboxStatus');
  if (!sandboxInput || !statusEl) return;

  const text = sandboxInput.value;
  if (!text || text.trim().length === 0) {
    statusEl.textContent = 'Enter text above to verify detection';
    statusEl.style.color = '#a1a1aa';
    statusEl.style.background = '#16161a';
    return;
  }

  const draft = getDraftCustomRuleFromModal();
  let matcher = typeof matchCustomRules === 'function' ? matchCustomRules : null;
  if (!matcher && typeof window !== 'undefined' && typeof window.matchCustomRules === 'function') {
    matcher = window.matchCustomRules;
  }
  if (!matcher && typeof globalThis !== 'undefined' && typeof globalThis.matchCustomRules === 'function') {
    matcher = globalThis.matchCustomRules;
  }

  if (!matcher) {
    statusEl.textContent = 'Catalog matcher not initialized';
    statusEl.style.color = '#f87171';
    return;
  }

  const matches = matcher(text, [draft]);
  if (matches && matches.length > 0) {
    const m = matches[0];
    if (draft.action === 'REDACT') {
      let sanitizer = typeof sanitizeCustomPrompt === 'function' ? sanitizeCustomPrompt : null;
      if (!sanitizer && typeof window !== 'undefined' && typeof window.sanitizeCustomPrompt === 'function') {
        sanitizer = window.sanitizeCustomPrompt;
      }
      const sanRes = sanitizer ? sanitizer(text, matches) : { sanitizedText: text };
      statusEl.innerHTML = `🛑 <strong style="color: #c084fc;">MATCH [REDACT]:</strong> Matched "<code>${escapeHtml(m.matchedToken || draft.name)}</code>"<br><span style="color: #34d399;">Sanitized preview:</span> <code>${escapeHtml(sanRes.sanitizedText)}</code>`;
      statusEl.style.background = 'rgba(168, 85, 247, 0.15)';
    } else if (draft.action === 'WARN') {
      statusEl.innerHTML = `⚠️ <strong style="color: #fbbf24;">MATCH [WARN]:</strong> Advisory warning for "<code>${escapeHtml(m.matchedToken || draft.name)}</code>"`;
      statusEl.style.background = 'rgba(245, 158, 11, 0.15)';
    } else {
      statusEl.innerHTML = `🛑 <strong style="color: #f87171;">MATCH [BLOCK]:</strong> Prompt blocked by rule "<code>${escapeHtml(draft.name)}</code>"`;
      statusEl.style.background = 'rgba(239, 68, 68, 0.15)';
    }
  } else {
    statusEl.textContent = '✓ No match detected for this prompt.';
    statusEl.style.color = '#34d399';
    statusEl.style.background = 'rgba(16, 185, 129, 0.12)';
  }
}

function initCustomRulesUI() {
  const modal = document.getElementById('customRuleModal');
  const btnOpen = document.getElementById('btnOpenCustomModal');
  const btnClose = document.getElementById('btnCloseCustomModal');
  const btnCancel = document.getElementById('btnCancelCustomModal');
  const btnSave = document.getElementById('btnSaveCustomRule');

  const nameInput = document.getElementById('customRuleName');
  const slugInput = document.getElementById('customRuleSlug');
  const typeSelect = document.getElementById('customRuleType');
  const patternInput = document.getElementById('customRulePattern');
  const patternContainer = document.getElementById('customPatternContainer');
  const semanticContainer = document.getElementById('customSemanticContainer');
  const patternLinterStatus = document.getElementById('customPatternLinterStatus');
  const sensitivitySlider = document.getElementById('customRuleSensitivity');
  const sensitivityVal = document.getElementById('customSensitivityVal');
  const actionSelect = document.getElementById('customRuleAction');
  const actionHint = document.getElementById('customActionHint');
  const sandboxInput = document.getElementById('customRuleSandboxInput');
  const searchInput = document.getElementById('customSearchInput');

  let userEditedSlug = false;

  function openModal() {
    if (btnOpen && btnOpen.disabled) return;
    if (!modal) return;
    modal.style.display = 'flex';
    userEditedSlug = false;
    if (nameInput) nameInput.value = '';
    if (slugInput) slugInput.value = '';
    if (typeSelect) typeSelect.value = 'keyword';
    if (patternInput) patternInput.value = '';
    if (patternContainer) patternContainer.style.display = 'block';
    if (semanticContainer) semanticContainer.style.display = 'none';
    const protos = document.getElementById('customRulePrototypes');
    if (protos) protos.value = '';
    if (sensitivitySlider) sensitivitySlider.value = '0.85';
    if (sensitivityVal) sensitivityVal.textContent = '0.85';
    if (actionSelect) actionSelect.value = 'BLOCK';
    if (actionHint) actionHint.textContent = 'BLOCK stops outgoing transmission completely and displays a violation overlay.';
    if (sandboxInput) sandboxInput.value = '';
    const statusEl = document.getElementById('customRuleSandboxStatus');
    if (statusEl) {
      statusEl.textContent = 'Enter text above to verify detection';
      statusEl.style.color = '#a1a1aa';
      statusEl.style.background = '#16161a';
    }
  }

  function closeModal() {
    if (modal) modal.style.display = 'none';
  }

  if (btnOpen) btnOpen.addEventListener('click', openModal);
  if (btnClose) btnClose.addEventListener('click', closeModal);
  if (btnCancel) btnCancel.addEventListener('click', closeModal);

  if (modal) {
    modal.addEventListener('click', (e) => {
      if (e.target === modal) closeModal();
    });
  }

  if (nameInput) {
    nameInput.addEventListener('input', () => {
      if (!userEditedSlug && slugInput) {
        const generated = generateSlug(nameInput.value);
        slugInput.value = generated;
        const hint = document.getElementById('customSlugDirectiveHint');
        if (hint) hint.textContent = `// saif:ignore[${generated || 'custom-rule'}]`;
      }
      testCustomRuleSandbox();
    });
  }

  if (slugInput) {
    slugInput.addEventListener('input', () => {
      userEditedSlug = true;
      const hint = document.getElementById('customSlugDirectiveHint');
      if (hint) hint.textContent = `// saif:ignore[${slugInput.value || 'custom-rule'}]`;
      testCustomRuleSandbox();
    });
  }

  if (typeSelect) {
    typeSelect.addEventListener('change', () => {
      const isSemantic = typeSelect.value === 'semantic';
      if (patternContainer) patternContainer.style.display = isSemantic ? 'none' : 'block';
      if (semanticContainer) semanticContainer.style.display = isSemantic ? 'block' : 'none';
      if (patternLinterStatus && !isSemantic) {
        patternLinterStatus.textContent = typeSelect.value === 'regex' ? 'Regex syntax check active' : 'Exact substring matching';
      }
      testCustomRuleSandbox();
    });
  }

  if (patternInput) {
    patternInput.addEventListener('input', () => {
      if (typeSelect && typeSelect.value === 'regex') {
        const check = checkReDoS(patternInput.value);
        if (!check.valid) {
          patternLinterStatus.textContent = `⚠️ ${check.error}`;
          patternLinterStatus.style.color = '#f87171';
        } else {
          patternLinterStatus.textContent = '✓ Regular expression valid & ReDoS safe';
          patternLinterStatus.style.color = '#34d399';
        }
      } else {
        patternLinterStatus.textContent = '✓ Valid keyword pattern';
        patternLinterStatus.style.color = '#34d399';
      }
      testCustomRuleSandbox();
    });
  }

  if (sensitivitySlider && sensitivityVal) {
    sensitivitySlider.addEventListener('input', () => {
      sensitivityVal.textContent = sensitivitySlider.value;
      testCustomRuleSandbox();
    });
  }

  if (actionSelect) {
    actionSelect.addEventListener('change', () => {
      const act = actionSelect.value;
      if (actionHint) {
        if (act === 'BLOCK') actionHint.textContent = 'BLOCK stops outgoing transmission completely and displays a violation overlay.';
        else if (act === 'REDACT') actionHint.textContent = 'REDACT performs in-place text replacement in the composer before send.';
        else if (act === 'WARN') actionHint.textContent = 'WARN displays an advisory badge above the composer without blocking.';
      }
      testCustomRuleSandbox();
    });
  }

  if (sandboxInput) {
    sandboxInput.addEventListener('input', testCustomRuleSandbox);
  }

  const protos = document.getElementById('customRulePrototypes');
  if (protos) {
    protos.addEventListener('input', testCustomRuleSandbox);
  }

  if (searchInput) {
    searchInput.addEventListener('input', (e) => {
      currentCustomSearchQuery = (e.target.value || '').toLowerCase().trim();
      renderCustomRules();
    });
  }

  if (btnSave) {
    btnSave.addEventListener('click', () => {
      const name = (nameInput?.value || '').trim();
      if (!name) {
        alert('Please provide a rule name.');
        return;
      }
      const slug = (slugInput?.value || '').trim() || generateSlug(name);
      const type = typeSelect?.value || 'keyword';
      const pattern = (patternInput?.value || '').trim();
      const protoText = document.getElementById('customRulePrototypes')?.value || '';
      const prototypes = protoText.split('\n').map(s => s.trim()).filter(Boolean);

      if ((type === 'keyword' || type === 'regex') && !pattern) {
        alert('Please enter a pattern or keyword string.');
        return;
      }
      if (type === 'regex') {
        const check = checkReDoS(pattern);
        if (!check.valid) {
          alert(`Invalid regular expression: ${check.error}`);
          return;
        }
      }
      if (type === 'semantic' && prototypes.length === 0) {
        alert('Please provide at least one prototype sentence for semantic evaluation.');
        return;
      }

      const action = actionSelect?.value || 'BLOCK';
      const sensitivity = parseFloat(sensitivitySlider?.value || '0.85');

      const newRule = {
        id: 'custom-' + Date.now(),
        slug,
        name,
        type,
        pattern: (type === 'keyword' || type === 'regex') ? pattern : undefined,
        prototypes: type === 'semantic' ? prototypes : undefined,
        sensitivity: type === 'semantic' ? sensitivity : 0.85,
        action,
        enabled: true,
        createdAt: Date.now()
      };

      const updated = [...customRules, newRule];
      saveCustomRulesStorage(updated, () => {
        renderCustomRules();
        closeModal();
      });
    });
  }
}

// Node.js test environment export
try {
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      exportAuditCsv,
      formatOrigin,
      escapeHtml,
      initSandbox,
      runSandboxInspection,
      highlightRedactedDiff,
      generateSlug,
      checkReDoS,
      loadCustomRules,
      renderCustomRules,
      getDraftCustomRuleFromModal,
      testCustomRuleSandbox,
      syncCustomRulesToAgent
    };
  }
} catch (_) {}
