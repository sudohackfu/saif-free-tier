const urlParams = new URLSearchParams(window.location.search);
    const sessionId = urlParams.get('session') || urlParams.get('sessionId');

    let sessionData = null;
    let grouped = {};
    let selectedActions = {};
    let selectedItemActions = {};
    let currentSanitizedPrompt = null;
    let currentOverriddenTokens = [];
    let decisionSubmitted = false;

    // Listen for extension postMessage bridge
    window.addEventListener('message', (event) => {
      if (event.data && event.data.type === 'SAIF_TRIAGE_LOAD') {
        sessionData = event.data.payload;
        renderTriageUI(sessionData);
      }
    });

    // Notify parent frame (extension content script) that triage UI is ready
    if (window.parent && window.parent !== window) {
      window.parent.postMessage({ type: 'SAIF_TRIAGE_INIT' }, '*');
    }

    // Desktop REST API fallback if sessionId exists
    if (sessionId) {
      fetch('/api/v1/triage/details?session=' + encodeURIComponent(sessionId))
        .then(res => res.json())
        .then(data => {
          sessionData = data;
          renderTriageUI(data);
        })
        .catch(err => {
          console.error('Failed to load session details:', err);
        });
    }

    function renderTriageUI(data) {
      const listEl = document.getElementById('violation-list');
      if (!listEl) return;
      listEl.innerHTML = '';
      console.log('[SAIF Triage] renderTriageUI data:', JSON.stringify(data));

      const violations = (data && data.violations) || [];
      const subtitle = document.getElementById('triage-subtitle');
      if (subtitle) subtitle.textContent = 'SAIF Security - Composite Threat Triage: ' + violations.length + ' policy violation(s) detected';
      const pill = document.getElementById('saif-counter-pill');
      if (pill) pill.textContent = violations.length + ' Violations Detected';

      // Group by rule
      grouped = {};
      selectedActions = {};
      selectedItemActions = {};

      violations.forEach((v, idx) => {
        const key = v.rule_id || v.ruleId || v.id || ('rule-' + idx);
        if (!grouped[key]) {
          grouped[key] = {
            id: key,
            name: v.rule_name || v.ruleName || v.name || key,
            origin: v.origin || 'REGEX_DLP',
            category: v.category || 'pii_national_id',
            placeholder: v.placeholder || '[REDACTED]',
            items: []
          };
        }
        const itemIdx = grouped[key].items.length;
        grouped[key].items.push(v);
        selectedActions[key] = 'redact';
        selectedItemActions[key + ':' + itemIdx] = 'redact';
      });

      Object.values(grouped).forEach(g => {
        const row = document.createElement('div');
        row.className = 'violation-row';
        row.dataset.ruleId = g.id;

        const isSemantic = g.origin === 'SEMANTIC_ONNX';
        const badgeClass = isSemantic ? 'badge-semantic' : 'badge-dlp';
        const badgeText = isSemantic ? 'Semantic' : 'DLP Regex';
        const hasMultiple = g.items.length > 1;

        let rowHTML = '<div class="row-main">' +
          '<div class="row-left">' +
            '<span class="badge ' + badgeClass + '">' + badgeText + '</span>' +
            '<span class="rule-name">' + escapeHTML(g.name) + '</span>';

        if (hasMultiple) {
          rowHTML += '<button type="button" class="btn-accordion">' +
            '<span class="accordion-arrow">▾</span> <span class="match-count">(' + g.items.length + ' matches)</span>' +
          '</button>';
        } else {
          rowHTML += '<span class="match-count">(1 match)</span>';
        }

        rowHTML += '</div>' +
          '<div class="row-actions">' +
            '<label><input type="radio" name="action-' + escapeHTML(g.id) + '" value="redact" checked> ' + (hasMultiple ? 'Redact All' : 'Redact') + '</label>' +
            '<label><input type="radio" name="action-' + escapeHTML(g.id) + '" value="override"> ' + (hasMultiple ? 'Override All' : 'Override') + '</label>' +
          '</div>' +
        '</div>' +
        '<div class="drawer">' +
          '<div class="drawer-header" style="display:flex;align-items:center;justify-content:space-between;' + (hasMultiple ? 'margin-bottom:6px;' : '') + '">' +
            '<span>Sample token: <code>' + escapeHTML(g.items[0].matched_text || g.items[0].matchedText || g.items[0].token || '[match]') + '</code></span>' +
            (hasMultiple ? '<span style="font-size:10px;color:var(--text-muted);">(Customize individual matches below)</span>' : '') +
          '</div>';

        if (hasMultiple) {
          rowHTML += '<div class="accordion-items" id="accordion-' + escapeHTML(g.id) + '">';
          g.items.forEach((item, itemIdx) => {
            rowHTML += '<div class="sub-item-row" data-item-idx="' + itemIdx + '">' +
              '<div class="sub-item-left">' +
                '<span class="sub-item-idx">#' + (itemIdx + 1) + '</span>' +
                '<code class="sub-item-token">' + escapeHTML(item.matched_text || item.matchedText || item.token || '[match]') + '</code>' +
              '</div>' +
              '<div class="sub-item-actions">' +
                '<label><input type="radio" name="item-' + escapeHTML(g.id) + '-' + itemIdx + '" value="redact" checked> Redact</label>' +
                '<label><input type="radio" name="item-' + escapeHTML(g.id) + '-' + itemIdx + '" value="override"> Override</label>' +
              '</div>' +
            '</div>';
          });
          rowHTML += '</div>';
        }

        rowHTML += '</div>';
        row.innerHTML = rowHTML;

        // Accordion toggle button
        if (hasMultiple) {
          const btn = row.querySelector('.btn-accordion');
          const drawer = row.querySelector('.accordion-items');
          const arrow = row.querySelector('.accordion-arrow');
          if (btn && drawer) {
            btn.addEventListener('click', (e) => {
              e.preventDefault();
              drawer.classList.toggle('collapsed');
              const isCollapsed = drawer.classList.contains('collapsed');
              if (arrow) arrow.textContent = isCollapsed ? '▸' : '▾';
            });
          }
        }

        // Master group radios
        const masterRadios = row.querySelectorAll('.row-actions input[type="radio"]');
        masterRadios.forEach(mr => {
          mr.addEventListener('change', () => {
            selectedActions[g.id] = mr.value;
            g.items.forEach((_, itemIdx) => {
              selectedItemActions[g.id + ':' + itemIdx] = mr.value;
            });
            const subRadios = row.querySelectorAll('.sub-item-row input[type="radio"]');
            subRadios.forEach(sr => {
              if (sr.value === mr.value) sr.checked = true;
            });
            updateDiffPreview();
          });
        });

        // Individual child radios
        if (hasMultiple) {
          const subRows = row.querySelectorAll('.sub-item-row');
          subRows.forEach(subRow => {
            const itemIdx = parseInt(subRow.dataset.itemIdx, 10);
            const childRadios = subRow.querySelectorAll('input[type="radio"]');
            childRadios.forEach(cr => {
              cr.addEventListener('change', () => {
                selectedItemActions[g.id + ':' + itemIdx] = cr.value;
                let allRedact = true;
                let allOverride = true;
                g.items.forEach((_, idx) => {
                  const val = selectedItemActions[g.id + ':' + idx];
                  if (val === 'override') allRedact = false;
                  if (val === 'redact') allOverride = false;
                });
                const masterRedact = row.querySelector('.row-actions input[value="redact"]');
                const masterOverride = row.querySelector('.row-actions input[value="override"]');
                if (allRedact && masterRedact) {
                  masterRedact.checked = true;
                  selectedActions[g.id] = 'redact';
                } else if (allOverride && masterOverride) {
                  masterOverride.checked = true;
                  selectedActions[g.id] = 'override';
                } else {
                  if (masterRedact) masterRedact.checked = false;
                  if (masterOverride) masterOverride.checked = false;
                  selectedActions[g.id] = 'custom';
                }
                updateDiffPreview();
              });
            });
          });
        }

        listEl.appendChild(row);
      });

      updateDiffPreview();
    }

    function getCanonicalMask(v) {
      if (v.placeholder && v.placeholder.startsWith('[') && v.placeholder.endsWith(']')) {
        return v.placeholder;
      }
      if (v.origin === 'SEMANTIC_ONNX' && (v.rule_name || v.ruleName)) {
        return '[REDACTED: ' + (v.rule_name || v.ruleName) + ']';
      }
      const cat = (v.category || '').toLowerCase();
      if (cat.includes('secret')) return '[REDACTED: secrets]';
      if (cat.includes('national') || cat.includes('id') || cat.includes('pii')) return '[REDACTED: pii_national_id]';
      if (cat.includes('financial')) return '[REDACTED: pii_financial]';
      if (cat.includes('healthcare')) return '[REDACTED: pii_healthcare]';

      const rule = ((v.rule_id || v.ruleId || '') + ' ' + (v.rule_name || v.ruleName || '')).toLowerCase();
      if (rule.includes('phoenix')) return '[REDACTED: Project Phoenix Technical Leak]';
      if (rule.includes('aws') || rule.includes('key')) return '[AWS_KEY_REDACTED]';
      if (rule.includes('secret') || rule.includes('token') || rule.includes('infra')) return '[REDACTED: secrets]';
      if (rule.includes('ssn') || rule.includes('passport') || rule.includes('national')) return '[REDACTED: pii_national_id]';
      if (rule.includes('bank') || rule.includes('finance') || rule.includes('margin') || rule.includes('mnpi')) return '[REDACTED: pii_financial]';
      if (rule.includes('mrn') || rule.includes('health') || rule.includes('biopsy')) return '[REDACTED: pii_healthcare]';

      if (v.rule_name || v.ruleName) return '[REDACTED: ' + (v.rule_name || v.ruleName) + ']';
      return '[REDACTED: pii_national_id]';
    }

    function updateDiffPreview() {
      if (!sessionData) return;
      let text = sessionData.prompt || '';
      const diffEl = document.getElementById('diff-preview');
      if (!diffEl) return;

      const violations = sessionData.violations || [];
      const spans = [];
      const overrides = [];

      violations.forEach((v) => {
        const ruleId = v.rule_id || v.ruleId || v.id;
        const g = grouped[ruleId];
        let itemIdx = 0;
        if (g && g.items) {
          const foundIdx = g.items.indexOf(v);
          if (foundIdx !== -1) itemIdx = foundIdx;
        }
        const itemKey = ruleId + ':' + itemIdx;
        const itemDecision = selectedItemActions[itemKey] !== undefined ? selectedItemActions[itemKey] : (selectedActions[ruleId] || 'redact');

        let start = v.start;
        let end = v.end;
        const matchText = v.matched_text || v.matchedText || v.token;

        if (matchText) {
          if (start === undefined || start < 0 || end > text.length || start >= end || text.slice(start, end) !== matchText) {
            const idx = text.indexOf(matchText);
            if (idx !== -1) {
              start = idx;
              end = idx + matchText.length;
            }
          }
        }

        if (start >= 0 && end <= text.length && start < end) {
          if (itemDecision === 'redact') {
            const mask = getCanonicalMask(v);
            spans.push({ start, end, mask, ruleId });
          } else if (itemDecision === 'override') {
            const tok = matchText || (start >= 0 && end <= text.length ? text.slice(start, end) : '');
            overrides.push({ start, end, ruleId, token: tok });
          }
        }
      });

      // Carve out explicitly overridden child tokens from enclosing parent rule spans
      overrides.forEach((ov) => {
        for (let i = 0; i < spans.length; i++) {
          const sp = spans[i];
          if (sp.start <= ov.start && ov.end <= sp.end && (sp.end - sp.start) > (ov.end - ov.start)) {
            if (sp.start < ov.start) {
              sp.end = ov.start;
            } else {
              sp.start = ov.end;
            }
          }
        }
      });

      if (spans.length > 1) {
        const filtered = spans.filter(sp => !(sp.start === 0 && sp.end >= text.length));
        if (filtered.length > 0) spans.length = 0, spans.push(...filtered);
      }

      spans.sort((a, b) => a.start === b.start ? b.end - a.end : a.start - b.start);

      const merged = [];
      for (const curr of spans) {
        if (merged.length === 0) {
          merged.push(curr);
          continue;
        }
        const last = merged[merged.length - 1];
        if (curr.start >= last.start && curr.end <= last.end) continue;
        if (curr.start < last.end) {
          if (curr.end > last.end) last.end = curr.end;
          continue;
        }
        merged.push(curr);
      }

      let sanHtml = '';
      let plainSanitized = '';
      let lastIdx = 0;

      for (let i = 0; i < merged.length; i++) {
        const sp = merged[i];
        const unch = text.slice(lastIdx, sp.start);
        sanHtml += escapeHTML(unch);
        plainSanitized += unch;

        sanHtml += '<span class="masked-tag">' + escapeHTML(sp.mask) + '</span>';
        plainSanitized += sp.mask;

        lastIdx = sp.end;
      }
      const tail = text.slice(lastIdx);
      sanHtml += escapeHTML(tail);
      plainSanitized += tail;

      currentSanitizedPrompt = plainSanitized;

      // Extract unique plain strings for all authorized override items
      currentOverriddenTokens = [];
      overrides.forEach(ov => {
        const tok = ov.token || (ov.start >= 0 && ov.end <= text.length ? text.slice(ov.start, ov.end) : '');
        const cleanTok = (tok || '').trim();
        if (cleanTok && !currentOverriddenTokens.includes(cleanTok)) {
          currentOverriddenTokens.push(cleanTok);
        }
      });

      diffEl.innerHTML = sanHtml;
    }

    function copySanitizedText() {
      const textToCopy = currentSanitizedPrompt || (sessionData && sessionData.sanitized_prompt) || (sessionData && sessionData.prompt);
      if (!textToCopy) return;

      try {
        const ta = document.createElement('textarea');
        ta.value = textToCopy;
        ta.style.position = 'fixed';
        ta.style.left = '-9999px';
        ta.style.top = '-9999px';
        document.body.appendChild(ta);
        ta.focus();
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
      } catch (err) {
        console.error('[SAIF Triage] execCommand copy error:', err);
      }

      if (navigator.clipboard && navigator.clipboard.writeText) {
        navigator.clipboard.writeText(textToCopy).catch(() => {});
      }
    }

    function submitDecision(action) {
      if (!currentSanitizedPrompt && sessionData) {
        updateDiffPreview();
      }
      if (action === 'redact') {
        copySanitizedText();
      }

      if (decisionSubmitted) return;
      decisionSubmitted = true;

      console.log('[SAIF Triage] submitDecision posting SAIF_TRIAGE_DECISION with tokens:', JSON.stringify(currentOverriddenTokens));

      // In extension mode, notify parent content script
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({
          type: 'SAIF_TRIAGE_DECISION',
          action: action,
          selected: selectedActions,
          selected_items: selectedItemActions,
          sanitized_prompt: currentSanitizedPrompt,
          overridden_tokens: currentOverriddenTokens
        }, '*');
      }

      if (sessionId) {
        fetch('/api/v1/triage/decision', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sessionId: sessionId,
            action: action,
            selected: selectedActions,
            selected_items: selectedItemActions,
            sanitized_prompt: currentSanitizedPrompt
          })
        }).finally(() => {
          setTimeout(() => { window.close(); }, 100);
        });
      }
    }

    function sendWindowCloseCancellation() {
      if (decisionSubmitted) return;
      decisionSubmitted = true;
      if (window.parent && window.parent !== window) {
        window.parent.postMessage({
          type: 'SAIF_TRIAGE_DECISION',
          action: 'cancel'
        }, '*');
      }
      if (sessionId) {
        const payload = JSON.stringify({ sessionId: sessionId, action: 'cancel' });
        if (navigator.sendBeacon) {
          navigator.sendBeacon('/api/v1/triage/decision', new Blob([payload], { type: 'application/json' }));
        } else {
          fetch('/api/v1/triage/decision', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: payload,
            keepalive: true
          });
        }
      }
    }

    window.addEventListener('pagehide', sendWindowCloseCancellation);
    window.addEventListener('beforeunload', sendWindowCloseCancellation);
    window.addEventListener('unload', sendWindowCloseCancellation);

    // Batch toggle listeners
    document.getElementById('radio-batch-redact').addEventListener('change', () => {
      setAllActions('redact');
    });
    document.getElementById('radio-batch-override').addEventListener('change', () => {
      setAllActions('override');
    });

    function setAllActions(action) {
      Object.keys(selectedActions).forEach(k => {
        selectedActions[k] = action;
      });
      Object.keys(selectedItemActions).forEach(itemKey => {
        selectedItemActions[itemKey] = action;
      });
      document.querySelectorAll('.row-actions input[type="radio"], .sub-item-actions input[type="radio"]').forEach(r => {
        if (r.value === action) r.checked = true;
      });
      const applyBtn = document.getElementById('btn-apply');
      if (applyBtn) {
        applyBtn.textContent = action === 'override' ? 'Authorize Break-Glass & Send' : '🛡️ Sanitize Prompt (Enter / R)';
      }
      updateDiffPreview();
    }

    // Button actions
    document.getElementById('btn-apply').addEventListener('click', () => {
      const isBreakGlassPreset = document.getElementById('radio-batch-override') && document.getElementById('radio-batch-override').checked;
      const action = isBreakGlassPreset ? 'override' : 'redact';
      submitDecision(action);
    });

    document.getElementById('btn-cancel').addEventListener('click', () => {
      submitDecision('cancel');
    });

    // Keyboard shortcuts
    window.addEventListener('keydown', (e) => {
      const activeEl = document.activeElement;
      const isInput = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA');
      if (isInput) return;

      if (e.key === 'Enter') {
        const isBreakGlassPreset = document.getElementById('radio-batch-override') && document.getElementById('radio-batch-override').checked;
        submitDecision(isBreakGlassPreset ? 'override' : 'redact');
      } else if (e.key === 'Escape') {
        submitDecision('cancel');
      } else if (e.key === 'r' || e.key === 'R') {
        document.getElementById('radio-batch-redact').checked = true;
        setAllActions('redact');
        submitDecision('redact');
      } else if (e.key === 'b' || e.key === 'B') {
        document.getElementById('radio-batch-override').checked = true;
        setAllActions('override');
      }
    });

    function escapeHTML(str) {
      return (str || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }
